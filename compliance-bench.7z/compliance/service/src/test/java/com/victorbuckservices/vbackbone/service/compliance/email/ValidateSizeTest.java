package com.victorbuckservices.vbackbone.service.compliance.email;

import static com.google.common.io.Resources.getResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Lists;
import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailSizeData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@RunWith(Parameterized.class)
public class ValidateSizeTest extends AbstractTest {

    private MockMvc mockMvc;

    @Before
    public void init() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Parameterized.Parameter(0)
    public TestData testData;

    @Parameterized.Parameters(name = "{index}: testEmailSize({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {
        return Arrays.asList(EmailSizeData.getBatchEmailSizeData())
                .stream()
                .flatMap(List::stream)
                .filter(TestData::isServer)
                .map(d -> new Object[]{d})
                .collect(Collectors.toList());
    }

    @Test
    public void testEmailSize() throws Exception {
        doMock(mockMvc , testData);
    }
}
