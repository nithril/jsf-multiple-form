package com.victorbuckservices.vbackbone.service.compliance.email;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.FromAddressesData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Lists;

/**
 * Created by nlabrot on 31/10/15.
 */
@RunWith(Parameterized.class)
public class ValidateFromTest extends AbstractTest {

    private MockMvc mockMvc;

    @Before
    public void init() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Parameterized.Parameter(0)
    public TestData testData;


    @Parameterized.Parameters(name = "{index}: testValidate({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {
        return Lists.newArrayList(
                FromAddressesData.getBatchEmailData(),
                FromAddressesData.getUnitaryEmailData(),
                FromAddressesData.getUnitaryEmailDataWithReport())
                .stream()
                .flatMap(List::stream)
                .filter(TestData::isServer)
                .map(d -> new Object[]{d})
                .collect(Collectors.toList());
    }

    @Test
    public void testValidate() throws Exception {
        doMock(mockMvc , testData);
    }


}
