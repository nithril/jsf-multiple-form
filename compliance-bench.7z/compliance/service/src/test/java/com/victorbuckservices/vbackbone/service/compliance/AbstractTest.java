package com.victorbuckservices.vbackbone.service.compliance;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.context.WebApplicationContext;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringApplicationConfiguration(classes = {Application.class})
@WebAppConfiguration
@ActiveProfiles({"test"})
public abstract class AbstractTest {

    @ClassRule
    public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();
    @Rule
    public final SpringMethodRule springMethodRule = new SpringMethodRule();
    @Autowired
    protected WebApplicationContext webApplicationContext;
    @Autowired
    protected ObjectMapper objectMapper;

    @BeforeClass
    public static void createDirectory() throws Exception {
        Files.createDirectories(Paths.get("target/storagekeeper/work"));
        Files.createDirectories(Paths.get("target/storagekeeper/storage"));
    }

    @Before
    public void setUp() {
        objectMapper.enable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    protected void doMock(MockMvc mockMvc, TestData testData) {
        try {
            MockHttpServletRequestBuilder request = request(testData.getMethod(), new URI(testData.getUrl()));

            if (testData.getRequestMediaType() != null) {
                request.contentType(testData.getRequestMediaType());
            }
            if (testData.getRequestContent() != null) {
                request.content(testData.getRequestContent());
            }

            ResultActions actions = mockMvc.perform(request);

            if (testData.getResultMediaType() != null) {
                actions.andExpect(content().contentType(testData.getResultMediaType()));
            }
            actions.andExpect(status().is(testData.getStatus()));

            MvcResult mvcResult = actions.andReturn();

            if (testData.getServerResultContent() != null) {

                if (testData.getResultMediaType() != null && testData.getResultMediaType().toString().contains("json")) {
                    Assert.assertEquals(objectMapper.readTree(testData.getServerResultContent()), objectMapper.readTree(mvcResult.getResponse().getContentAsString()));
                } else {
                    Assert.assertEquals(testData.getServerResultContent(), mvcResult.getResponse().getContentAsString());
                }
            }
        } catch (Exception | Error e) {
            throw new RuntimeException("Element was '" + testData.getData().toString() + "'", e);
        }
    }
}
