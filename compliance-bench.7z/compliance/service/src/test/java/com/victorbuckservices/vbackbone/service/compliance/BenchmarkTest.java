package com.victorbuckservices.vbackbone.service.compliance;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Stopwatch;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import com.victorbuckservices.vbackbone.service.compliance.validator.email.EmailAddressValidator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.net.URI;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by nlabrot on 31/10/15.
 */
@Ignore
public class BenchmarkTest extends AbstractTest {

    @Autowired
    EmailAddressValidator emailAddressValidator;

    private MockMvc mockMvc;

    @Before
    public void init() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void testName() throws Exception {

        List<String> list = new ObjectMapper().readValue(getClass().getResourceAsStream("/benchmark.json"), List.class);


        Stopwatch stopwatch = Stopwatch.createStarted();

        for (String email : list) {
            emailAddressValidator.validate(email);
        }

        stopwatch.stop();

        System.out.println(list.size() / (stopwatch.elapsed(TimeUnit.MILLISECONDS) / 1000.0f));


    }


    @Test
    public void bench() throws Exception {
        List<String> list = new ObjectMapper().readValue(getClass().getResourceAsStream("/benchmark.json"), List.class);


        for (int i = 0; i < 100; i++) {
            Stopwatch stopwatch = Stopwatch.createStarted();

            for (String email : list) {
                TestData testData = TestData.newUnitaryEmailData_Pass(email);
                doMock(mockMvc, testData);
            }
            stopwatch.stop();
            System.out.println(list.size() / (stopwatch.elapsed(TimeUnit.MILLISECONDS) / 1000.0f));
        }


    }


    protected void doMock(MockMvc mockMvc, TestData testData) {
        try {
            MockHttpServletRequestBuilder request = request(testData.getMethod(), new URI(testData.getUrl()));

            if (testData.getRequestMediaType() != null) {
                request.contentType(testData.getRequestMediaType());
            }
            if (testData.getRequestContent() != null) {
                request.content(testData.getRequestContent());
            }

            ResultActions actions = mockMvc.perform(request);

            if (testData.getResultMediaType() != null) {
                actions.andExpect(content().contentType(testData.getResultMediaType()));
            }
            //actions.andExpect(status().is(testData.getStatus()));

            MvcResult mvcResult = actions.andReturn();

            if (testData.getServerResultContent() != null) {

                if (testData.getResultMediaType() != null && testData.getResultMediaType().toString().contains("json")) {
                    Assert.assertEquals(objectMapper.readTree(testData.getServerResultContent()), objectMapper.readTree(mvcResult.getResponse().getContentAsString()));
                } else {
                    Assert.assertEquals(testData.getServerResultContent(), mvcResult.getResponse().getContentAsString());
                }
            }
        } catch (Exception | Error e) {
            throw new RuntimeException("Element was '" + testData.getData().toString() + "'", e);
        }
    }
}
