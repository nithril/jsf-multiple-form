package com.victorbuckservices.vbackbone.service.compliance.fax;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.FaxNumberData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Created by nlabrot on 31/10/15.
 */
@RunWith(Parameterized.class)
public class ValidateNumberTest extends AbstractTest {

    private MockMvc mockMvc;

    @Before
    public void init() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Parameterized.Parameter(0)
    public TestData testData;


    @Parameterized.Parameters(name = "{index}: testValidate({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {

        return Arrays.asList(
                FaxNumberData.getBatchData(),
                FaxNumberData.getUnitaryData(),
                FaxNumberData.getUnitaryDataWithReport())
                .stream()
                .flatMap(List::stream)
                .filter(TestData::isServer)
                .map(d -> new Object[]{d})
                .collect(Collectors.toList());
    }

    @Test
    public void testValidate() throws Exception {
        doMock(mockMvc, testData);
    }


}
