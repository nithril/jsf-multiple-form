package com.victorbuckservices.vbackbone.service.compliance.email;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressesData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RunWith(Parameterized.class)
public class ValidateAddressTest extends AbstractTest {

    @Parameterized.Parameter(0)
    public TestData testData;
    private MockMvc mockMvc;

    @Parameterized.Parameters(name = "{index}: testValidate({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {
        return Arrays.asList(
                EmailAddressesData.getBatchEmailData(),
                EmailAddressesData.getUnitaryEmailData(),
                EmailAddressesData.getUnitaryEmailDataWithReport()
        ).stream()
                .flatMap(List::stream)
                .filter(TestData::isServer)
                .map(d -> new Object[]{d})
                .collect(Collectors.toList());
    }

    @Before
    public void init() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void testValidate() throws Exception {
        doMock(mockMvc, testData);
    }


}
