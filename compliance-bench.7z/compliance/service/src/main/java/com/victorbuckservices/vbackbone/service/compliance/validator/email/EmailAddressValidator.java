package com.victorbuckservices.vbackbone.service.compliance.validator.email;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;

/**
 * Created by nlabrot on 31/10/15.
 */
@Component
public class EmailAddressValidator {

    @Value("${email.pattern}")
    private String emailPattern;

    private Pattern pattern;

    @PostConstruct
    public void init(){
        pattern = Pattern.compile(emailPattern, Pattern.COMMENTS);
    }

    public boolean validate(String emailAddress) {

        // The email length is limited to 255 characters.
        if (emailAddress.length() > 255) {
            return false;
        }

        Matcher matcher = pattern.matcher(emailAddress);
        return matcher.matches();
    }

}
