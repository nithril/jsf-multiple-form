package com.victorbuckservices.vbackbone.service.compliance.email;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_ADDRESS_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.EMAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressValidationResponse.newEmailAddressValidationResponse;
import static org.springframework.http.ResponseEntity.badRequest;
import static org.springframework.http.ResponseEntity.ok;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.validator.email.EmailAddressValidator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RestController
@RequestMapping("/ws/v1")
public class RecipientComplianceController {

    private static final Logger LOG = LoggerFactory.getLogger(RecipientComplianceController.class);

    @Autowired
    private EmailAddressValidator emailAddressValidator;

    @RequestMapping(value = "compliance/emails/addresses/{address:.*}", method = RequestMethod.GET)
    public ResponseEntity validateGet(@PathVariable("address") String address) {

        EmailAddressValidationResponse validationResponse = validate(address);

        if (validationResponse.getLevel() == ReportLevel.INFO) {
            LOG.debug("[INFO] validateGet [address={}] => OK", address);
            return ok().contentType(EMAIL_ADDRESS_RESPONSE.toMediaType()).body(validationResponse);
        } else {
            LOG.debug("[WARNING] validateGet [address={}] => NOK", address);
            return badRequest().contentType(EMAIL_ADDRESS_RESPONSE.toMediaType()).body(validationResponse);
        }

    }

    @RequestMapping(value = "compliance/emails/addresses/{address:.*}", method = RequestMethod.HEAD)
    public ResponseEntity validateHead(@PathVariable("address") String address) {

        if (validate(address).getLevel() == ReportLevel.INFO) {
            LOG.debug("[INFO] validateHead [address={}] => OK", address);
            return ok().build();
        } else {
            LOG.warn("[WARNING] validateHead [address={}] => NOK", address);
            return badRequest().build();
        }
    }


    @RequestMapping(value = "compliance/emails/addresses", method = RequestMethod.POST, consumes = BATCH_EMAIL_ADDRESS_REQUEST_VALUE)
    public ResponseEntity validates(@RequestBody EmailAddressesValidationRequest request) {

        LOG.debug("[INFO] validates [address={}]", StringUtils.join(request.getEmailAddresses(), ", "));

        List<EmailAddressValidationResponse> results = request.getEmailAddresses().stream()
                .filter(n -> !emailAddressValidator.validate(n))
                .map(n -> newEmailAddressValidationResponse().emailAddress(n).level(ReportLevel.ERROR).result("Invalid email address [" + n + "]").build())
                .collect(Collectors.toList());

        return ok()
                .contentType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                .body(EmailAddressesValidationResponse.newEmailAddressesValidationResponse()
                        .results(results)
                        .level(results.isEmpty() ? ReportLevel.INFO : ReportLevel.ERROR).build());
    }

    private EmailAddressValidationResponse validate(String address) {
        EmailAddressValidationResponse.Builder builder = EmailAddressValidationResponse.newEmailAddressValidationResponse();

        if (!emailAddressValidator.validate(address)) {
            builder.level(ReportLevel.ERROR).emailAddress(address).result("Invalid email address [" + address + "]");
        } else {
            builder.level(ReportLevel.INFO).emailAddress(address).result("");
        }
        return builder.build();
    }


}
