package com.victorbuckservices.vbackbone.service.compliance.email;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_SIZE_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_SIZE_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationResult.newEmailSizeValidationResult;
import static org.springframework.http.ResponseEntity.ok;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationResult;
import com.victorbuckservices.vbackbone.service.compliance.validator.email.EmailSizeValidator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@RestController
@RequestMapping("/ws/v1")
public class EmailSizeComplianceController {

    @Autowired
    private EmailSizeValidator emailSizeValidator;

    @RequestMapping(value = "compliance/emails/size", method = RequestMethod.POST, consumes = BATCH_EMAIL_SIZE_REQUEST_VALUE)
    public ResponseEntity validates(@RequestBody EmailSizeValidationRequest request) {

        List<EmailSizeValidationResult> results = request.getEmailMessages().stream()
                .filter(n -> !emailSizeValidator.validate(n))
                .map(n -> newEmailSizeValidationResult().emailMessage(n).level(ReportLevel.ERROR).result("Invalid email size [" + StringUtils.join(n.getAttachmentsUri(), ",") + "," + n.getEmailBodyUri() + "]").build())
                .collect(Collectors.toList());

        return ok()
                .contentType(BATCH_EMAIL_SIZE_RESPONSE.toMediaType())
                .body(EmailSizeValidationResponse.newEmailSizeValidationResponse()
                        .results(results)
                        .level(results.isEmpty() ? ReportLevel.INFO : ReportLevel.ERROR).build());
    }
}
