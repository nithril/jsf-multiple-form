package com.victorbuckservices.vbackbone.service.compliance.validator.mail;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
@Component
public class MailAddressValidator {

    @Value("${mail.pattern}")
    private String MAIL_PATTERN;

    public boolean validate(String mailAddress){
        if (StringUtils.isBlank(mailAddress)){
            return false;
        }
        return Arrays.stream(StringUtils.split(mailAddress, '\n')).filter(StringUtils::isNotBlank).count() >= 3;
    }

}
