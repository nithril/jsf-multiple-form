package com.victorbuckservices.vbackbone.service.compliance.configuration;

import static com.google.common.collect.Lists.newArrayList;

import com.fasterxml.classmate.TypeResolver;
import com.fasterxml.classmate.types.ResolvedObjectType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;
import org.joda.time.LocalDate;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.AlternateTypeRules;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.schema.ModelBuilderPlugin;
import springfox.documentation.spi.schema.contexts.ModelContext;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.UiConfiguration;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Created on 25/03/2016
 *
 * @author labrot
 */
@Configuration
public class SwaggerConfiguration {

    @Autowired
    private TypeResolver typeResolver;

    private ApiKey apiKey() {
        return new ApiKey("mykey", "api_key", "header");
    }
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                .forPaths(PathSelectors.regex("/anyPath.*"))
                .build();
    }
    List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope
                = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return newArrayList(
                new SecurityReference("mykey", authorizationScopes));
    }
/*    @Bean
    SecurityConfiguration security() {
        return new SecurityConfiguration(
                "test-app-client-id",
                "test-app-client-secret",
                "test-app-realm",
                "test-app",
                "apiKey",
                ApiKeyVehicle.HEADER,
                "api_key",
                "," *//*scope separator*//*);
    }*/

    @Bean
    public UiConfiguration uiConfig() {
        return new UiConfiguration(
                "validatorUrl",// url
                "none",       // docExpansion          => none | list
                "alpha",      // apiSorter             => alpha
                "schema",     // defaultModelRendering => schema
                false,        // enableJsonEditor      => true | false
                true);        // showRequestHeaders    => true | false
    }


    interface MixIn {
        @JsonIgnore
        int getCallbacks(); // we don't need it!
    }


    @Bean
    public ModelBuilderPlugin modelBuilderPlugin() {

        return new ModelBuilderPlugin() {
            @Override
            public void apply(ModelContext context) {
                try {

                    if (context.getType() instanceof ResolvedObjectType) {
                        Class<?> erasedType = ((ResolvedObjectType) context.getType()).getErasedType();

                        Object mock = Mockito.mock(erasedType);

                        for (Method method : erasedType.getMethods()) {
                            if (method.getName().startsWith("get") && !method.getName().startsWith("getCallback")) {
                                if (String.class.isAssignableFrom(method.getReturnType())) {
                                    Mockito.when(method.invoke(mock)).thenReturn("");
                                }
                                if (ImmutableSet.class.isAssignableFrom(method.getReturnType())) {
                                    Mockito.when(method.invoke(mock)).thenReturn(ImmutableSet.of());
                                }

                            }

                        }

                        ObjectMapper mapper = new ObjectMapper();

                        mapper.addMixIn(erasedType, MixIn.class);
                        //mapper.configure(MapperFeature.AUTO_DETECT_GETTERS,false);


                        context.getBuilder().example(mapper.writeValueAsString(mock));


                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            @Override
            public boolean supports(DocumentationType documentationType) {
                return true;
            }
        };
    }

    @Bean
    public Docket petApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.victorbuckservices.vbackbone.service.compliance"))
                .paths(PathSelectors.any())
                .build()
                .pathMapping("/")
                .directModelSubstitute(LocalDate.class,
                        String.class)
                //.genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(
                        AlternateTypeRules.newRule(typeResolver.resolve(DeferredResult.class,
                                typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
                                typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET,
                        newArrayList(new ResponseMessageBuilder()
                                .code(500)
                                .message("500 message")
                                .responseModel(new ModelRef("Error"))
                                .build()))
                //.securitySchemes(newArrayList(apiKey()))
                //.securityContexts(newArrayList(securityContext()))
                .enableUrlTemplating(true)
                .tags(new Tag("Pet Service", "All apis relating to pets"))
                ;
    }

}
