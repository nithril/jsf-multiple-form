package com.victorbuckservices.vbackbone.service.compliance;

import com.victorbuckservices.vbackbone.common.configuration.UuidGeneratorConfiguration;
import com.victorbuckservices.vbackbone.common.storagekeeper.configuration.StorageKeeperConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication(exclude = {VelocityAutoConfiguration.class, FreeMarkerAutoConfiguration.class})
@Import({StorageKeeperConfiguration.class,
        UuidGeneratorConfiguration.class})
@EnableSwagger2
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
