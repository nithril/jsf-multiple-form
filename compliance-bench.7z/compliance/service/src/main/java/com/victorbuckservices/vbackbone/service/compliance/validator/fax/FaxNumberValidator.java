package com.victorbuckservices.vbackbone.service.compliance.validator.fax;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by nlabrot on 31/10/15.
 */
@Component
public class FaxNumberValidator {

    @Value("${fax.pattern}")
    private String faxPattern;

    public boolean validate(String faxNumber){

        Pattern pattern = Pattern.compile(faxPattern, Pattern.COMMENTS);
        Matcher matcher = pattern.matcher(faxNumber);
        return matcher.matches();
    }

}
