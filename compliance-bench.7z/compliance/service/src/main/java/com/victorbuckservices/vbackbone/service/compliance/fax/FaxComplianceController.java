package com.victorbuckservices.vbackbone.service.compliance.fax;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_FAX_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_FAX_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.FAX_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumberValidationResponse.newFaxNumberValidationResponse;
import static com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationResponse.newFaxNumbersValidationResponse;
import static org.springframework.http.ResponseEntity.badRequest;
import static org.springframework.http.ResponseEntity.ok;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumberValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.validator.fax.FaxNumberValidator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RestController
@RequestMapping("/ws/v1")
public class FaxComplianceController {

    private static final Logger LOG = LoggerFactory.getLogger(FaxComplianceController.class);

    @Autowired
    private FaxNumberValidator faxNumberValidator;

    @RequestMapping(value = "compliance/faxes/fax-numbers/{faxNumber}", method = RequestMethod.GET)
    public ResponseEntity validateGet(@PathVariable("faxNumber") String faxNumber) {

        FaxNumberValidationResponse validationResponse = validate(faxNumber);

        if (validationResponse.getLevel() == ReportLevel.INFO) {
            LOG.debug("[INFO] validateGet [faxNumber={}] => OK", faxNumber);
            return ok().contentType(FAX_RESPONSE.toMediaType()).body(validationResponse);
        } else {
            LOG.warn("[WARNING] validateGet [faxNumber={}] => NOK", faxNumber);
            return badRequest().contentType(FAX_RESPONSE.toMediaType()).body(validationResponse);
        }
    }

    @RequestMapping(value = "compliance/faxes/fax-numbers/{faxNumber}", method = RequestMethod.HEAD)
    public ResponseEntity validateHead(@PathVariable("faxNumber") String faxNumber) {

        if (validate(faxNumber).getLevel() == ReportLevel.INFO) {
            LOG.debug("[INFO] validateHead [faxNumber={}] => OK", faxNumber);
            return ok().build();
        } else {
            LOG.warn("[WARNING] validateHead [faxNumber={}] => NOK", faxNumber);
            return badRequest().build();
        }
    }


    @RequestMapping(value = "compliance/faxes/fax-numbers", method = RequestMethod.POST, consumes = BATCH_FAX_REQUEST_VALUE)
    public ResponseEntity validates(@RequestBody FaxNumbersValidationRequest request) {

        LOG.debug("[INFO] validates [faxNumbers={}]", StringUtils.join(request.getFaxNumbers(), ", "));

        List<FaxNumberValidationResponse> results = request.getFaxNumbers().stream()
                .filter(n -> !faxNumberValidator.validate(n))
                .map(n -> newFaxNumberValidationResponse().faxNumber(n).level(ReportLevel.ERROR).result("Invalid fax number [" + n + "]").build())
                .collect(Collectors.toList());

        return ok()
                .contentType(BATCH_FAX_RESPONSE.toMediaType())
                .body(newFaxNumbersValidationResponse()
                        .results(results)
                        .level(results.isEmpty() ? ReportLevel.INFO : ReportLevel.ERROR).build());
    }


    private FaxNumberValidationResponse validate(String number) {
        FaxNumberValidationResponse.Builder builder = newFaxNumberValidationResponse();

        if (!faxNumberValidator.validate(number)) {
            builder.level(ReportLevel.ERROR).faxNumber(number).result("Invalid fax number [" + number + "]");
        } else {
            builder.level(ReportLevel.INFO).faxNumber(number).result("");
        }
        return builder.build();
    }

}
