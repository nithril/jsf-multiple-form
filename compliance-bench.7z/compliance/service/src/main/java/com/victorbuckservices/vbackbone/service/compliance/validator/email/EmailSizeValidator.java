package com.victorbuckservices.vbackbone.service.compliance.validator.email;

import com.victorbuckservices.vbackbone.common.storagekeeper.StorageKeeper;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@Component
public class EmailSizeValidator {

    private static final Logger LOG = LoggerFactory.getLogger(EmailSizeValidator.class);

    @Autowired
    private StorageKeeper storageKeeper;

    @Value("${email.size.limit}")
    private long emailSizeLimit;

    public boolean validate(EmailMessage emailMessage) {

        double emailSizeInMb = 0;

        try {
            emailSizeInMb = getEmailResourcesSize(emailMessage) / (1024 * 1024);
            LOG.debug("[DEBUG] emailSizeInMb = {}",emailSizeInMb);
        } catch (IOException e) {
            LOG.error("[ERROR] Cannot retrieve email size",e);
            return false;
        }

        return ( emailSizeInMb <= emailSizeLimit) ? true : false;
    }

    private double getEmailResourcesSize(EmailMessage emailMessage) throws IOException {

        String emailBodyUri = emailMessage.getEmailBodyUri();
        Resource emailBody = storageKeeper.getResource(emailBodyUri);
        if(!emailBody.exists()) {
            throw new IOException("Unable to find String [" + emailBodyUri + "]");
        }
        double totalSize = emailBody.contentLength();

        for ( String attachmentUri : emailMessage.getAttachmentsUri()) {
            Resource attachment = storageKeeper.getResource(attachmentUri);
            if(!attachment.exists()) {
                throw new IOException("Unable to find String [" + attachmentUri + "]");
            }
            totalSize += attachment.contentLength();
        }

        return totalSize;
    }
}
