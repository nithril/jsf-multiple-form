package com.victorbuckservices.vbackbone.service.compliance.mail;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_MAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_MAIL_ADDRESS_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressValidationResponse.newMailAddressValidationResponse;
import static com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationResponse.newMailAddressesValidationResponse;
import static org.springframework.http.ResponseEntity.ok;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.validator.mail.MailAddressValidator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
@RestController
@RequestMapping("/ws/v1")
public class MailComplianceController {

    private static final Logger LOG = LoggerFactory.getLogger(MailComplianceController.class);

    @Autowired
    private MailAddressValidator mailAddressValidator;


    @RequestMapping(value = "compliance/mails/addresses", method = RequestMethod.POST, consumes = BATCH_MAIL_ADDRESS_REQUEST_VALUE)
    public ResponseEntity validates(@RequestBody MailAddressesValidationRequest request) {

        LOG.debug("[INFO] validates [mailAddresses={}]", StringUtils.join(request.getMailAddresses(), ", "));

        List<MailAddressValidationResponse> results = request.getMailAddresses().stream()
                .filter(n -> !mailAddressValidator.validate(n))
                .map(n -> newMailAddressValidationResponse().mailAddress(n).level(ReportLevel.ERROR).result("Invalid postal address [" + n + "]").build())
                .collect(Collectors.toList());

        return ok()
                .contentType(BATCH_MAIL_ADDRESS_RESPONSE.toMediaType())
                .body(newMailAddressesValidationResponse()
                        .results(results)
                        .level(results.isEmpty() ? ReportLevel.INFO : ReportLevel.ERROR).build());
    }
}
