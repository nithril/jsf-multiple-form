package com.victorbuckservices.vbackbone.service.compliance.validator.email;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by nlabrot on 31/10/15.
 */
@Component
public class FromAddressValidator {

    @Value("${email.from.pattern}")
    private String fromPattern;

    public boolean validate(String emailAddress){
        return emailAddress.matches(fromPattern);
    }

}
