package com.victorbuckservices.vbackbone.service.compliance.email;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_ADDRESS_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.EMAIL_ADDRESS_RESPONSE;
import static org.springframework.http.ResponseEntity.badRequest;
import static org.springframework.http.ResponseEntity.ok;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.validator.email.FromAddressValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RestController
@RequestMapping("/ws/v1")
public class FromComplianceController {

    @Autowired
    private FromAddressValidator fromAddressValidator;

    @RequestMapping(value = "compliance/emails/froms/{from:.*}", method = RequestMethod.GET)
    public ResponseEntity validateGet(@PathVariable("from") String from) {

        EmailAddressValidationResponse validationResponse = validate(from);

        if (validationResponse.getLevel() == ReportLevel.INFO) {
            return ok().contentType(EMAIL_ADDRESS_RESPONSE.toMediaType()).body(validationResponse);
        } else {
            return badRequest().contentType(EMAIL_ADDRESS_RESPONSE.toMediaType()).body(validationResponse);
        }
    }

    @RequestMapping(value = "compliance/emails/froms/{from:.*}", method = RequestMethod.HEAD)
    public ResponseEntity validateHead(@PathVariable("from") String from) {

        EmailAddressValidationResponse validationResponse = validate(from);

        if (validationResponse.getLevel() == ReportLevel.INFO) {
            return ok().build();
        } else {
            return badRequest().build();
        }
    }


    @RequestMapping(value = "compliance/emails/froms", method = RequestMethod.POST, consumes = BATCH_EMAIL_ADDRESS_REQUEST_VALUE)
    public ResponseEntity validates(@RequestBody EmailAddressesValidationRequest request) {

        List<EmailAddressValidationResponse> results = request.getEmailAddresses().stream()
                .filter(n -> !fromAddressValidator.validate(n))
                .map(n -> EmailAddressValidationResponse.newEmailAddressValidationResponse().emailAddress(n).level(ReportLevel.ERROR).result("Invalid from value [" + n + "]").build())
                .collect(Collectors.toList());

        return ok()
                .contentType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                .body(EmailAddressesValidationResponse.newEmailAddressesValidationResponse()
                        .results(results)
                        .level(results.isEmpty() ? ReportLevel.INFO : ReportLevel.ERROR).build());
    }


    private EmailAddressValidationResponse validate(String from) {
        EmailAddressValidationResponse.Builder builder = EmailAddressValidationResponse.newEmailAddressValidationResponse();
        if (!fromAddressValidator.validate(from)) {
            builder.emailAddress(from).level(ReportLevel.ERROR).result("Invalid from value [" + from + "]").build();
        } else {
            builder.level(ReportLevel.INFO).emailAddress(from).result("");
        }
        return builder.build();
    }
}
