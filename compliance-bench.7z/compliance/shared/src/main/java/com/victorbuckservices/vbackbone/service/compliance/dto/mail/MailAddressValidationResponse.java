package com.victorbuckservices.vbackbone.service.compliance.dto.mail;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_MailAddressValidationResponse.Builder.class)
public abstract class MailAddressValidationResponse {

    public static MailAddressValidationResponse.Builder newMailAddressValidationResponse() {
        return new AutoValue_MailAddressValidationResponse.Builder();
    }

    public abstract String getMailAddress();
    public abstract String getResult();
    public abstract ReportLevel getLevel();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder mailAddress(String s);
        public abstract Builder result(String s);
        public abstract Builder level(ReportLevel level);
        public abstract MailAddressValidationResponse build();
    }
}
