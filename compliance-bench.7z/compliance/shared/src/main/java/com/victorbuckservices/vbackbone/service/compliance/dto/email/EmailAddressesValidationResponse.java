package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

import java.util.List;
import java.util.stream.Stream;

/**
 * Created by nlabrot on 31/10/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailAddressesValidationResponse.Builder.class)
public abstract class EmailAddressesValidationResponse {

    public static EmailAddressesValidationResponse.Builder newEmailAddressesValidationResponse() {
        return new AutoValue_EmailAddressesValidationResponse.Builder();
    }

    public abstract List<EmailAddressValidationResponse> getResults();

    public abstract ReportLevel getLevel();

    public Stream<EmailAddressValidationResponse> filterResultsAboveLevel(ReportLevel level){
        return getResults().stream().filter(v -> v.getLevel().levelAsInt() > level.levelAsInt());
    }

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public interface Builder {
        Builder results(List<EmailAddressValidationResponse> s);
        Builder level(ReportLevel level);
        EmailAddressesValidationResponse build();
    }
}
