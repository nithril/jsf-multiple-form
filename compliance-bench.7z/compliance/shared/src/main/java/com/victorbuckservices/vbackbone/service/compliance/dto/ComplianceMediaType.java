package com.victorbuckservices.vbackbone.service.compliance.dto;

import java.util.Arrays;

import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumberValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationResponse;
import org.springframework.http.MediaType;

import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Created by nlabrot on 01/11/15.
 */
public enum ComplianceMediaType implements VbbMimeType {

    BATCH_FAX_REQUEST(Constants.BATCH_FAX_REQUEST_VALUE, Void.class),
    BATCH_FAX_RESPONSE(Constants.BATCH_FAX_RESPONSE_VALUE, FaxNumbersValidationResponse.class),
    FAX_RESPONSE(Constants.FAX_RESPONSE_VALUE, FaxNumberValidationResponse.class),

    BATCH_MAIL_ADDRESS_REQUEST(Constants.BATCH_MAIL_ADDRESS_REQUEST_VALUE, Void.class),
    BATCH_MAIL_ADDRESS_RESPONSE(Constants.BATCH_MAIL_ADDRESS_RESPONSE_VALUE, MailAddressesValidationResponse.class),
    MAIL_ADDRESS_RESPONSE(Constants.MAIL_ADDRESS_RESPONSE_VALUE, MailAddressesValidationResponse.class),

    BATCH_EMAIL_ADDRESS_REQUEST(Constants.BATCH_EMAIL_ADDRESS_REQUEST_VALUE, Void.class),
    BATCH_EMAIL_ADDRESS_RESPONSE(Constants.BATCH_EMAIL_ADDRESS_RESPONSE_VALUE, EmailAddressesValidationResponse.class),
    EMAIL_ADDRESS_RESPONSE(Constants.EMAIL_ADDRESS_RESPONSE_VALUE, EmailAddressValidationResponse.class),

    BATCH_EMAIL_SIZE_REQUEST(Constants.BATCH_EMAIL_SIZE_REQUEST_VALUE, Void.class),
    BATCH_EMAIL_SIZE_RESPONSE(Constants.BATCH_EMAIL_SIZE_RESPONSE_VALUE, EmailSizeValidationResponse.class);


    private final String name;
    private final Class<?> contentClass;

    ComplianceMediaType(String name, Class<?> contentClass) {
        this.name = name;
        this.contentClass = contentClass;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Class<?> getContentClass() {
        return contentClass;
    }

    public static class Constants {
        public final static String BATCH_FAX_REQUEST_VALUE = "application/vnd.vbs.vbackbone.compliance.fax.batch-request-1.0+json;charset=UTF-8;v=1.0";
        public final static String BATCH_FAX_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.fax.batch-response-1.0+json;charset=UTF-8;v=1.0";
        public final static String FAX_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.fax.response-1.0+json;charset=UTF-8;v=1.0";

        public final static String BATCH_MAIL_ADDRESS_REQUEST_VALUE = "application/vnd.vbs.vbackbone.compliance.mail.address.batch-request-1.0+json;charset=UTF-8;v=1.0";
        public final static String BATCH_MAIL_ADDRESS_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.mail.address.batch-response-1.0+json;charset=UTF-8;v=1.0";
        public final static String MAIL_ADDRESS_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.mail.address.response-1.0+json;charset=UTF-8;v=1.0";

        public final static String BATCH_EMAIL_ADDRESS_REQUEST_VALUE = "application/vnd.vbs.vbackbone.compliance.email.address.batch-request-1.0+json;charset=UTF-8;v=1.0";
        public final static String BATCH_EMAIL_ADDRESS_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.email.address.batch-response-1.0+json;charset=UTF-8;v=1.0";
        public final static String EMAIL_ADDRESS_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.email.address.response-1.0+json;charset=UTF-8;v=1.0";

        public final static String BATCH_EMAIL_SIZE_REQUEST_VALUE = "application/vnd.vbs.vbackbone.compliance.email.size.batch-request-1.0+json;charset=UTF-8;v=1.0";
        public final static String BATCH_EMAIL_SIZE_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.email.size.batch-response-1.0+json;charset=UTF-8;v=1.0";
        public final static String EMAIL_SIZE_RESPONSE_VALUE = "application/vnd.vbs.vbackbone.compliance.email.size.response-1.0+json;charset=UTF-8;v=1.0";
    }

    public MediaType toMediaType() {
        return MediaType.valueOf(getName());
    }


    public static ComplianceMediaType findByMediaType(String mediaType) {
        return Arrays.stream(values()).filter(c -> c.toMediaType().isCompatibleWith(MediaType.valueOf(mediaType))).findFirst().orElse(null);
    }
}
