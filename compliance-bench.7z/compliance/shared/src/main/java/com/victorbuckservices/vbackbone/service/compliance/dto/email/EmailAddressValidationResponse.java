package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

/**
 * Created by nlabrot on 31/10/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailAddressValidationResponse.Builder.class)
public abstract class EmailAddressValidationResponse {

    public static EmailAddressValidationResponse.Builder newEmailAddressValidationResponse() {
        return new AutoValue_EmailAddressValidationResponse.Builder();
    }

    public abstract String getEmailAddress();
    public abstract String getResult();
    public abstract ReportLevel getLevel();


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder emailAddress(String s);
        public abstract Builder result(String s);
        public abstract Builder level(ReportLevel level);
        public abstract EmailAddressValidationResponse build();
    }
}
