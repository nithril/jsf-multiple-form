package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

import java.util.List;
import java.util.stream.Stream;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailSizeValidationResponse.Builder.class)
public abstract class EmailSizeValidationResponse {

    public static EmailSizeValidationResponse.Builder newEmailSizeValidationResponse() {
        return new AutoValue_EmailSizeValidationResponse.Builder();
    }

    public abstract List<EmailSizeValidationResult> getResults();

    public abstract ReportLevel getLevel();

    public Stream<EmailSizeValidationResult> filterResultsAboveLevel(ReportLevel level){
        return getResults().stream().filter(v -> v.getLevel().levelAsInt() > level.levelAsInt());
    }

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public interface Builder {
        Builder results(List<EmailSizeValidationResult> s);
        Builder level(ReportLevel level);
        EmailSizeValidationResponse build();
    }
}
