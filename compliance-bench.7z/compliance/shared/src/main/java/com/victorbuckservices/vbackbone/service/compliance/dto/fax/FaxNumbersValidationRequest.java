package com.victorbuckservices.vbackbone.service.compliance.dto.fax;

import java.util.Collection;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.google.common.collect.ImmutableSet;

/**
 * Created by nlabrot on 31/10/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_FaxNumbersValidationRequest.Builder.class)
public abstract class FaxNumbersValidationRequest {

    public static FaxNumbersValidationRequest.Builder newFaxNumbersValidationRequest() {
        return new AutoValue_FaxNumbersValidationRequest.Builder();
    }

    public abstract ImmutableSet<String> getFaxNumbers();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder faxNumbers(Collection<String> s);
        public abstract FaxNumbersValidationRequest build();
    }
}
