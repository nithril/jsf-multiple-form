package com.victorbuckservices.vbackbone.service.compliance.dto.mail;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

import java.util.List;
import java.util.stream.Stream;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_MailAddressesValidationResponse.Builder.class)
public abstract class MailAddressesValidationResponse {

    public static MailAddressesValidationResponse.Builder newMailAddressesValidationResponse() {
        return new AutoValue_MailAddressesValidationResponse.Builder();
    }

    public abstract List<MailAddressValidationResponse> getResults();

    public abstract ReportLevel getLevel();

    public Stream<MailAddressValidationResponse> filterResultsAboveLevel(ReportLevel level){
        return getResults().stream().filter(v -> v.getLevel().levelAsInt() > level.levelAsInt());
    }


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder results(List<MailAddressValidationResponse> s);
        public abstract Builder level(ReportLevel level);
        public abstract MailAddressesValidationResponse build();
    }
}
