package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.google.common.collect.ImmutableSet;

import java.io.File;
import java.util.Collection;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailSizeValidationRequest.Builder.class)
public abstract class EmailSizeValidationRequest {

    public static EmailSizeValidationRequest.Builder newEmailSizeValidationRequest() {
        return new AutoValue_EmailSizeValidationRequest.Builder();
    }

    public abstract ImmutableSet<EmailMessage> getEmailMessages();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder emailMessages(Collection<EmailMessage> f);
        public abstract EmailSizeValidationRequest build();
    }
}
