package com.victorbuckservices.vbackbone.service.compliance.dto.fax;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

/**
 * Created by nlabrot on 31/10/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_FaxNumberValidationResponse.Builder.class)
public abstract class FaxNumberValidationResponse {

    public static FaxNumberValidationResponse.Builder newFaxNumberValidationResponse() {
        return new AutoValue_FaxNumberValidationResponse.Builder();
    }

    public abstract String getFaxNumber();
    public abstract String getResult();
    public abstract ReportLevel getLevel();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder faxNumber(String s);
        public abstract Builder result(String s);
        public abstract Builder level(ReportLevel level);
        public abstract FaxNumberValidationResponse build();
    }
}
