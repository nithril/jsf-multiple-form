package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import java.util.Collection;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.google.common.collect.ImmutableSet;

/**
 * Created by nlabrot on 31/10/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailAddressesValidationRequest.Builder.class)
public abstract class EmailAddressesValidationRequest {

    public static EmailAddressesValidationRequest.Builder newEmailAddressesValidationRequest() {
        return new AutoValue_EmailAddressesValidationRequest.Builder();
    }

    public abstract ImmutableSet<String> getEmailAddresses();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder emailAddresses(Collection<String> s);
        public abstract EmailAddressesValidationRequest build();
    }
}
