package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.Validate;

import java.util.Collection;
import java.util.Collections;
import javax.annotation.Nonnull;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
public class EmailMessage {

    private String emailBodyUri;
    private Collection<String> attachmentsUri = Collections.emptyList();

    public EmailMessage() {
    }

    public EmailMessage(@Nonnull String emailBodyUri, @Nonnull Collection<String> attachmentsUri) {
        Validate.notNull(emailBodyUri);
        Validate.notNull(attachmentsUri);
        this.emailBodyUri = emailBodyUri;
        this.attachmentsUri = attachmentsUri;
    }

    /**
     * Getter for property 'emailBodyUri'.
     *
     * @return Value for property 'emailBodyUri'.
     */
    public String getEmailBodyUri() {
        return emailBodyUri;
    }

    /**
     * Setter for property 'emailBodyUri'.
     *
     * @param emailBodyUri Value to set for property 'emailBodyUri'.
     */
    public void setEmailBodyUri(String emailBodyUri) {
        this.emailBodyUri = emailBodyUri;
    }

    /**
     * Getter for property 'attachmentsUri'.
     *
     * @return Value for property 'attachmentsUri'.
     */
    public Collection<String> getAttachmentsUri() {
        return attachmentsUri;
    }

    /**
     * Setter for property 'attachmentsUri'.
     *
     * @param attachmentsUri Value to set for property 'attachmentsUri'.
     */
    public void setAttachmentsUri(Collection<String> attachmentsUri) {
        this.attachmentsUri = attachmentsUri;
    }

    @Override
    public String toString() {
        return "EmailMessage{" +
                ", emailBodyUri=" + emailBodyUri +
                ", attachmentsUri=" + StringUtils.join(attachmentsUri, ", ") +
                '}';
    }
}
