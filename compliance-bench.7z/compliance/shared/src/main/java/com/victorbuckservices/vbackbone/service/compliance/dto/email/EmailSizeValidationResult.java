package com.victorbuckservices.vbackbone.service.compliance.dto.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.victorbuckservices.common.utils.report.ReportLevel;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_EmailSizeValidationResult.Builder.class)
public abstract class EmailSizeValidationResult {

    public static EmailSizeValidationResult.Builder newEmailSizeValidationResult() {
        return new AutoValue_EmailSizeValidationResult.Builder();
    }

    public abstract EmailMessage getEmailMessage();
    public abstract String getResult();
    public abstract ReportLevel getLevel();


    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder emailMessage(EmailMessage e);
        public abstract Builder result(String s);
        public abstract Builder level(ReportLevel level);
        public abstract EmailSizeValidationResult build();
    }
}
