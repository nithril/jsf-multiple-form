package com.victorbuckservices.vbackbone.service.compliance.email.from;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressesData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RunWith(Parameterized.class)
public class ValidateFromTest extends AbstractTest {

    @Parameterized.Parameter(0)
    public TestData testData;


    @Parameterized.Parameters(name = "{index}: testUnitary({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {
        return EmailAddressesData.getUnitaryEmailData().stream().map(d -> new Object[]{d}).collect(Collectors.toList());
    }


    @Test
    public void test() throws Exception {
        mockUnitary(testData);
        CompletableFuture<Boolean> response = emailAddressComplianceClient.validateAddress((String) testData.getData().get("email"));
        Assert.assertEquals(mapper.readTree(testData.getClientResultContent()), mapper.valueToTree(response.get()));
    }

}
