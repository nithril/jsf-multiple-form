package com.victorbuckservices.vbackbone.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Stopwatch;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.exception.EmailValidationException;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.groovy.template.GroovyTemplateAutoConfiguration;
import org.springframework.boot.autoconfigure.velocity.VelocityAutoConfiguration;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created on 25/04/2016
 *
 * @author labrot
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {BenchmarkTest.MyConf.class, ComplianceClientConfiguration.class}
)
@ActiveProfiles({
        "production"
})
@TestPropertySource("classpath:/test.properties")
@Ignore
public class BenchmarkTest {

    private static final Logger LOG = LoggerFactory.getLogger(BenchmarkTest.class);
    @EnableAutoConfiguration(exclude = {
            FreeMarkerAutoConfiguration.class,
            GroovyTemplateAutoConfiguration.class,
            VelocityAutoConfiguration.class
    })
    @Configuration
    public static class MyConf {

        @Bean
        public ObjectMapper objectMapper(){
            return new ObjectMapper();
        }

    }

    @Autowired
    private EmailAddressComplianceClient complianceClient;

    @Test
    public void testFuture() throws Exception {

        LOG.info("start request");

        complianceClient
                .validateAddress("foo@bar.com")
                .thenAccept(r -> {
                    LOG.info("{}" , r);
                });

        LOG.info("end request");

        Thread.sleep(10000);
    }




    @Test
    public void testAsync() throws Exception {

        List<String> list = new ObjectMapper().readValue(getClass().getResourceAsStream("/benchmark.json"), List.class);//.subList(0,4000);

        Stopwatch stopwatch = Stopwatch.createStarted();

        List<CompletableFuture<Boolean>> futures = new ArrayList<>(list.size());

        for (String email : list) {
            futures.add(complianceClient.validateAddress(email));
        }



        //CompletableFuture.allOf(futures.toArray(new CompletableFuture[]{})).get();

        futures.forEach(f -> {
            try {
                f.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        });

        stopwatch.stop();

        System.out.println(list.size() / (stopwatch.elapsed(TimeUnit.MILLISECONDS)/1000.0f));


    }


    @Test
    public void testSync() throws Exception {

        List<String> list = new ObjectMapper().readValue(getClass().getResourceAsStream("/benchmark.json"), List.class);//.subList(0,3000);


        Stopwatch stopwatch = Stopwatch.createStarted();


        for (String email : list) {
            try {
                complianceClient.validateAddress(email).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EmailValidationException e) {
                e.printStackTrace();
            }
        }

        stopwatch.stop();

        System.out.println(list.size() / (stopwatch.elapsed(TimeUnit.MILLISECONDS)/1000.0f));


    }


}
