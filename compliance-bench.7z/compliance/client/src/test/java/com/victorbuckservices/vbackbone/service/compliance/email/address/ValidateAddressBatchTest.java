package com.victorbuckservices.vbackbone.service.compliance.email.address;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.victorbuckservices.vbackbone.service.compliance.AbstractTest;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressesData;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.springframework.test.annotation.Repeat;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Created by nlabrot on 31/10/15.
 */
@RunWith(Parameterized.class)

public class ValidateAddressBatchTest extends AbstractTest {

    @Parameterized.Parameter(0)
    public TestData testData;


    @Parameterized.Parameters(name = "{index}: testUnitary({0})")
    public static Collection<Object[]> data() throws JsonProcessingException {
        return EmailAddressesData.getBatchEmailData().stream()
                .filter(TestData::isClient)
                .map(d -> new Object[]{d}).collect(Collectors.toList());
    }


    @Test
    @Repeat(value = 2) // Cache test
    public void test() throws Exception {
        mockUnitary(testData);
        CompletableFuture<EmailAddressesValidationResponse> response = emailAddressComplianceClient.validateAddresses((Collection<String>) testData.getData().get("email"));
        Assert.assertEquals(mapper.readTree(testData.getClientResultContent()), mapper.valueToTree(response.get()));
    }

}
