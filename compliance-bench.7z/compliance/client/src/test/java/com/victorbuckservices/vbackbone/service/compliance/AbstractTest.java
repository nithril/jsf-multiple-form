package com.victorbuckservices.vbackbone.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailSizeComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.FaxComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.MailComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.TestData;
import com.victorbuckservices.vbackbone.service.compliance.configuration.ComplianceProperties;
import org.junit.ClassRule;
import org.junit.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;

//@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {TestConfiguration.class})
@TestPropertySource("classpath:/test.properties")
@ActiveProfiles("production")
public abstract class AbstractTest {

    @Autowired
    protected ObjectMapper mapper;

    @Autowired
    protected FaxComplianceClient faxComplianceClient;

    @Autowired
    protected MailComplianceClient mailComplianceClient;

    @Autowired
    protected EmailAddressComplianceClient emailAddressComplianceClient;

    @Autowired
    protected EmailSizeComplianceClient emailSizeComplianceClient;

    @Autowired
    private ComplianceProperties complianceProperties;


    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8089); // No-args constructor defaults to port 8080

    @ClassRule
    public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();

    @Rule
    public final SpringMethodRule springMethodRule = new SpringMethodRule();


    protected void mockUnitary(TestData testData) {

        MappingBuilder request = WireMock.request(testData.getMethod().name(), WireMock.urlEqualTo(testData.getUrl()));

        if (testData.getRequestContent() != null){
            request.withRequestBody(WireMock.equalToJson(testData.getRequestContent()));
        }
        if (testData.getRequestMediaType() != null){
            request.withHeader("Content-Type", WireMock.equalTo(testData.getRequestMediaType().toString()));
        }

        ResponseDefinitionBuilder responseDefinitionBuilder = WireMock.aResponse().withStatus(testData.getStatus());

        if (testData.getResultMediaType() != null){
            responseDefinitionBuilder.withHeader("Content-Type", testData.getResultMediaType().toString());
        }

        if (testData.getServerResultContent() != null){
            responseDefinitionBuilder.withBody(testData.getServerResultContent());
        }
        WireMock.stubFor(request.willReturn(responseDefinitionBuilder));
    }

}
