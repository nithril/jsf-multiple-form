package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_ADDRESS_REQUEST_VALUE;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.victorbuckservices.vbackbone.service.compliance.ClientHelper;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import org.asynchttpclient.BoundRequestBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriTemplate;

import java.net.URI;
import java.time.Duration;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Created by nlabrot on 31/10/15.
 */
public class EmailFromComplianceClient {

    public static final String ADDRESS_UNITARY = "ws/v1/compliance/emails/addresses/{address}";
    public static final String ADDRESS_BATCH = "ws/v1/compliance/emails/addresses";

    public static final String FROM_UNITARY = "ws/v1/compliance/emails/froms/{from}";
    public static final String FROM_BATCH = "ws/v1/compliance/emails/froms";

    @Autowired
    private ClientHelper clientHelper;

    @Value("${compliance.email.from.cache.size:10000}")
    private int cacheSize = 10000;

    @Value("${compliance.email.from.cache.expireAfterAccess:P2D}")
    private String expireAfterAccess = "P2D";

    private Cache<String, Boolean> adressesCache;


    public EmailFromComplianceClient() {
        CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder().maximumSize(cacheSize);
        if (expireAfterAccess != null){
            builder.expireAfterAccess(Duration.parse(expireAfterAccess).toMillis(), TimeUnit.MILLISECONDS);
        }
        adressesCache = builder.build();
    }


    public CompletableFuture<EmailAddressesValidationResponse> validateFromWithReport(String from) {
        URI uri = new UriTemplate(clientHelper.getComplianceUrl() + FROM_UNITARY).expand(from);
        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareGet(uri.toString());

        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }

    public CompletableFuture<Boolean> validateFrom(String from) {
        URI uri = new UriTemplate(clientHelper.getComplianceUrl() + FROM_UNITARY).expand(from);
        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareHead(uri.toString());

        return requestBuilder.execute().toCompletableFuture().thenApply(input -> input.getStatusCode() == 200);
    }

    public CompletableFuture<EmailAddressesValidationResponse> validateFroms(Collection<String> froms) {
        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().preparePost(clientHelper.getComplianceUrl() + FROM_BATCH)
                .addHeader(HttpHeaders.CONTENT_TYPE, BATCH_EMAIL_ADDRESS_REQUEST_VALUE)
                .setBody(clientHelper.writeValueAsBytes(
                        EmailAddressesValidationRequest.newEmailAddressesValidationRequest()
                                .emailAddresses(froms)
                                .build()));
        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }
}
