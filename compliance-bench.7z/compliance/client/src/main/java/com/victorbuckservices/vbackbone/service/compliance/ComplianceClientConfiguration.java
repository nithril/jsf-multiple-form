package com.victorbuckservices.vbackbone.service.compliance;

import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailFromComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailSizeComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.FaxComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.MailComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.configuration.ComplianceProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Created by nlabrot on 01/11/15.
 */
@Configuration
@Profile("production")
public class ComplianceClientConfiguration {


    @Bean
    public ComplianceProperties complianceProperties(){
        return new ComplianceProperties();
    }

    @Bean
    public ClientHelper clientHelper(){
        return new ClientHelper();
    }

    @Bean
    public EmailAddressComplianceClient emailAddressComplianceClient(){
        return new EmailAddressComplianceClient();
    }

    @Bean
    public EmailFromComplianceClient emailFromComplianceClient(){
        return new EmailFromComplianceClient();
    }

    @Bean
    public EmailSizeComplianceClient emailSizeComplianceClient(){
        return new EmailSizeComplianceClient();
    }

    @Bean
    public FaxComplianceClient faxComplianceClient(){
        return new FaxComplianceClient();
    }

    @Bean
    public MailComplianceClient mailComplianceClient(){
        return new MailComplianceClient();
    }
}
