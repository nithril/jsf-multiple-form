package com.victorbuckservices.vbackbone.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.victorbuckservices.vbackbone.service.compliance.configuration.ComplianceProperties;
import com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClientConfig;
import org.asynchttpclient.Response;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * Created by nlabrot on 17/11/15.
 */
public class ClientHelper {

    private ObjectMapper objectMapper = new ObjectMapper();

    private AsyncHttpClient asyncHttpClient;

    @Autowired
    private ComplianceProperties complianceProperties;


    @PostConstruct
    public void init() {
        complianceProperties.getHttp().forEach((k,v) -> System.setProperty(k, v.toString()));
        asyncHttpClient = new DefaultAsyncHttpClient(new DefaultAsyncHttpClientConfig.Builder()
                .build());
    }

    @PreDestroy
    public void release() throws IOException {
        asyncHttpClient.close();
    }

    public <T> T transform(Response input) {
        ComplianceMediaType mediaType = ComplianceMediaType.findByMediaType(input.getContentType());
        if (mediaType != null){
            return readValue(input, (Class<T>)mediaType.getContentClass());
        } else {
            throw new RuntimeException();
        }
    }

    public <T> T readValue(Response content, Class<T> v) {
        try {
            return objectMapper.readValue(content.getResponseBody(), v);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public <T> byte[] writeValueAsBytes(T v) {
        try {
            return objectMapper.writeValueAsBytes(v);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String getComplianceUrl() {
        return complianceProperties.getUrl();
    }

    public AsyncHttpClient getAsyncHttpClient() {
        return asyncHttpClient;
    }

}
