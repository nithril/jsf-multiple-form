package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_MAIL_ADDRESS_REQUEST_VALUE;

import com.victorbuckservices.vbackbone.service.compliance.ClientHelper;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationResponse;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.asynchttpclient.BoundRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
public class MailComplianceClient {

    private static final Logger LOG = LoggerFactory.getLogger(MailComplianceClient.class);

    public static final String ADDRESS_BATCH = "ws/v1/compliance/mails/addresses";

    @Autowired
    private ClientHelper clientHelper;

    public CompletableFuture<MailAddressesValidationResponse> validateAddresses(Collection<String> addresses) {
        Validate.isTrue(CollectionUtils.isNotEmpty(addresses));

        LOG.debug("validateAddresses [addresses={}]", StringUtils.join(addresses.toArray(), ", "));

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().preparePost(clientHelper.getComplianceUrl() + ADDRESS_BATCH)
                .addHeader(HttpHeaders.CONTENT_TYPE, BATCH_MAIL_ADDRESS_REQUEST_VALUE)
                .setBody(clientHelper.writeValueAsBytes(
                        MailAddressesValidationRequest.newMailAddressesValidationRequest()
                                .mailAddresses(addresses)
                                .build()));

        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }
}
