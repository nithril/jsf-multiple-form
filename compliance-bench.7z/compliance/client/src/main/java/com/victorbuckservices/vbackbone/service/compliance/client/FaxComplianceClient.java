package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_FAX_REQUEST_VALUE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationRequest.newFaxNumbersValidationRequest;

import com.victorbuckservices.vbackbone.service.compliance.ClientHelper;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumberValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationResponse;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.asynchttpclient.BoundRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriTemplate;

import java.net.URI;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nonnull;

/**
 * Created by nlabrot on 31/10/15.
 */
public class FaxComplianceClient {

    private static final Logger LOG = LoggerFactory.getLogger(FaxComplianceClient.class);

    public static final String UNITARY = "ws/v1/compliance/faxes/fax-numbers/{faxNumber}";
    public static final String BATCH = "ws/v1/compliance/faxes/fax-numbers";

    @Autowired
    private ClientHelper clientHelper;

    public CompletableFuture<FaxNumberValidationResponse> validateWithReport(@Nonnull String faxNumber) {
        Validate.notNull(faxNumber);

        LOG.debug("[INFO] validateWithReport [faxNumber={}]", faxNumber);

        URI uri = new UriTemplate(clientHelper.getComplianceUrl() + UNITARY).expand(faxNumber);
        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareGet(uri.toString());
        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }

    public CompletableFuture<Boolean> validate(@Nonnull String faxNumber) {
        Validate.notNull(faxNumber);

        LOG.debug("[INFO] validate [faxNumber={}]", faxNumber);

        URI uri = new UriTemplate(clientHelper.getComplianceUrl() + UNITARY).expand(faxNumber);
        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareHead(uri.toString());

        return requestBuilder.execute().toCompletableFuture().thenApply(input -> input.getStatusCode() == 200);
    }


    public CompletableFuture<FaxNumbersValidationResponse> validates(Collection<String> faxNumbers) {
        Validate.isTrue(CollectionUtils.isNotEmpty(faxNumbers));

        LOG.debug("validates [faxNumbers={}]", StringUtils.join(faxNumbers.toArray(), ", "));

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().preparePost(clientHelper.getComplianceUrl() + BATCH)
                .addHeader(HttpHeaders.CONTENT_TYPE, BATCH_FAX_REQUEST_VALUE)
                .setBody(clientHelper.writeValueAsBytes(
                        newFaxNumbersValidationRequest()
                                .faxNumbers(faxNumbers)
                                .build()));

        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }
}
