package com.victorbuckservices.vbackbone.service.compliance.exception;

/**
 * @author Lardinois
 *         Created on 7/03/2016
 */
public class EmailValidationException extends Exception {

    String emailAddress;

    public EmailValidationException(String message, String emailAddress, Throwable cause) {
        super(message, cause);
        this.emailAddress = emailAddress;
    }

    public EmailValidationException(String message, String emailAddress) {
        super(message);
        this.emailAddress = emailAddress;
    }

    /**
     * Getter for property 'emailAddress'.
     *
     * @return Value for property 'emailAddress'.
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Setter for property 'emailAddress'.
     *
     * @param emailAddress Value to set for property 'emailAddress'.
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
