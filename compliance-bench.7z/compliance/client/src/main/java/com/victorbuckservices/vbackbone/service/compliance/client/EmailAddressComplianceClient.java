package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_ADDRESS_REQUEST_VALUE;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.hash.Hashing;
import com.victorbuckservices.vbackbone.service.compliance.ClientHelper;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationResponse;
import com.victorbuckservices.vbackbone.service.compliance.exception.EmailValidationException;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.asynchttpclient.BoundRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nonnull;

/**
 * Created by nlabrot on 31/10/15.
 */
public class EmailAddressComplianceClient {

    public static final String ADDRESS_UNITARY = "ws/v1/compliance/emails/addresses/";
    public static final String ADDRESS_BATCH = "ws/v1/compliance/emails/addresses";
    private static final Logger LOG = LoggerFactory.getLogger(EmailAddressComplianceClient.class);
    @Autowired
    private ClientHelper clientHelper;

    @Value("${compliance.email.address.cache.size:10000}")
    private int cacheSize = 10000;

    @Value("${compliance.email.address.cache.expireAfterAccess:P1D}")
    private String expireAfterAccess = "P1D";

    @Value("${compliance.email.address.cache.expireAfterWrite:P2D}")
    private String expireAfterWrite = "P2D";

    private Cache<String, Object> addressesCache;

    public EmailAddressComplianceClient() {
        CacheBuilder builder = CacheBuilder.newBuilder().maximumSize(cacheSize);
        if (expireAfterAccess != null) {
            builder.expireAfterAccess(Duration.parse(expireAfterAccess).toMillis(), TimeUnit.MILLISECONDS);
        }
        if (expireAfterWrite != null) {
            builder.expireAfterWrite(Duration.parse(expireAfterWrite).toMillis(), TimeUnit.MILLISECONDS);
        }
        addressesCache = builder.build();
    }

    public CompletableFuture<EmailAddressValidationResponse> validateAddressWithReport(@Nonnull String address) throws EmailValidationException {
        Validate.notNull(address);

        Object cachedResult = addressesCache.getIfPresent("validateAddressWithReport" + address);
        if (cachedResult != null) {
            LOG.debug("[INFO] validateAddressWithReport from cache [address={}]", address);
            return CompletableFuture.completedFuture((EmailAddressValidationResponse) cachedResult);
        }

        LOG.debug("[INFO] validateAddressWithReport [address={}]", address);

        String uri = null;
        try {
            uri = clientHelper.getComplianceUrl() + ADDRESS_UNITARY + UriUtils.encode(address, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOG.error("[ERROR] Cannot encode address for url [address={}]", address);
            throw new EmailValidationException("Cannot encode address for url", address, e);
        }

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareGet(uri.toString());

        return requestBuilder.execute().toCompletableFuture()
                .thenApply(clientHelper::transform)
                .thenApply(EmailAddressValidationResponse.class::cast)
                .thenApply(emailAddressValidationResponse -> {
                    addressesCache.put("validateAddressWithReport" + address, emailAddressValidationResponse);
                    return emailAddressValidationResponse;
                });
    }

    public CompletableFuture<Boolean> validateAddress(String address) throws EmailValidationException {

        Object cachedResult = addressesCache.getIfPresent("validateAddress" + address);

        if (cachedResult != null) {
            LOG.debug("validateAddress from cache [address={}]", address);
            return CompletableFuture.completedFuture((Boolean) cachedResult);
        }

        LOG.debug("validateAddress [address={}]", address);

        String uri = null;
        try {
            uri = clientHelper.getComplianceUrl() + ADDRESS_UNITARY + UriUtils.encode(address, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOG.error("[ERROR] Cannot encode address for url [address={}]", address);
            throw new EmailValidationException("Cannot encode address for url", address, e);
        }

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().prepareHead(uri.toString());

        return requestBuilder.execute().toCompletableFuture()
                .thenApply(input -> input.getStatusCode() == 200)
                .thenApply(r -> {
                    addressesCache.put("validateAddress" + address, r);
                    return r;
                });
    }

    public CompletableFuture<EmailAddressesValidationResponse> validateAddresses(Collection<String> addresses) {
        Validate.isTrue(CollectionUtils.isNotEmpty(addresses));

        String hashAddresses = addresses.stream()
                .reduce(Hashing.sha512().newHasher(), (h, s) -> h.putUnencodedChars(s), (h1, h2) -> h1)
                .hash().toString();

        Object cachedResult = addressesCache.getIfPresent(hashAddresses);

        if (cachedResult != null) {
            LOG.debug("validateAddresses from cache [addresses={}]", StringUtils.join(addresses.toArray(), ", "));
            return CompletableFuture.completedFuture((EmailAddressesValidationResponse) cachedResult);
        }

        LOG.debug("validateAddresses [addresses={}]", StringUtils.join(addresses.toArray(), ", "));

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().preparePost(clientHelper.getComplianceUrl() + ADDRESS_BATCH)
                .addHeader(HttpHeaders.CONTENT_TYPE, BATCH_EMAIL_ADDRESS_REQUEST_VALUE)
                .setBody(clientHelper.writeValueAsBytes(
                        EmailAddressesValidationRequest.newEmailAddressesValidationRequest()
                                .emailAddresses(addresses)
                                .build()));

        return requestBuilder.execute().toCompletableFuture()
                .thenApply(clientHelper::transform)
                .thenApply(EmailAddressesValidationResponse.class::cast)
                .thenApply(r -> {
                    addressesCache.put(hashAddresses, r);
                    return r;
                });
    }
}

