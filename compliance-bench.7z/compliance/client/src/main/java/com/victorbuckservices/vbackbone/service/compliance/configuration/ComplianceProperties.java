package com.victorbuckservices.vbackbone.service.compliance.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.annotation.PostConstruct;

/**
 * Created on 27/04/2016
 *
 * @author labrot
 */
@ConfigurationProperties(prefix = "compliance")
public class ComplianceProperties {

    private String url;

    private Map<String,Object> http = new HashMap<>();

    @Autowired
    private ResourceLoader resourceLoader;

    @PostConstruct
    public void init() throws IOException {

        try (InputStream is = resourceLoader.getResource("classpath:/config/compliance-default.properties").getInputStream()){
            Properties defaultProperties = new Properties();
            defaultProperties.load(is);
            defaultProperties.forEach((k, v) -> http.putIfAbsent(k.toString(),v));
        }

        if (!url.endsWith("/")) {
            url = url + "/";
        }
    }

    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public Map<String, Object> getHttp() {
        return http;
    }
    public void setHttp(Map<String, Object> http) {
        this.http = http;
    }
}