package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.Constants.BATCH_EMAIL_SIZE_REQUEST_VALUE;

import com.victorbuckservices.vbackbone.service.compliance.ClientHelper;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailMessage;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationRequest;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationResponse;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.apache.commons.lang3.StringUtils;
import org.asynchttpclient.BoundRequestBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nonnull;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
public class EmailSizeComplianceClient {

    private static final Logger LOG = LoggerFactory.getLogger(EmailSizeComplianceClient.class);

    public static final String EMAIL_SIZE_BATCH = "ws/v1/compliance/emails/size";

    @Autowired
    private ClientHelper clientHelper;

    public CompletableFuture<EmailSizeValidationResponse> validateEmailSize (@Nonnull Collection<EmailMessage> emailMessages) {

        Validate.notNull(emailMessages);

        LOG.debug("[INFO] validateEmailSize [address={}]", StringUtils.join(emailMessages.toString(), ",\n"));

        BoundRequestBuilder requestBuilder = clientHelper.getAsyncHttpClient().preparePost(clientHelper.getComplianceUrl() + EMAIL_SIZE_BATCH)
                .addHeader(HttpHeaders.CONTENT_TYPE, BATCH_EMAIL_SIZE_REQUEST_VALUE)
                .setBody(clientHelper.writeValueAsBytes(
                        EmailSizeValidationRequest.newEmailSizeValidationRequest()
                                .emailMessages(emailMessages)
                                .build()));

        return requestBuilder.execute().toCompletableFuture().thenApply(clientHelper::transform);
    }
}
