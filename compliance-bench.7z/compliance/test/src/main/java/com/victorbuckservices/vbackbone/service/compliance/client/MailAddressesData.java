package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_MAIL_ADDRESS_REQUEST;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_MAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.MAIL_ADDRESS_RESPONSE;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.victorbuckservices.vbackbone.service.compliance.dto.mail.MailAddressesValidationRequest;
import org.springframework.http.HttpMethod;

import java.util.Arrays;
import java.util.List;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
public class MailAddressesData {

    public static ObjectMapper mapper = (new ObjectMapper()).configure(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER, true);

    public static final List<TestData> getBatchMailData() throws JsonProcessingException {
        return Arrays.asList(
                TestData.newData().data(ImmutableMap.of("mail", Arrays.asList("aaa\nbbb\nccc","aaa\nbbb\nccc\n","\naaa\nbbb\nccc\n","\n\naaa\n\nbbb\n\nccc\n\n","Address Line 1\nAddress Line 2\nAddress Line 3\nAddress Line 4\nAddress Line 5\n"," a a \n b b \n c c \n")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/mails/addresses")
                        .requestMediaType(BATCH_MAIL_ADDRESS_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(MailAddressesValidationRequest.newMailAddressesValidationRequest().mailAddresses(Arrays.asList("aaa\nbbb\nccc","aaa\nbbb\nccc\n","\naaa\nbbb\nccc\n","\n\naaa\n\nbbb\n\nccc\n\n","Address Line 1\nAddress Line 2\nAddress Line 3\nAddress Line 4\nAddress Line 5\n"," a a \n b b \n c c \n")).build()))
                        .resultMediaType(BATCH_MAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"INFO\",\"results\":[]}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("mail", Arrays.asList("aaa","aaa\nbbb","aaa\nbbb\n\n")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/mails/addresses")
                        .requestMediaType(BATCH_MAIL_ADDRESS_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(MailAddressesValidationRequest.newMailAddressesValidationRequest().mailAddresses(Arrays.asList("aaa","aaa\nbbb","aaa\nbbb\n\n")).build()))
                        .resultMediaType(BATCH_MAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"ERROR\",\"results\":[{\"level\":\"ERROR\",\"mailAddress\":\"aaa\",\"result\":\"Invalid postal address [aaa]\"},{\"level\":\"ERROR\",\"mailAddress\":\"aaa\\nbbb\",\"result\":\"Invalid postal address [aaa\\nbbb]\"},{\"level\":\"ERROR\",\"mailAddress\":\"aaa\\nbbb\\n\\n\",\"result\":\"Invalid postal address [aaa\\nbbb\\n\\n]\"}]}")
                        .status(200).build(),
                TestData.newData().client(false)
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/mails/addresses")
                        .requestMediaType(BATCH_MAIL_ADDRESS_REQUEST.toMediaType())
                        .clientAndServerResultContent("")
                        .status(400).build()
        );
    }
}
