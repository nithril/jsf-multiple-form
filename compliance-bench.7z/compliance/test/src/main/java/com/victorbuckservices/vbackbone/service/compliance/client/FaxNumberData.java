package com.victorbuckservices.vbackbone.service.compliance.client;

import java.util.Arrays;
import java.util.List;

import com.victorbuckservices.vbackbone.service.compliance.dto.fax.FaxNumbersValidationRequest;
import org.springframework.http.HttpMethod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_FAX_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.FAX_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_FAX_REQUEST;

import static com.google.common.collect.Sets.newHashSet;

/**
 * Created by nlabrot on 26/11/15.
 */
public class FaxNumberData {

    public static ObjectMapper mapper = new ObjectMapper();

    public static final List<TestData> getUnitaryDataWithReport() {
        return Arrays.asList(
                TestData.newData().data(ImmutableMap.of("fax", "0012345"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0012345")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"0012345\",\"level\":\"INFO\",\"result\":\"\"}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+12345"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+12345")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"+12345\",\"level\":\"INFO\",\"result\":\"\"}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "0012345678901234567890123456"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0012345678901234567890123456")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"0012345678901234567890123456\",\"level\":\"INFO\",\"result\":\"\"}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+12345678901234567890123456"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+12345678901234567890123456")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"+12345678901234567890123456\",\"level\":\"INFO\",\"result\":\"\"}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "00123456789012345678901234567"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/00123456789012345678901234567")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"00123456789012345678901234567\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [00123456789012345678901234567]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+123456789012345678901234567"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+123456789012345678901234567")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"+123456789012345678901234567\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+123456789012345678901234567]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "0001234"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0001234")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"0001234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [0001234]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+01234"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+01234")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"+01234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+01234]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "001234"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/001234")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"001234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [001234]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+1234"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+1234")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"+1234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+1234]\"}")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "abc"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/faxes/fax-numbers/abc")
                        .resultMediaType(FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"faxNumber\":\"abc\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [abc]\"}")
                        .status(400).build()
        );
    }


    public static final List<TestData> getUnitaryData() {

        return Arrays.asList(
                TestData.newData().data(ImmutableMap.of("fax", "0012345"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0012345")
                        .clientResultContent("true")
                        .serverResultContent("")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+12345"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+12345")
                        .clientResultContent("true")
                        .serverResultContent("")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "0012345678901234567890123456"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0012345678901234567890123456")
                        .clientResultContent("true")
                        .serverResultContent("")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+12345678901234567890123456"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+12345678901234567890123456")
                        .clientResultContent("true")
                        .serverResultContent("")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", "00123456789012345678901234567"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/00123456789012345678901234567")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+123456789012345678901234567"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+123456789012345678901234567")
                        .clientResultContent("false")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "0001234"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/0001234")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+01234"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+01234")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "001234"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/001234")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "+1234"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/+1234")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build(),
                TestData.newData().data(ImmutableMap.of("fax", "abc"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/faxes/fax-numbers/abc")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build()
        );
    }



    public static final List<TestData> getBatchData() throws JsonProcessingException {
        return Arrays.asList(
                TestData.newData().data(ImmutableMap.of("fax", newHashSet("0012345","+12345","0012345678901234567890123456","+12345678901234567890123456")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/faxes/fax-numbers")
                        .requestMediaType(BATCH_FAX_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(FaxNumbersValidationRequest.newFaxNumbersValidationRequest().faxNumbers(newHashSet("0012345","+12345","0012345678901234567890123456","+12345678901234567890123456")).build()))
                        .resultMediaType(BATCH_FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"INFO\",\"results\":[]}")
                        .status(200).build(),
                TestData.newData().data(ImmutableMap.of("fax", newHashSet("00123456789012345678901234567","+123456789012345678901234567","0001234","+01234","001234","+1234","abc")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/faxes/fax-numbers")
                        .requestMediaType(BATCH_FAX_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(FaxNumbersValidationRequest.newFaxNumbersValidationRequest().faxNumbers(newHashSet("00123456789012345678901234567","+123456789012345678901234567","0001234","+01234","001234","+1234","abc")).build()))
                        .resultMediaType(BATCH_FAX_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"ERROR\",\"results\":[{\"faxNumber\":\"abc\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [abc]\"},{\"faxNumber\":\"00123456789012345678901234567\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [00123456789012345678901234567]\"},{\"faxNumber\":\"001234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [001234]\"},{\"faxNumber\":\"+123456789012345678901234567\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+123456789012345678901234567]\"},{\"faxNumber\":\"+1234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+1234]\"},{\"faxNumber\":\"+01234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [+01234]\"},{\"faxNumber\":\"0001234\",\"level\":\"ERROR\",\"result\":\"Invalid fax number [0001234]\"}]}")
                        .status(200).build(),
                TestData.newData().client(false)
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/faxes/fax-numbers")
                        .requestMediaType(BATCH_FAX_REQUEST.toMediaType())
                        .clientAndServerResultContent("")
                        .status(400).build()

        );
    }
}
