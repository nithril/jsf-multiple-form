package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.google.common.io.Resources.getResource;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_SIZE_REQUEST;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_SIZE_RESPONSE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailMessage;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailSizeValidationRequest;
import org.springframework.http.HttpMethod;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * @author Lardinois
 *         Created on 4/03/2016
 */
public class EmailSizeData {

    public static String testEmailBodyUri = getResource("email/testEmailBody.txt").toString();
    public static String testEmailAttachmentUri_1 = getResource("email/sample-document-1.pdf").toString();
    public static String testEmailAttachmentUri_2 = getResource("email/sample-document-2.pdf").toString();

    public static ObjectMapper mapper = new ObjectMapper();

    public static final List<TestData> getBatchEmailSizeData() throws JsonProcessingException {
        return Arrays.asList(
            TestData.newData().data(ImmutableMap.of("email", (Collection<EmailMessage>) Arrays.asList(new EmailMessage(testEmailBodyUri, Arrays.asList(testEmailAttachmentUri_1)))))
                    .method(HttpMethod.POST)
                    .url("/ws/v1/compliance/emails/size")
                    .requestMediaType(BATCH_EMAIL_SIZE_REQUEST.toMediaType())
                    .requestContent(mapper.writeValueAsString(EmailSizeValidationRequest.newEmailSizeValidationRequest().emailMessages(Arrays.asList(new EmailMessage(testEmailBodyUri, Arrays.asList(testEmailAttachmentUri_1)))).build()))
                    .resultMediaType(BATCH_EMAIL_SIZE_RESPONSE.toMediaType())
                    .clientAndServerResultContent("{\"level\":\"INFO\",\"results\":[]}")
                    .status(200).build(),
            TestData.newData().data(ImmutableMap.of("email", (Collection<EmailMessage>) Arrays.asList(new EmailMessage(testEmailBodyUri, Arrays.asList(testEmailAttachmentUri_1, testEmailAttachmentUri_2)))))
                    .method(HttpMethod.POST)
                    .url("/ws/v1/compliance/emails/size")
                    .requestMediaType(BATCH_EMAIL_SIZE_REQUEST.toMediaType())
                    .requestContent(mapper.writeValueAsString(EmailSizeValidationRequest.newEmailSizeValidationRequest().emailMessages(Arrays.asList(new EmailMessage(testEmailBodyUri, Arrays.asList(testEmailAttachmentUri_1, testEmailAttachmentUri_2)))).build()))
                    .resultMediaType(BATCH_EMAIL_SIZE_RESPONSE.toMediaType())
                    .clientAndServerResultContent("{\"level\":\"ERROR\",\"results\":[{\"emailMessage\":{\"attachmentsUri\":[\""+testEmailAttachmentUri_1+"\",\""+testEmailAttachmentUri_2+"\"],\"emailBodyUri\":\""+testEmailBodyUri+"\"},\"level\":\"ERROR\",\"result\":\"Invalid email size [" + testEmailAttachmentUri_1 + "," + testEmailAttachmentUri_2 + "," + testEmailBodyUri + "]\"}]}")
                    .status(200).build()
        );
    }
}
