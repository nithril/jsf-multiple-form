package com.victorbuckservices.vbackbone.service.compliance.client;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpMethod;

import java.util.Arrays;
import java.util.List;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_REQUEST;

/**
 * Created by nlabrot on 26/11/15.
 */
public class EmailAddressesData {

    public static ObjectMapper mapper = (new ObjectMapper()).configure(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER, true);

    public static final List<TestData> getUnitaryEmailDataWithReport() {
        try {
            return Arrays.asList(
                    /**
                     * Tests that pass
                     */
                    TestData.newUnitaryEmailDataWithReport_Pass(
                            "foo@bar.com",
                            "{\"emailAddress\":\"foo@bar.com\",\"level\":\"INFO\",\"result\":\"\"}"
                    ),

                    /**
                     * Tests that fail
                     */
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "1234",
                            "{\"emailAddress\":\"1234\",\"level\":\"ERROR\",\"result\":\"Invalid email address [1234]\"}"
                    ),
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "test@emailFinishWithDot.",
                            "{\"emailAddress\":\"test@emailFinishWithDot.\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailFinishWithDot.]\"}"
                    ),
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX",
                            "{\"emailAddress\":\"test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX]\"}"
                    ),
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "\"(@<>,;:'\\\".[])\"@emailWithDoubleQuotedName.com",
                            "{\"emailAddress\":\"\\\"(@<>,;:'\\\\\\\".[])\\\"@emailWithDoubleQuotedName.com\",\"level\":\"ERROR\",\"result\":\"Invalid email address [\\\"(@<>,;:'\\\\\\\".[])\\\"@emailWithDoubleQuotedName.com]\"}"
                    ),
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "(@<>,;:'\\\".[])@emailWithoutDoubleQuote.com",
                            "{\"emailAddress\":\"(@<>,;:'\\\\\\\".[])@emailWithoutDoubleQuote.com\",\"level\":\"ERROR\",\"result\":\"Invalid email address [(@<>,;:'\\\\\\\".[])@emailWithoutDoubleQuote.com]\"}"
                    ),
                    TestData.newUnitaryEmailDataWithReport_Fail(
                            "test@emailWithoutDomainExtension",
                            "{\"emailAddress\":\"test@emailWithoutDomainExtension\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailWithoutDomainExtension]\"}"
                    )
            );
        } catch (Exception e) {
            return Arrays.asList();
        }
    }

    public static final List<TestData> getUnitaryEmailData() {
        try {
            return Arrays.asList(
                    /**
                     * Tests that pass
                     */
                    TestData.newUnitaryEmailData_Pass("foo@bar.com"),
                    TestData.newUnitaryEmailData_Pass("foo@bar.com"),
                    TestData.newUnitaryEmailData_Pass("o'foo.bar@bar.com"),
                    TestData.newUnitaryEmailData_Pass("o`foo.bar@bar.com"),
                    TestData.newUnitaryEmailData_Pass("o$foo.bar@bar.com"),


                    /**
                     * Tests that fail
                     */
                    TestData.newUnitaryEmailData_Fail("foo bar@foo.bar"),
                    TestData.newUnitaryEmailData_Fail("foo..bar@bar.com"),
                    TestData.newUnitaryEmailData_Fail("ofoo.bar@foo bar.com"),
                    TestData.newUnitaryEmailData_Fail("1234"),
                    TestData.newUnitaryEmailData_Fail("test@emailFinishWithDot."),
                    TestData.newUnitaryEmailData_Fail("test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX"),
                    TestData.newUnitaryEmailData_Fail("\"(@<>,;:'\\\".[])\"@emailWithDoubleQuotedName.com"),
                    TestData.newUnitaryEmailData_Fail("(@<>,;:'\\\".[])@emailWithoutDoubleQuote.com"),
                    TestData.newUnitaryEmailData_Fail("test@emailWithoutDomainExtension"),
                    TestData.newUnitaryEmailData_Fail("\"(test)\"@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("(test)@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("\"(test)\".\"(test)\"@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("(test).\"(test)\"@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("(test).(test)@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("test!@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("\"test!\"@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("test*@emailDomainExtension.com"),
                    TestData.newUnitaryEmailData_Fail("\"test*\"@emailDomainExtension.com")
            );
        } catch (Exception e) {
            return Arrays.asList();
        }
    }


    public static final List<TestData> getBatchEmailData() throws JsonProcessingException {
        try {
            return Arrays.asList(
                    TestData.newData().client(false)
                            .method(HttpMethod.POST)
                            .url("/ws/v1/compliance/emails/addresses")
                            .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                            .clientAndServerResultContent("")
                            .status(400).build(),

                    /**
                     * Tests that pass
                     */
                    TestData.newBatchEmailData_Pass(
                            Arrays.asList("foo@bar.com", "foo@baz.com"),
                            "{\"level\":\"INFO\",\"results\":[]}",
                            mapper),
                    TestData.newBatchEmailData_Pass(
                            Arrays.asList("foo@bar.com", "abc"),
                            "{\"level\":\"ERROR\",\"results\":[{\"emailAddress\":\"abc\",\"level\":\"ERROR\",\"result\":\"Invalid email address [abc]\"}]}",
                            mapper),
                    TestData.newBatchEmailData_Pass(
                            Arrays.asList(
                                    "test@emailFinishWithDot.",
                                    "test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX",
                                    "\"(@<>,;:'\".[])\"@emailWithDoubleQuotedName.com",
                                    "(@<>,;:'\".[])@emailWithoutDoubleQuote.com",
                                    "test@emailWithoutDomainExtension"
                            ),
                            "{\"level\":\"ERROR\",\"results\":[{\"emailAddress\":\"test@emailFinishWithDot.\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailFinishWithDot.]\"},"
                                    + "{\"emailAddress\":\"test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailHaveMoreThan255CharactersXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.XX]\"}," + "{\"emailAddress\":\"\\\"(@<>,;:'\\\".[])\\\"@emailWithDoubleQuotedName.com\",\"level\":\"ERROR\",\"result\":\"Invalid email address [\\\"(@<>,;:'\\\".[])\\\"@emailWithDoubleQuotedName.com]\"},"
                                    + "{\"emailAddress\":\"(@<>,;:'\\\".[])@emailWithoutDoubleQuote.com\",\"level\":\"ERROR\",\"result\":\"Invalid email address [(@<>,;:'\\\".[])@emailWithoutDoubleQuote.com]\"},"
                                    + "{\"emailAddress\":\"test@emailWithoutDomainExtension\",\"level\":\"ERROR\",\"result\":\"Invalid email address [test@emailWithoutDomainExtension]\"}]}",
                            mapper
                    )
            );
        } catch (Exception e) {
            return Arrays.asList();
        }
    }
}
