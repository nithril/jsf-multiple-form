package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_REQUEST;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.EMAIL_ADDRESS_RESPONSE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.google.auto.value.AutoValue;
import com.google.common.collect.ImmutableMap;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

/**
 * Created by nlabrot on 25/11/15.
 */
@AutoValue
@JsonDeserialize(builder = AutoValue_TestData.Builder.class)
public abstract class TestData {

    private static final String COMPLIANCE_EMAILS_ADDRESSES_URL = "/ws/v1/compliance/emails/addresses";

    public static TestData.Builder newData() {
        return new AutoValue_TestData.Builder().client(true).server(true);
    }

    public static TestData newBatchEmailData_Pass(List<String> emails, String resultContent, ObjectMapper mapper) throws UnsupportedEncodingException, JsonProcessingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", emails))
                .method(HttpMethod.POST)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL)
                .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                .requestContent(mapper.writeValueAsString(EmailAddressesValidationRequest.newEmailAddressesValidationRequest().emailAddresses(emails).build()))
                .resultMediaType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                .clientAndServerResultContent(resultContent)
                .status(200)
                .build();
    }

    public static TestData newBatchEmailData_Fails(List<String> emails, String resultContent, ObjectMapper mapper) throws UnsupportedEncodingException, JsonProcessingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", emails))
                .method(HttpMethod.POST)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL)
                .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                .requestContent(mapper.writeValueAsString(EmailAddressesValidationRequest.newEmailAddressesValidationRequest().emailAddresses(emails).build()))
                .resultMediaType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                .clientAndServerResultContent(resultContent)
                .status(400)
                .build();
    }

    public static TestData newUnitaryEmailData_Pass(String email) throws UnsupportedEncodingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", email))
                .method(HttpMethod.HEAD)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL + "/" + UriUtils.encode(email, "UTF-8"))
                .clientResultContent("true")
                .serverResultContent("")
                .status(200)
                .build();
    }

    public static TestData newUnitaryEmailData_Fail(String email) throws UnsupportedEncodingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", email))
                .method(HttpMethod.HEAD)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL + "/" + UriUtils.encode(email, "UTF-8"))
                .clientResultContent("false")
                .serverResultContent("")
                .status(400)
                .build();
    }

    public static TestData newUnitaryEmailDataWithReport_Pass(String email, String resultContent) throws UnsupportedEncodingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", email))
                .method(HttpMethod.GET)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL + "/" + UriUtils.encode(email, "UTF-8"))
                .resultMediaType(EMAIL_ADDRESS_RESPONSE.toMediaType())
                .clientAndServerResultContent(resultContent)
                .status(200)
                .build();
    }

    public static TestData newUnitaryEmailDataWithReport_Fail(String email, String resultContent) throws UnsupportedEncodingException {
        return new AutoValue_TestData.Builder()
                .client(true)
                .server(true)
                .data(ImmutableMap.of("email", email))
                .method(HttpMethod.GET)
                .url(COMPLIANCE_EMAILS_ADDRESSES_URL + "/" + UriUtils.encode(email, "UTF-8"))
                .resultMediaType(EMAIL_ADDRESS_RESPONSE.toMediaType())
                .clientAndServerResultContent(resultContent)
                .status(400)
                .build();
    }

    public abstract HttpMethod getMethod();

    public abstract String getUrl();

    @Nullable
    public abstract MediaType getResultMediaType();

    @Nullable
    public abstract MediaType getRequestMediaType();

    @Nullable
    public abstract String getRequestContent();

    @Nullable
    public abstract String getServerResultContent();

    @Nullable
    public abstract String getClientResultContent();

    public abstract int getStatus();

    @Nullable
    public abstract Map getData();

    public abstract boolean isClient();

    public abstract boolean isServer();

    @AutoValue.Builder
    @JsonPOJOBuilder(withPrefix = "")
    public abstract static class Builder {
        public abstract Builder method(HttpMethod s);

        public abstract Builder url(String s);

        public abstract Builder requestMediaType(MediaType s);

        public abstract Builder requestContent(String s);

        public abstract Builder serverResultContent(String s);

        public abstract Builder clientResultContent(String s);

        public Builder clientAndServerResultContent(String s) {
            return serverResultContent(s).clientResultContent(s);
        }

        public abstract Builder resultMediaType(MediaType s);

        public abstract Builder status(int s);

        public abstract Builder data(Map s);

        public abstract Builder client(boolean s);

        public abstract Builder server(boolean s);


        public abstract TestData build();
    }
}
