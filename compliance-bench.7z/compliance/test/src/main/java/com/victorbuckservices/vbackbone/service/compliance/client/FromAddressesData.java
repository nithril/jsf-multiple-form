package com.victorbuckservices.vbackbone.service.compliance.client;

import static com.google.common.collect.Sets.newHashSet;
import static com.victorbuckservices.vbackbone.service.compliance.client.TestData.newData;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_REQUEST;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.BATCH_EMAIL_ADDRESS_RESPONSE;
import static com.victorbuckservices.vbackbone.service.compliance.dto.ComplianceMediaType.EMAIL_ADDRESS_RESPONSE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.victorbuckservices.vbackbone.service.compliance.dto.email.EmailAddressesValidationRequest;
import org.springframework.http.HttpMethod;

import java.util.Arrays;
import java.util.List;

/**
 * Created by nlabrot on 26/11/15.
 */
public class FromAddressesData {

    public static ObjectMapper mapper = new ObjectMapper();

    public static final List<TestData> getUnitaryEmailDataWithReport() {
        return Arrays.asList(
                newData().data(ImmutableMap.of("email", "foo@victorbuckservices.com"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/emails/froms/foo@victorbuckservices.com")
                        .resultMediaType(EMAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"emailAddress\":\"foo@victorbuckservices.com\",\"level\":\"INFO\",\"result\":\"\"}")
                        .status(200).build(),
                newData().data(ImmutableMap.of("email", "foo@baz.com"))
                        .method(HttpMethod.GET)
                        .url("/ws/v1/compliance/emails/froms/foo@baz.com")
                        .resultMediaType(EMAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"emailAddress\":\"foo@baz.com\",\"level\":\"ERROR\",\"result\":\"Invalid from value [foo@baz.com]\"}")
                        .status(400).build()
        );
    }


    public static final List<TestData> getUnitaryEmailData() {

        return Arrays.asList(
                newData().data(ImmutableMap.of("email", "foo@victorbuckservices.com"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/emails/froms/foo@victorbuckservices.com")
                        .clientResultContent("true")
                        .serverResultContent("")
                        .status(200).build(),
                newData().data(ImmutableMap.of("email", "1234"))
                        .method(HttpMethod.HEAD)
                        .url("/ws/v1/compliance/emails/froms/1234")
                        .clientResultContent("false")
                        .serverResultContent("")
                        .status(400).build()

        );
    }



    public static final List<TestData> getBatchEmailData() throws JsonProcessingException {
        return Arrays.asList(
                newData().data(ImmutableMap.of("email", newHashSet("foo@victorbuckservices.com","foo2@victorbuckservices.com")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/emails/froms")
                        .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(EmailAddressesValidationRequest.newEmailAddressesValidationRequest().emailAddresses(newHashSet("foo@victorbuckservices.com","foo2@victorbuckservices.com")).build()))
                        .resultMediaType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"INFO\",\"results\":[]}")
                        .status(200).build(),
                newData().data(ImmutableMap.of("email", newHashSet("foo@victorbuckservices.com","foo@baz.com")))
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/emails/froms")
                        .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                        .requestContent(mapper.writeValueAsString(EmailAddressesValidationRequest.newEmailAddressesValidationRequest().emailAddresses(newHashSet("foo@victorbuckservices.com","foo@baz.com")).build()))
                        .resultMediaType(BATCH_EMAIL_ADDRESS_RESPONSE.toMediaType())
                        .clientAndServerResultContent("{\"level\":\"ERROR\",\"results\":[{\"emailAddress\":\"foo@baz.com\",\"level\":\"ERROR\",\"result\":\"Invalid from value [foo@baz.com]\"}]}")
                        .status(200).build(),
                newData().client(false)
                        .method(HttpMethod.POST)
                        .url("/ws/v1/compliance/emails/froms")
                        .requestMediaType(BATCH_EMAIL_ADDRESS_REQUEST.toMediaType())
                        .clientAndServerResultContent("")
                        .status(400).build()

        );
    }
}
