package com.victorbuckservices.vbackbone.service.compliance;

import com.victorbuckservices.vbackbone.service.compliance.client.EmailAddressComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailFromComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.EmailSizeComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.FaxComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.client.MailComplianceClient;
import com.victorbuckservices.vbackbone.service.compliance.configuration.ComplianceProperties;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * @author Lardinois
 *         Created on 10/03/2016
 */
@Configuration
@Profile("test")
public class ComplianceClientConfigurationForTest {

    @Bean
    public ComplianceProperties complianceProperties(){
        return new ComplianceProperties();
    }

    @Bean
    public ClientHelper clientHelper(){
        return Mockito.mock(ClientHelper.class);
    }

    @Bean
    public EmailAddressComplianceClient emailAddressComplianceClient(){
        return Mockito.mock(EmailAddressComplianceClient.class);
    }

    @Bean
    public EmailFromComplianceClient emailFromComplianceClient(){
        return Mockito.mock(EmailFromComplianceClient.class);
    }

    @Bean
    public EmailSizeComplianceClient emailSizeComplianceClient(){
        return Mockito.mock(EmailSizeComplianceClient.class);
    }

    @Bean
    public FaxComplianceClient faxComplianceClient(){
        return Mockito.mock(FaxComplianceClient.class);
    }

    @Bean
    public MailComplianceClient mailComplianceClient(){
        return Mockito.mock(MailComplianceClient.class);
    }

}
