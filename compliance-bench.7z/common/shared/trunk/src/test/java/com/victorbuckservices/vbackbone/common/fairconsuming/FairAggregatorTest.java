package com.victorbuckservices.vbackbone.common.fairconsuming;

import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.QueuePriority;
import com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairAggregator;
import com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairAmqpConsummerFactory;
import com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairConsumerSlot;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.channel.MessageChannels;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
public class FairAggregatorTest {

    private static final Logger LOG = LoggerFactory.getLogger(FairAggregatorTest.class);

    private static final int NB_QUEUE = QueuePriority.values().length;
    private static final int NB_MESSAGES_PER_QUEUE = 5000;

    @Test
    public void test() throws Exception {
        DirectChannel directChannel = MessageChannels.direct().get();
        ExecutorService executorService = FairAmqpConsummerFactory.newThreadPoolTaskExecutor(4);
        List<FairConsumerSlot> slots = Arrays.stream(QueuePriority.values()).map(p -> new FairConsumerSlot("q." + p.getValue(), p.getWeight())).collect(Collectors.toList());
        FairAggregator fairAggregator = new FairAggregator(slots, executorService, directChannel);
        final CountDownLatch countDownLatch = new CountDownLatch(NB_MESSAGES_PER_QUEUE * NB_QUEUE / 3);

        for (FairConsumerSlot slot : slots) {
            for (int i = 0; i < NB_MESSAGES_PER_QUEUE; i++) {
                Message<String> message = MessageBuilder.withPayload("").setHeader(AmqpHeaders.CONSUMER_QUEUE, slot.getQueueName()).build();
                fairAggregator.handleMessage(message);
            }
        }

        directChannel.subscribe(message -> countDownLatch.countDown());


        Stopwatch stopwatch = Stopwatch.createStarted();
        fairAggregator.start();
        countDownLatch.await(60, TimeUnit.SECONDS);
        stopwatch.stop();
        fairAggregator.stop();

        Assert.assertEquals(0, countDownLatch.getCount());

        float haveBoost = 0;
        float haveHigh = 0;
        float haveMedium = 0;
        float haveLow = 0;

        for (FairConsumerSlot slot : slots) {
            float rate = (1000f * slot.getProcessedMsg() / stopwatch.elapsed(TimeUnit.MILLISECONDS));

            if (QueuePriority.LOW.getWeight() == slot.getQuantum()) {
                haveLow = rate;
            } else if (QueuePriority.MEDIUM.getWeight() == slot.getQuantum()) {
                haveMedium = rate;
            } else if (QueuePriority.HIGH.getWeight() == slot.getQuantum()) {
                haveHigh = rate;
            } else if (QueuePriority.BOOST.getWeight() == slot.getQuantum()) {
                haveBoost = rate;
            }
            LOG.info("Name={} Quantum={} Consumed msg={} Msg/s={}", slot.getQueueName(), slot.getQuantum(), slot.getProcessedMsg(), rate);
        }

        Assert.assertTrue(haveBoost > haveHigh);
        Assert.assertTrue(haveHigh > haveMedium);
        Assert.assertTrue(haveHigh > haveLow);
    }


    @Test
    public void testBoost() throws Exception {
        DirectChannel directChannel = MessageChannels.direct().get();
        ExecutorService executorService = FairAmqpConsummerFactory.newThreadPoolTaskExecutor(4);
        List<FairConsumerSlot> slots = Arrays.stream(QueuePriority.values()).map(p -> new FairConsumerSlot("q." + p.getValue(), p.getWeight()))
                .collect(Collectors.toList());
        slots = Lists.reverse(slots);

        FairAggregator fairAggregator = new FairAggregator(slots, executorService, directChannel);
        final CountDownLatch countDownLatch = new CountDownLatch(NB_MESSAGES_PER_QUEUE);

        for (FairConsumerSlot slot : slots) {
            for (int i = 0; i < NB_MESSAGES_PER_QUEUE; i++) {
                Message<String> message = MessageBuilder.withPayload("").setHeader(AmqpHeaders.CONSUMER_QUEUE, slot.getQueueName()).build();
                fairAggregator.handleMessage(message);
            }
        }
        directChannel.subscribe(message -> countDownLatch.countDown());

        Stopwatch stopwatch = Stopwatch.createStarted();
        fairAggregator.start();
        countDownLatch.await(60, TimeUnit.SECONDS);
        stopwatch.stop();
        fairAggregator.stop();

        Assert.assertEquals(0, countDownLatch.getCount());

        Assert.assertEquals(NB_MESSAGES_PER_QUEUE, slots.stream().filter(pq -> pq.getQuantum() == QueuePriority.BOOST.getWeight()).findFirst().get().getProcessedMsg());
        //May be above 0 while the FairAggregator stopped
        slots.forEach(s -> LOG.info("Slot: [{}]" , s));
        Assert.assertEquals(QueuePriority.values().length - 1, slots.stream().filter(pq -> pq.getQuantum() != QueuePriority.BOOST.getWeight() && pq.getProcessedMsg() < 100).count());
    }


    @Test
    public void testRatio() throws Exception {
        DirectChannel directChannel = MessageChannels.direct().get();
        ExecutorService executorService = FairAmqpConsummerFactory.newThreadPoolTaskExecutor(4);

        List<FairConsumerSlot> slots = Arrays.stream(QueuePriority.values()).filter(qp -> qp != QueuePriority.BOOST).map(p -> new FairConsumerSlot("q." + p.getValue(), p.getWeight())).collect(Collectors.toList());
        FairAggregator fairAggregator = new FairAggregator(slots, executorService, directChannel);
        final CountDownLatch countDownLatch = new CountDownLatch(NB_MESSAGES_PER_QUEUE * NB_QUEUE / 3);

        for (FairConsumerSlot slot : slots) {
            for (int i = 0; i < NB_MESSAGES_PER_QUEUE; i++) {
                Message<String> message = MessageBuilder.withPayload("").setHeader(AmqpHeaders.CONSUMER_QUEUE, slot.getQueueName()).build();
                fairAggregator.handleMessage(message);
            }
        }

        directChannel.subscribe(message -> countDownLatch.countDown());

        Stopwatch stopwatch = Stopwatch.createStarted();
        fairAggregator.start();
        countDownLatch.await(60, TimeUnit.SECONDS);
        stopwatch.stop();
        fairAggregator.stop();

        Assert.assertEquals(0, countDownLatch.getCount());


        float haveHigh = 0;
        float haveMedium = 0;
        float haveLow = 0;

        for (FairConsumerSlot slot : slots) {
            float rate = (1000f * slot.getProcessedMsg() / stopwatch.elapsed(TimeUnit.MILLISECONDS));

            if (QueuePriority.LOW.getWeight() == slot.getQuantum()) {
                haveLow = rate;
            } else if (QueuePriority.MEDIUM.getWeight() == slot.getQuantum()) {
                haveMedium = rate;
            } else if (QueuePriority.HIGH.getWeight() == slot.getQuantum()) {
                haveHigh = rate;
            }
            LOG.info("Name={} Quantum={} Consumed msg={} Msg/s={}", slot.getQueueName(), slot.getQuantum(), slot.getProcessedMsg(), rate);
        }

        Assert.assertEquals((float) QueuePriority.HIGH.getWeight() / QueuePriority.MEDIUM.getWeight() , haveHigh / haveMedium , 0.01);
        Assert.assertEquals((float) QueuePriority.MEDIUM.getWeight() / QueuePriority.LOW.getWeight() , haveMedium / haveLow , 0.01);

        Assert.assertTrue(haveHigh > haveMedium);
        Assert.assertTrue(haveHigh > haveLow);
    }


    private void waitFor(int interval) {
        long start = System.nanoTime();
        while (start + interval > System.nanoTime()) ;
    }
}
