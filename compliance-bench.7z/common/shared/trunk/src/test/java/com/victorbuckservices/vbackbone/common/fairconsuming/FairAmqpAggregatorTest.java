package com.victorbuckservices.vbackbone.common.fairconsuming;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.QueuePriority;
import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.common.CommonSharedConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.*;
import com.victorbuckservices.vbackbone.common.controlbus.inbound.ControlBusActionService;
import com.victorbuckservices.vbackbone.common.exception.BadConfigurationException;
import com.victorbuckservices.vbackbone.common.integration.fairconsuming.AbstractFairConsumerConfiguration;
import com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairConsumerSlot;
import com.victorbuckservices.vbackbone.common.testcontext.TestContextConfiguration;
import com.victorbuckservices.vbackbone.common.utils.lambda.with.CheckedConsumer;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.channel.MessageChannels;
import org.springframework.messaging.Message;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                CommonSharedConfiguration.class
                , FairAmqpAggregatorTest.FairAmqpAggregatorTestConfiguration.class
                , TestContextConfiguration.class
                , ControlBusConfiguration.class
                , MonitoringConfiguration.class
                , BusBuilderPlaceholderConfigurerConfiguration.class
                , RabbitConnectionConfiguration.class
                , FairConsumingConfiguration.class
        }
)
@ActiveProfiles({
        "production",
        "test",
        "test-with-frozen-uuidgenerator"
})
public class FairAmqpAggregatorTest extends AbstractTest {

    private static final Logger LOG = LoggerFactory.getLogger(FairAmqpAggregatorTest.class);

    private static final int NB_QUEUE = QueuePriority.values().length;
    private static final int NB_MESSAGES_PER_QUEUE = 5000;

    @Autowired
    private ControlBusActionService controlBusActionService;

    @Autowired
    private Dispatcher dispatcher;

    @Configuration
    @EnableAutoConfiguration(exclude = {
            LiquibaseAutoConfiguration.class,
            FreeMarkerAutoConfiguration.class
    })
    @IntegrationComponentScan("com.victorbuckservices.vbackbone.common.fairconsuming")
    public static class FairAmqpAggregatorTestConfiguration extends AbstractFairConsumerConfiguration {

        protected String getServiceInChannelName() {
            return "foobar";
        }

        protected List<FairConsumerSlot> getFairConsumerSlots() {
            List<FairConsumerSlot> slots = Arrays.stream(QueuePriority.values()).map(p -> new FairConsumerSlot("testrecovery." + p.getValue(), p.getWeight())).collect(Collectors.toList());
            return slots;
        }

        @Override
        public IntegrationFlow amqpFairServiceInboundFlow(IntegrationFlow serviceDispatcherFlow, ConnectionFactory connectionFactory, RabbitTemplate amqpTemplate, AmqpAdmin amqpAdmin) throws BadConfigurationException {
            amqpTemplate.execute(c -> {
                c.exchangeDeclare("fairconsuming", "direct", false, true, Collections.emptyMap());
                getFairConsumerSlots().stream().forEach((CheckedConsumer<FairConsumerSlot>) s -> c.queueDeclare(s.getQueueName(), false, false, true, null));
                getFairConsumerSlots().stream().forEach((CheckedConsumer<FairConsumerSlot>) s -> c.queueBind(s.getQueueName(), "fairconsuming", s.getQueueName()));
                return null;
            });

            amqpTemplate.execute(c -> {
                for (FairConsumerSlot slot : getFairConsumerSlots()) {
                    for (int i = 0; i < NB_MESSAGES_PER_QUEUE; i++) {
                        c.basicPublish("fairconsuming", slot.getQueueName() , new AMQP.BasicProperties.Builder().build() , new byte[]{});
                    }
                }
                return null;
            });

            return super.amqpFairServiceInboundFlow(serviceDispatcherFlow, connectionFactory, amqpTemplate , amqpAdmin);
        }

        @Bean
        public Dispatcher dispatcher() {
            return new Dispatcher(getFairConsumerSlots());
        }


        @Bean
        public IntegrationFlow serviceDispatcherFlow() {
            return IntegrationFlows.from(MessageChannels.direct(getServiceInChannelName())).handle(m -> dispatcher().dispatch(m)).get();
        }

    }

    public static class Dispatcher {

        public Map<String, AtomicInteger> slotCounter;
        public CountDownLatch countDownLatch = new CountDownLatch(NB_MESSAGES_PER_QUEUE * NB_QUEUE / 3);

        public Dispatcher(List<FairConsumerSlot> slots) {
            slotCounter = slots.stream().map(FairConsumerSlot::getQueueName).collect(Collectors.toConcurrentMap(k -> k, k -> new AtomicInteger()));
        }

        public void dispatch(Message m) {
            try {
                Channel channel = m.getHeaders().get(AmqpHeaders.CHANNEL, Channel.class);
                Long deliveryTag = m.getHeaders().get(AmqpHeaders.DELIVERY_TAG, Long.class);
                String queueName = m.getHeaders().get(AmqpHeaders.CONSUMER_QUEUE, String.class);
                slotCounter.get(queueName).incrementAndGet();
                countDownLatch.countDown();
                waitFor(1_000_000);
                channel.basicAck(deliveryTag , false);
            } catch (IOException e) {
                LOG.error(e.getMessage() , e);
                throw new RuntimeException(e);
            }
        }
    }


    @Ignore
    @Test
    public void testName() throws Exception {
        dispatcher.countDownLatch.await();
        controlBusActionService.stopConsumers();
    }


    private static void waitFor(int interval) {
        long start = System.nanoTime();
        while (start + interval > System.nanoTime()) ;
    }
}
