package com.victorbuckservices.vbackbone.common.uuid;

import static org.assertj.core.api.BDDAssertions.then;

import com.victorbuckservices.vbackbone.common.uuid.locality.LocalityUuidGeneratorService;
import org.apache.commons.exec.OS;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;

/**
 * Created on 03/24/2015
 *
 * @author labrot
 */
public class UuidLocalityDiscriminantTest {

    @InjectMocks
    private LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();

    @Mock
    private Environment environment;


    @Rule
    public ExpectedException expectedException = ExpectedException.none();


    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testDiscriminantValue_Correct() throws Exception {
        localityUuidGeneratorService.setUuidDiscriminant(16384);
        localityUuidGeneratorService.setServiceDiscriminant(1);
        localityUuidGeneratorService.initVersionAndDiscriminant();
        localityUuidGeneratorService.generateUuid();
    }

    @Test
    public void testDiscriminantValue_Correct2() throws Exception {
        localityUuidGeneratorService.setUuidDiscriminant((1<<20)-1);
        localityUuidGeneratorService.setServiceDiscriminant(1);
        localityUuidGeneratorService.initVersionAndDiscriminant();
        localityUuidGeneratorService.generateUuid();
    }

    @Test
    public void testDiscriminantValue_NotSet() throws Exception {
        try {
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("Uuid discriminant value or path is not set");
        }
    }

    @Test
    public void testServiceDiscriminantValue_NotSet() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminant(0);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalArgumentException.class).hasMessage("service.discriminant must be provided");
        }
    }



    @Test
    public void testServiceDiscriminantValue_Zero() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminant(0);
            localityUuidGeneratorService.setServiceDiscriminant(0);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("Service discriminant is equals to 0 or gte 2^8");
        }
    }

    @Test
    public void testServiceDiscriminantValue_TooLong() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminant(0);
            localityUuidGeneratorService.setServiceDiscriminant(256);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("Service discriminant is equals to 0 or gte 2^8");
        }
    }

    @Test
    public void testDiscriminantValue_TooLong() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminant(1 << 20);
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("Discriminant value is gte 2^20");
        }
    }

    @Test
    public void testDiscriminantPath_Ok() throws Exception {
        localityUuidGeneratorService.setUuidDiscriminantPath("src/test/resources/discriminant/correct.conf");
        localityUuidGeneratorService.setServiceDiscriminant(1);
        localityUuidGeneratorService.initVersionAndDiscriminant();
    }

    @Test
    public void testDiscriminantPath_TwoLines() throws Exception {
        localityUuidGeneratorService.setUuidDiscriminantPath("src/test/resources/discriminant/twoLines.conf");
        localityUuidGeneratorService.setServiceDiscriminant(1);
        localityUuidGeneratorService.initVersionAndDiscriminant();
    }

    @Test
    public void testDiscriminantPath_NaN() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminantPath("src/test/resources/discriminant/NaN.conf");
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(NumberFormatException.class).hasMessage("For input string: \"aa\"");
        }
    }

    @Test
    public void testDiscriminantPath_tooLong() throws Exception {
        try {
            localityUuidGeneratorService.setUuidDiscriminantPath("src/test/resources/discriminant/tooLong.conf");
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            throw new IllegalStateException();
        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("Discriminant value is gte 2^20");
        }
    }


    @Test
    public void testDiscriminantValue_IncorrectEnvironment() throws Exception {
        try {
            Mockito.when(environment.acceptsProfiles("production")).thenReturn(true);

            localityUuidGeneratorService.setUuidDiscriminant(0);
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            localityUuidGeneratorService.generateUuid();

            Assert.assertTrue(OS.isFamilyWindows());
        } catch (Exception e) {
            Mockito.verify(environment).acceptsProfiles("production");

            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("You are using an UUID associated to a local environment with a production profile on a non windows OS, this configuration is erroneous");
        }
    }

    @Test
    public void testDiscriminantValue_CorrectEnvironment() throws Exception {
        try {
            Mockito.when(environment.acceptsProfiles("production")).thenReturn(true);

            localityUuidGeneratorService.setUuidDiscriminant(1<<14);
            localityUuidGeneratorService.setServiceDiscriminant(1);
            localityUuidGeneratorService.initVersionAndDiscriminant();
            localityUuidGeneratorService.generateUuid();

            Mockito.verifyNoMoreInteractions(environment);

        } catch (Exception e) {
            then(e).isInstanceOf(IllegalStateException.class);
            then(e.getCause()).isInstanceOf(IllegalStateException.class).hasMessage("You are using an UUID associated to a local environment with a production profile, this configuration is not supported");
        }
    }
}
