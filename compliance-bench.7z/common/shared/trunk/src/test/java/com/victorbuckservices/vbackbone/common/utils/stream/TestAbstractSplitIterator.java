package com.victorbuckservices.vbackbone.common.utils.stream;

import com.victorbuckservices.vbackbone.common.utils.lambda.IoCloser;
import org.junit.Assert;
import org.junit.Test;

import java.util.Spliterators;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Created on 6/01/2016
 *
 * @author labrot
 */
public class TestAbstractSplitIterator {

    @Test
    public void testForEach() throws Exception {
        AtomicInteger integer = new AtomicInteger(0);
        StreamSupport.stream(new IntegerSpliterator(), false).forEach(a -> {
            integer.incrementAndGet();
        });
        Assert.assertEquals(9 , integer.get());
    }


    @Test
    public void testIteratorForEachRemaining() throws Exception {
        AtomicInteger integer = new AtomicInteger(0);
        Spliterators.iterator(new IntegerSpliterator()).forEachRemaining(a -> {
            integer.incrementAndGet();
        });
        Assert.assertEquals(9 , integer.get());
    }

    @Test
    public void testStreamToIterator() throws Exception {
        AtomicInteger integer = new AtomicInteger(0);
        Stream<Integer> stream = StreamSupport.stream(new IntegerSpliterator(), false);
        Iterable<Integer> iterable = stream::iterator;
        for (Integer v : iterable){
            integer.incrementAndGet();
        }
        Assert.assertEquals(9 , integer.get());
    }

    //VBBSHARED-142
    @Test
    public void testStreamMapToIterator() throws Exception {

        IntStream.range(0,10).iterator();

        AtomicInteger integer = new AtomicInteger(0);
        Stream<Integer> stream = StreamSupport.stream(new IntegerSpliterator(), false).map(v -> v * 2);
        Iterable<Integer> iterable = stream::iterator;
        for (Integer v : iterable){
            integer.incrementAndGet();
        }
        Assert.assertEquals(9 , integer.get());
    }


    private static class IntegerSpliterator extends AbstractSpliterator<Integer> {
        int integer = 0;

        @Override
        protected Integer readNext() throws Exception {
            integer++;
            if (integer == 10) {
                return null;
            } else if (integer < 10) {
                return integer;
            } else {
                throw new IllegalStateException();
            }
        }

        @Override
        protected void initIfNeeded() {
        }

        @Override
        protected IoCloser closeQuietly() {
            return null;
        }
    }
}
