package com.victorbuckservices.vbackbone.common.testcontext;

import static com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest.Constants.ACTION_MAPPING;
import static com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest.Constants.OVERRIDED_ACTION_MAPPING;

import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.annotation.ActionMapping;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest;
import com.victorbuckservices.vbackbone.common.testcontext.dto.Foo;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import org.junit.Assert;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created on 02/10/2015
 *
 * @author labrot
 */
@Service
public class ActionWithUrnFooService {

    private AtomicInteger actionWithUrnFooCounter = new AtomicInteger();
    private AtomicInteger overridedActionWithUrnFooCounter = new AtomicInteger();

    @ActionMapping(urn = ACTION_MAPPING)
    public void actionWithUrnFoo(Foo foo, MessageEnvelopeHeader messageEnvelopeHeader, Action action) {
        Assert.assertEquals(1, foo.getFoo());
        Assert.assertEquals(CommonActionForTest.FOO_ACTION , messageEnvelopeHeader.getAction());
        Assert.assertEquals(CommonActionForTest.FOO_ACTION , action);
        actionWithUrnFooCounter.incrementAndGet();
    }

    @OverridedActionMapping(urn = OVERRIDED_ACTION_MAPPING)
    public void overridedActionWithUrnFoo(Foo foo, MessageEnvelopeHeader messageEnvelopeHeader, Action action) {
        Assert.assertEquals(1, foo.getFoo());
        Assert.assertEquals(CommonActionForTest.OVERRIDED_ACTION_MAPPING , messageEnvelopeHeader.getAction());
        Assert.assertEquals(CommonActionForTest.OVERRIDED_ACTION_MAPPING , action);
        overridedActionWithUrnFooCounter.incrementAndGet();
    }


    public void reset(){
        actionWithUrnFooCounter.set(0);
        overridedActionWithUrnFooCounter.set(0);
    }

    public int getActionWithUrnFooCounter(){
        return actionWithUrnFooCounter.get();
    }
    public int getOverridedActionWithUrnFooCounter(){
        return overridedActionWithUrnFooCounter.get();
    }

}
