package com.victorbuckservices.vbackbone.common.testcontext;

import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.annotation.ActionMapping;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created on 06/11/2015
 *
 * @author labrot
 */
@Retention(RetentionPolicy.RUNTIME)
@ActionMapping(urn = "")
public @interface OverridedActionMapping {

    /**
     * Action urn
     *
     * @return
     */
    String urn();

}
