package com.victorbuckservices.vbackbone.common.testcontext;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created on 02/06/2015
 *
 * @author labrot
 */
@Configuration
@ComponentScan({
        "com.victorbuckservices.vbackbone.common.testcontext",
        "com.victorbuckservices.vbackbone.common.storagekeeper"
})
public class TestContextConfiguration {

}
