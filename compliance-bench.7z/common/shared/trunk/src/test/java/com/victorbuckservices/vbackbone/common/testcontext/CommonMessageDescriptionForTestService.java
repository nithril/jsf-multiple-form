package com.victorbuckservices.vbackbone.common.testcontext;

import com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest;
import com.victorbuckservices.vbackbone.common.testcontext.definition.CommonVbbMimeTypeForTest;
import com.victorbuckservices.vbackbone.shared.ServiceDefinition;
import com.victorbuckservices.vbackbone.shared.service.ServiceDefinitionProviderService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
@Service
public class CommonMessageDescriptionForTestService implements ServiceDefinitionProviderService {

    @Override
    public ServiceDefinition getServiceDefinition() {
        ServiceDefinition serviceDefinition = new ServiceDefinition();
        serviceDefinition.setActions(Arrays.asList(CommonActionForTest.values()));
        serviceDefinition.setVbbMimeTypes(Arrays.asList(CommonVbbMimeTypeForTest.values()));
        return serviceDefinition;
    }
}
