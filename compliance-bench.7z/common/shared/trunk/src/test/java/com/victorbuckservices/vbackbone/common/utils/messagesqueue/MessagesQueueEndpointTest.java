package com.victorbuckservices.vbackbone.common.utils.messagesqueue;

import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import org.junit.Assert;
import org.junit.Test;

import java.util.concurrent.TimeoutException;

/**
 * Created by labrot on 12/15/2014.
 */
public class MessagesQueueEndpointTest {

    private MessagesQueueEndpoint messagesQueueEndpoint = new MessagesQueueEndpoint();

    @Test
    public void test_ReceiveNextHeaderAndBody_WithCorrectType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        Assert.assertEquals("foo", messagesQueueEndpoint.receiveNextHeaderAndBody().getBody());
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_ReceiveNextHeaderAndBody_WithIncorrectType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        messagesQueueEndpoint.receiveNextHeaderAndBody(Integer.class);
    }

    @Test
    public void test_ReceiveNextBody_WithCorrectType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        messagesQueueEndpoint.receiveNextBody();
    }

    @Test(expected = IllegalArgumentException.class)
    public void test_ReceiveNextBody_WithIncorrectType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        messagesQueueEndpoint.receiveNextBody(Integer.class);
    }

    @Test
    public void test_ReceiveNextHeaderAndBody_WithoutType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        Assert.assertEquals("foo", messagesQueueEndpoint.receiveNextHeaderAndBody().getBody());
    }

    @Test
    public void test_ReceiveNextBody_WithoutType() throws TimeoutException {
        GenericMessageEnvelope<String> messageEnvelope = new GenericMessageEnvelope<>(null, "foo");
        messagesQueueEndpoint.queueMessage(messageEnvelope);
        Assert.assertEquals("foo", messagesQueueEndpoint.receiveNextBody());
    }

    @Test(expected = TimeoutException.class)
    public void test_TimeOut() throws TimeoutException {
        messagesQueueEndpoint = new MessagesQueueEndpoint(1);
        messagesQueueEndpoint.receiveNextBody();
    }
}
