package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.util.MimeType;

/**
 * @author labrot
 *         Created on 11/18/2014
 */
public class CommonVbbMimeTypeTest {

    @Test
    public void testMimetypeVersionAreEquals() {
        for (VbbMimeType vbbMimeType : CommonVbbMimeType.values()) {
            MimeType mimeType = vbbMimeType.toMimeType();
            Assert.assertEquals(vbbMimeType.getVersion(), mimeType.getParameter(VbbMimeType.VERSION_PARAMETER));
            Assert.assertNotNull(vbbMimeType.getVersion());
        }
    }

}
