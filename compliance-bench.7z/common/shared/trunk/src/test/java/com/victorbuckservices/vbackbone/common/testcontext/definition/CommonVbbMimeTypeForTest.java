package com.victorbuckservices.vbackbone.common.testcontext.definition;

import com.victorbuckservices.vbackbone.common.testcontext.dto.GenericFoo;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Contain the common {@link com.victorbuckservices.vbackbone.shared.definition.VbbMimeType}s.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public enum CommonVbbMimeTypeForTest implements VbbMimeType {

    //TODO: correct the sonar
    FOO("application/vnd.vbs.vbackbone.test.foo-1.0+json;charset=UTF-8;v=1.0", "1.0", GenericFoo.class);


    private final String name;
    private final String version;
    private final Class<?> contentClass;

    private CommonVbbMimeTypeForTest(String name, String version, Class<?> contentClass) {
        this.name = name;
        this.version = version;
        this.contentClass = contentClass;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public Class<?> getContentClass() {
        return contentClass;
    }
}
