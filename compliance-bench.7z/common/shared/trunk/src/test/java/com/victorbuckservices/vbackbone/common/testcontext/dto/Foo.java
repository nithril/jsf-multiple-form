package com.victorbuckservices.vbackbone.common.testcontext.dto;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
public interface Foo {

    int getFoo();


}
