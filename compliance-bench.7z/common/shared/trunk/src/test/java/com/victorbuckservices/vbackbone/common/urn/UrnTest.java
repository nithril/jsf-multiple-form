package com.victorbuckservices.vbackbone.common.urn;

import com.victorbuckservices.vbackbone.common.utils.UrnHelper;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by nlabrot on 04/03/15.
 */
public class UrnTest {

    @Test
    public void testOk_1_2(){
        Assert.assertEquals("1.2", UrnHelper.extractVersion("urn:1.2"));

    }
    @Test
    public void testOk_1_2_3(){
        Assert.assertEquals("1.2.3", UrnHelper.extractVersion("urn:1.2.3"));
    }

    @Test
    public void testOk_10_1(){
        Assert.assertEquals("10.1", UrnHelper.extractVersion("urn:10.1"));
    }

    @Test(expected = IllegalStateException.class)
    public void testKo_1(){
        UrnHelper.extractVersion("urn:1");
    }

    @Test(expected = IllegalStateException.class)
    public void testKo_No(){
        UrnHelper.extractVersion("urn");
    }
}
