package com.victorbuckservices.vbackbone.common.testcontext.dto;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
public class GenericFoo implements Foo {

    private int foo;

    public GenericFoo() {
    }

    public GenericFoo(int foo) {
        this.foo = foo;
    }

    public int getFoo() {
        return foo;
    }

    public void setFoo(int foo) {
        this.foo = foo;
    }
}
