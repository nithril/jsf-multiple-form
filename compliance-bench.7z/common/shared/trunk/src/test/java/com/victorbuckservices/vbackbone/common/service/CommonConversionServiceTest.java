package com.victorbuckservices.vbackbone.common.service;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableMap;
import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.common.definition.CommonAction;
import com.victorbuckservices.vbackbone.common.integration.message.MessageHeader;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.MimeType;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Test the {@link CommonConversionService}.
 *
 * @author plouhinec
 * Created on 01/08/2015
 */
@RunWith(MockitoJUnitRunner.class)
public class CommonConversionServiceTest
{
    @Mock
    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    @InjectMocks
    private CommonConversionService commonConversionService = new CommonConversionService();

    @Test
    public void testParseMessageHeader()
    {
        long timestamp = Instant.now().toEpochMilli();

        Map<String, Object> headerAsMap = ImmutableMap.of(
                "contentType", "application/vnd.vbs.common.empty-1.0;v=1.0",
                "timestamp", timestamp,
                "vbb-action-urn", "urn:vbs:action:vbackbone:common:unknown:1.0",
                "vbb-status-level", "INFO");

        when(serviceDefinitionDirectoryService.findActionByUrn("urn:vbs:action:vbackbone:common:unknown:1.0")).thenReturn(CommonAction.UNKNOWN_ACTION);

        MessageHeader messageHeader = commonConversionService.parseMessageHeader(headerAsMap);
        Assert.assertEquals(MimeType.valueOf("application/vnd.vbs.common.empty-1.0;v=1.0"), messageHeader.getContentType());
        Assert.assertEquals(timestamp, messageHeader.getTimestamp().longValue());
        Assert.assertEquals(CommonAction.UNKNOWN_ACTION, messageHeader.getAction());
        Assert.assertEquals(ReportLevel.INFO, messageHeader.getStatusLevel());

        verify(serviceDefinitionDirectoryService).findActionByUrn("urn:vbs:action:vbackbone:common:unknown:1.0");
    }

    @Test
    public void testParseMessageHeaderWithEmptyMap()
    {
        MessageHeader messageHeader = commonConversionService.parseMessageHeader(null);
        Assert.assertNull(messageHeader.getContentType());
        Assert.assertNull(messageHeader.getTimestamp());
        Assert.assertNull(messageHeader.getAction());
        Assert.assertNull(messageHeader.getStatusLevel());

        messageHeader = commonConversionService.parseMessageHeader(new HashMap<>());
        Assert.assertNull(messageHeader.getContentType());
        Assert.assertNull(messageHeader.getTimestamp());
        Assert.assertNull(messageHeader.getAction());
        Assert.assertNull(messageHeader.getStatusLevel());
    }

    @Test
    public void testParseMessageHeaderWithInvalidData()
    {

        Map<String, Object> headerAsMap = ImmutableMap.of(
                "contentType", "1ez5d61ed5z1ed",
                "timestamp", "abc",
                "vbb-action-urn", "ho ho",
                "vbb-status-level", "ABZ");

        MessageHeader messageHeader = commonConversionService.parseMessageHeader(headerAsMap);
        Assert.assertNull(messageHeader.getContentType());
        Assert.assertNull(messageHeader.getTimestamp());
        Assert.assertNull(messageHeader.getAction());
        Assert.assertNull(messageHeader.getStatusLevel());
    }
}
