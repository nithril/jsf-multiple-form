package com.victorbuckservices.vbackbone.common;

import com.victorbuckservices.vbackbone.common.configuration.*;
import com.victorbuckservices.vbackbone.common.testcontext.TestContextConfiguration;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                CommonSharedConfiguration.class
                , TestContextConfiguration.class
                , ControlBusConfiguration.class
                , MonitoringConfiguration.class
                , BusBuilderPlaceholderConfigurerConfiguration.class
                , RabbitConnectionConfiguration.class

        }
)
@EnableConfigurationProperties
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator"
})
public abstract class AbstractTest {

    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;


    @BeforeClass
    public static void createDirectory() throws Exception {
        Files.createDirectories(Paths.get("target/storagekeeper/work"));
        Files.createDirectories(Paths.get("target/storagekeeper/storage"));
    }
}
