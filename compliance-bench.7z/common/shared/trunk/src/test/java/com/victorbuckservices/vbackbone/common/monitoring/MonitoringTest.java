package com.victorbuckservices.vbackbone.common.monitoring;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.common.busbuilder.BusBuilderService;
import com.victorbuckservices.vbackbone.common.configuration.MonitoringConfiguration;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class MonitoringTest extends AbstractTest{

    @Autowired
    private MonitoringConfiguration monitoringConfiguration;

    @Autowired
    private BusBuilderService busBuilderService;


    @Test
    public void testMonitoredQueues() throws Exception {
        Assert.assertEquals(3 , busBuilderService.getQueues().size());
        Assert.assertEquals(1 , busBuilderService.getQueues().stream().filter(queue -> queue.getName().contains("archiving")).count());

        Assert.assertEquals(2 , monitoringConfiguration.getMonitoredQueues().size());

        Assert.assertTrue(CollectionUtils.isSubCollection(monitoringConfiguration.getMonitoredQueues(), busBuilderService.getQueues()));
    }
}
