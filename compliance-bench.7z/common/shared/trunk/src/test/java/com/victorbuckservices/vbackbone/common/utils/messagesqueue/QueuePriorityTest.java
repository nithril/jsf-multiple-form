package com.victorbuckservices.vbackbone.common.utils.messagesqueue;

import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.QueuePriority;
import org.junit.Assert;
import org.junit.Test;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-09-11.
 */
public class QueuePriorityTest {

    @Test
    public void testQueuePriorityEnum(){

        Assert.assertEquals( "low", QueuePriority.LOW.getName());
        Assert.assertEquals( 0, QueuePriority.LOW.getValue());
        Assert.assertEquals( 1L, QueuePriority.LOW.getWeight());

        Assert.assertEquals( "medium", QueuePriority.MEDIUM.getName());
        Assert.assertEquals( 1, QueuePriority.MEDIUM.getValue());
        Assert.assertEquals( 2L, QueuePriority.MEDIUM.getWeight());

        Assert.assertEquals( "high", QueuePriority.HIGH.getName());
        Assert.assertEquals( 2, QueuePriority.HIGH.getValue());
        Assert.assertEquals( 4L, QueuePriority.HIGH.getWeight());

        Assert.assertEquals( "boost", QueuePriority.BOOST.getName());
        Assert.assertEquals( 32, QueuePriority.BOOST.getValue());
        Assert.assertEquals( 4294967296L, QueuePriority.BOOST.getWeight());
    }

}
