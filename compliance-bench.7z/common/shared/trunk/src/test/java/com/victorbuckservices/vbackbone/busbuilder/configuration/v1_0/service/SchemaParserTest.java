package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition.BusBuilderSchemaDefinition;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.PrioritizedQueue;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.QueuePriority;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.binding.Binding;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Test;

import java.util.Collections;

/**
 * Created on 23/09/2015
 *
 * @author labrot
 */
public class SchemaParserTest {

    @Test
    public void testSchemaParser() throws Exception {
        String expectedSchema = "{" +
        /**/        "\"schemaName\":\"normalization\"," +
        /**/        "\"vhosts\":[]," +
        /**/        "\"users\":[]," +
        /**/        "\"permissions\":[]," +
        /**/        "\"policies\":[]," +
        /**/        "\"exchanges\":{" +
        /**/            "\"default\":{" +
        /**/                "\"name\":\"normalization.exchange\"," +
        /**/                "\"type\":\"direct\"," +
        /**/                "\"durable\":true" +
        /**/            "}" +
        /**/        "}," +
        /**/        "\"queues\":{" +
        /**/            "\"jpmorgan\":{" +
        /**/                "\"name\":\"normalization.queue.jpmorgan\"," +
        /**/                "\"durable\":true" +
        /**/            "}," +
        /**/            "\"demontrs\":{" +
        /**/                "\"name\":\"normalization.queue.northentrust\"," +
        /**/                "\"durable\":true" +
        /**/            "}" +
        /**/        "}," +
        /**/        "\"prioritizedQueues\":{" +
        /**/            "\"vbstest\":{" +
        /**/                "\"queue_name_prefix\":\"normalization.queue.vbstest\"," +
        /**/                "\"queue_durable\":true," +
        /**/                "\"exchange_source\":\"normalization.exchange\"," +
        /**/                "\"exchange_routing_key_prefix\":\"vbstest\"," +
        /**/                "\"bindings\":null" +
        /**/            "}," +
        /**/            "\"vbstest2\":{" +
        /**/                "\"queue_name_prefix\":\"normalization.queue.vbstest\"," +
        /**/                "\"queue_durable\":true," +
        /**/                "\"exchange_source\":null," +
        /**/                "\"exchange_routing_key_prefix\":null," +
        /**/                "\"bindings\":[" +
        /**/                    "{" +
        /**/                        "\"exchange_source\":\"source_a.exchange\"," +
        /**/                        "\"exchange_routing_key_prefix\":\"vbstest_a\"" +
        /**/                    "},{" +
        /**/                        "\"exchange_source\":\"source_b.exchange\"," +
        /**/                        "\"exchange_routing_key_prefix\":\"vbstest_b\"" +
        /**/                    "}" +
        /**/                "]" +
        /**/            "}" +
        /**/       "}," +
        /**/        "\"bindings\":" +
        /**/            "[" +
        /**/                "{" +
        /**/                    "\"source\":\"normalization.exchange\"," +
        /**/                    "\"destination\":\"normalization.queue.vbstest\"," +
        /**/                    "\"destination_type\":\"queue\"," +
        /**/                    "\"routing_key\":\"vbstest\"" +
        /**/                "},{" +
        /**/                    "\"source\":\"normalization.exchange\"," +
        /**/                    "\"destination\":\"normalization.queue.jpmorgan\"," +
        /**/                    "\"destination_type\":\"queue\"," +
        /**/                    "\"routing_key\":\"jpmorgan\"" +
        /**/               "},{" +
        /**/                    "\"source\":\"normalization.exchange\"," +
        /**/                    "\"destination\":\"normalization.queue.northentrust\"," +
        /**/                    "\"destination_type\":\"queue\"," +
        /**/                    "\"routing_key\":\"northentrust\"" +
        /**/                "}" +
        /**/            "]" +
        /**/        "}";
        /**/ /* <--- start of line comments here to maintain the readable indented structure of the JSON code */

        BusBuilderSchemaDefinition schemaDefinition = SchemaParser.parse(getClass().getResourceAsStream("/bb-latest.yaml"), Collections.emptyMap());

        ObjectMapper objectMapper = new ObjectMapper();

        String actualSchema = objectMapper.writeValueAsString(schemaDefinition);
        Assert.assertEquals(expectedSchema, actualSchema);


        StringBuilder builder = new StringBuilder();

        for (PrioritizedQueue prioritizedQueue : schemaDefinition.getPrioritizedQueues().values()) {

            for (Pair<Queue, QueuePriority> queuePriorityPair : prioritizedQueue.resolveQueues()) {
                builder.append(objectMapper.writeValueAsString(queuePriorityPair.getLeft())).append("\n");
            }

            for (Binding binding : prioritizedQueue.resolveBindings()) {
                builder.append(objectMapper.writeValueAsString(binding)).append("\n");
            }
        }
        String expectedPrioritizedQueue = "{\"name\":\"normalization.queue.vbstest.0\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.1\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.2\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.32\",\"durable\":true}\n" +
                "{\"source\":\"normalization.exchange\",\"destination\":\"normalization.queue.vbstest.0\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest.0\"}\n" +
                "{\"source\":\"normalization.exchange\",\"destination\":\"normalization.queue.vbstest.1\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest.1\"}\n" +
                "{\"source\":\"normalization.exchange\",\"destination\":\"normalization.queue.vbstest.2\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest.2\"}\n" +
                "{\"source\":\"normalization.exchange\",\"destination\":\"normalization.queue.vbstest.32\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest.32\"}\n" +
                "{\"name\":\"normalization.queue.vbstest.0\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.1\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.2\",\"durable\":true}\n" +
                "{\"name\":\"normalization.queue.vbstest.32\",\"durable\":true}\n" +
                "{\"source\":\"source_a.exchange\",\"destination\":\"normalization.queue.vbstest.0\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_a.0\"}\n" +
                "{\"source\":\"source_a.exchange\",\"destination\":\"normalization.queue.vbstest.1\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_a.1\"}\n" +
                "{\"source\":\"source_a.exchange\",\"destination\":\"normalization.queue.vbstest.2\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_a.2\"}\n" +
                "{\"source\":\"source_a.exchange\",\"destination\":\"normalization.queue.vbstest.32\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_a.32\"}\n" +
                "{\"source\":\"source_b.exchange\",\"destination\":\"normalization.queue.vbstest.0\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_b.0\"}\n" +
                "{\"source\":\"source_b.exchange\",\"destination\":\"normalization.queue.vbstest.1\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_b.1\"}\n" +
                "{\"source\":\"source_b.exchange\",\"destination\":\"normalization.queue.vbstest.2\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_b.2\"}\n" +
                "{\"source\":\"source_b.exchange\",\"destination\":\"normalization.queue.vbstest.32\",\"destination_type\":\"queue\",\"routing_key\":\"vbstest_b.32\"}\n";
        Assert.assertEquals(expectedPrioritizedQueue, builder.toString());

    }
}
