package com.victorbuckservices.vbackbone.common.definition;

import static org.junit.Assert.assertEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.victorbuckservices.vbackbone.common.integration.message.RawMessageEnvelope;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by labrot on 12/02/2014.
 */
public class RawMessageEnvelopeSerDeserTest {

    private ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void serialize() throws IOException {

        RawMessageEnvelope messageEnvelope = new RawMessageEnvelope();
        messageEnvelope.setBody("{\"foo\":\"bar\"}".getBytes());

        String asJson = new String(objectMapper.writeValueAsBytes(messageEnvelope));
        assertEquals("{\"header\":null,\"body\":{\"foo\":\"bar\"}}", asJson);
        assertEquals("{\"header\":null,\"body\":{\"foo\":\"bar\"}}", objectMapper.writeValueAsString(messageEnvelope));

        RawMessageEnvelope expectedMessageEnvelope = objectMapper.readValue(asJson, RawMessageEnvelope.class);
        assertEquals("{\"foo\":\"bar\"}", new String(expectedMessageEnvelope.getBody()));
    }

}
