package com.victorbuckservices.vbackbone.shared.definition;

import com.victorbuckservices.vbackbone.common.utils.UrnHelper;

/**
 * Enum interface that must be implemented for each service.
 *
 * @author Marc Plouhinec
 *         Created on 14/10/2014
 */
public interface Service {

    /**
     * E.g. "urn:vbs:service:vbackbone:filegateway:1.0"
     * @return Unique identifier for a specific service version.
     */
    String getUrn();

    /**
     * E.g. "File Gateway"
     * @return Service name.
     */
    String getName();

    /**
     * E.g. "1.0"
     * @return Service version.
     */
    default String getVersion() {
        return UrnHelper.extractVersion(getUrn());
    }
}
