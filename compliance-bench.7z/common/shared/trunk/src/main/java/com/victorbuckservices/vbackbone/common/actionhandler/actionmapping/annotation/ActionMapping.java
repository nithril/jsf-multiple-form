package com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.annotation;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by nlabrot on 28/11/14.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface ActionMapping {

    /**
     * Action urn
     *
     * @return
     */
    String urn();

    /**
     * Not used
     *
     * @return
     */
    String mimeType() default "";

    /**
     * Nack and requeue for the provided exception list
     * @return
     */
    Class<? extends Throwable>[] nackAndRequeueFor() default {};

    /**
     * Nack and dequeue for the provided exception list
     * @return
     */
    Class<? extends Throwable>[] nackAndDequeueFor() default {};

    /**
     * Not used
     * @return
     */
    String expression() default "";
}
