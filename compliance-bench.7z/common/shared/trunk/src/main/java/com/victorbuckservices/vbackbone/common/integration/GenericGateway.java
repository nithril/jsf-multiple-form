package com.victorbuckservices.vbackbone.common.integration;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import com.victorbuckservices.vbackbone.shared.definition.VbackboneHeaders;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import java.io.IOException;

import static java.util.Objects.requireNonNull;

/**
 * Generic Gateway with abstract methods implemented using final fields
 *
 * @author labrot
 *
 */
public class GenericGateway implements Gateway {

    private static final Logger LOG = LoggerFactory.getLogger(GenericGateway.class);

    @Autowired
    private CommonConversionService commonConversionService;

    private final MessageChannel messageChannel;

    public GenericGateway(MessageChannel messageChannel) {
        this.messageChannel = requireNonNull(messageChannel);
    }


    @Override
    public boolean sendMessage(String routingKey, MessageEnvelopeHeader header, Object body) throws IOException {
        Message message = commonConversionService.buildMessage(header, body);
        return getMessageChannel().send(MessageBuilder.fromMessage(message).setHeader(VbackboneHeaders.ROUTING_KEY , routingKey).build());
    }

    @Override
    public boolean sendMessage(MessageEnvelopeHeader header, Object body) throws IOException {
        return getMessageChannel().send(commonConversionService.buildMessage(header, body));
    }

    @Override
    public MessageChannel getMessageChannel() {
        return messageChannel;
    }

}
