package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.victorbuckservices.vbackbone.common.definition.UnknownAction;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.shared.definition.Action;

import java.io.IOException;

/**
 * Deserializer for {@link com.victorbuckservices.vbackbone.shared.definition.Action}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public class ActionDeserializer extends VbackboneDeserializerBase<Action> {

    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    /**
     * Create a new {@link ActionDeserializer}.
     */
    public ActionDeserializer(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService)
    {
        super(Action.class);
        this.serviceDefinitionDirectoryService = serviceDefinitionDirectoryService;
    }

    @Override
    public Action deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        if (parser.getCurrentToken() != JsonToken.VALUE_STRING) {
            throw context.mappingException("Expected type string.");
        }
        String urn = parser.getText().trim();
        Action action = serviceDefinitionDirectoryService.findActionByUrn(urn);
        return action == null ? new UnknownAction(urn) : action;
    }
}
