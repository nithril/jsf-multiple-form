package com.victorbuckservices.vbackbone.common.utils.stream;

import com.victorbuckservices.vbackbone.common.exception.BadInputException;
import com.victorbuckservices.vbackbone.common.utils.iterator.CloseableSpliterator;
import com.victorbuckservices.vbackbone.common.utils.lambda.IoCloser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Objects;
import java.util.Spliterator;
import java.util.function.Consumer;

/**
 * Abstract class to ease the creation of spliterator parser.
 * Returned element cannot be null as it mark the end of the stream
 * <p>
 * Created on 16/09/2015
 *
 * @author labrot
 */
public abstract class AbstractSpliterator<T> implements CloseableSpliterator<T> {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractSpliterator.class);

    protected boolean isClosed = false;
    protected boolean isInitialized = false;
    protected boolean hasMoreElement = true;

    @Override
    public boolean tryAdvance(Consumer<? super T> action) {
        Objects.requireNonNull(action);
        try {
            if (hasMoreElement) {
                T elem = preProcessAndReadNext();
                if (elem != null) {
                    action.accept(elem);
                    return true;
                } else {
                    hasMoreElement = false;
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            throw new BadInputException(e);
        }
    }

    @Override
    public Spliterator trySplit() {
        return null;
    }

    @Override
    public long estimateSize() {
        return Long.MAX_VALUE;
    }

    @Override
    public int characteristics() {
        return Spliterator.NONNULL | Spliterator.DISTINCT;
    }


    @Override
    public void close() throws IOException {
        if (!isClosed && isInitialized) {
            isClosed = true;
            try {
                closeQuietly().get();
            } catch (Exception e) {
                throw new IOException("Unable to close the XmlStream", e);
            }
        }
    }


    protected void preprocess() {
        checkIfClosed();
        initIfNeeded();
    }

    protected T preProcessAndReadNext() throws Exception {
        preprocess();
        return readNext();
    }

    protected void checkIfClosed() {
        if (isClosed) {
            LOG.error("Already closed!");
            throw new IllegalStateException("Already closed!");
        }
    }

    /**
     * Parse the next item
     *
     * @return return the read item or null if there is no item
     */
    protected abstract T readNext() throws Exception;

    /**
     * Initialize the resources
     */
    protected abstract void initIfNeeded();

    /**
     * Close quietly the resources
     *
     * @return the {@link IoCloser} instance used to close the resources
     */
    protected abstract IoCloser closeQuietly();


}
