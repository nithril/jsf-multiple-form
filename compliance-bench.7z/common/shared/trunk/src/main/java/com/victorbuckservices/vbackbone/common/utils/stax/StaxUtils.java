package com.victorbuckservices.vbackbone.common.utils.stax;

import javax.xml.stream.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import java.io.Writer;

/**
 * @author Lardinois
 *         Created on 24/02/2015
 */
public final class StaxUtils {

    private StaxUtils() {
    }

    /**
     * Stream filter to avoid indentation events
     *
     * @return StreamFilter
     */
    public static StreamFilter getIndentationFilter() {
        return new StreamFilter() {
            public boolean accept(XMLStreamReader r) {
                return !r.isWhiteSpace();
            }
        };
    }

    /**
     * Skip the current node (and its children) from xmlStreamReader
     *
     * @param reader
     * @throws XMLStreamException
     */
    public static void skipElement(XMLStreamReader reader) throws XMLStreamException {

        // number of elements read in
        int read = 0;
        int event = reader.getEventType();

        while (reader.hasNext()) {

            switch (event) {
                case XMLStreamConstants.START_ELEMENT:
                    read++;
                    break;
                case XMLStreamConstants.END_ELEMENT:
                    read--;
                    if (read <= 0) {
                        return;
                    }
                    break;
            }
            event = reader.next();
        }
    }

    /**
     * Copy the current node (and its children) from xmlStreamReader to xmlStreamWriter
     *
     * @param reader
     * @param writer
     * @throws javax.xml.stream.XMLStreamException
     */
    public static void copy(XMLStreamReader reader, XMLStreamWriter writer) throws XMLStreamException {
        copy(reader, writer, false);
    }

    /**
     * Copy the current node (and potentially its children according to @param fragment) of  from xmlStreamReader to xmlStreamWriter
     *
     * @param reader
     * @param writer
     * @param fragment
     * @throws javax.xml.stream.XMLStreamException
     */
    public static void copy(XMLStreamReader reader, XMLStreamWriter writer, boolean fragment) throws XMLStreamException {

        // number of elements read in
        int read = 0;
        int event = reader.getEventType();

        while (reader.hasNext()) {

            switch (event) {
                case XMLStreamConstants.START_ELEMENT:
                    read++;
                    writeStartElement(reader, writer);
                    break;
                case XMLStreamConstants.END_ELEMENT:
                    writer.writeEndElement();
                    read--;
                    if (read <= 0 && !fragment) {
                        return;
                    }
                    break;
                case XMLStreamConstants.CHARACTERS:
                    writer.writeCharacters(reader.getText());
                    break;
                case XMLStreamConstants.START_DOCUMENT:
                case XMLStreamConstants.END_DOCUMENT:
                case XMLStreamConstants.ATTRIBUTE:
                case XMLStreamConstants.NAMESPACE:
                    break;
                default:
                    break;
            }
            event = reader.next();
        }
    }

    /**
     * Copy only the current node from xmlStreamReader to xmlStreamWriter
     *
     * @param reader
     * @param writer
     * @throws javax.xml.stream.XMLStreamException
     */
    public static void writeStartElement(XMLStreamReader reader, XMLStreamWriter writer) throws XMLStreamException {

        String local = reader.getLocalName();
        String uri = reader.getNamespaceURI();
        String prefix = reader.getPrefix();
        if (prefix == null) {
            prefix = "";
        }


//        System.out.println("STAXUTILS:writeStartElement : node name : " + local +  " namespace URI" + uri);
        boolean writeElementNS = false;
        if (uri != null) {
            String boundPrefix = writer.getPrefix(uri);
            if (boundPrefix == null || !prefix.equals(boundPrefix)) {
                writeElementNS = true;
            }
        }

        // Write out the element name
        if (uri != null) {
            if (prefix.length() == 0 && uri.trim().length() <= 0) { //[org.apache.cxf.common.util.StringUtils.isEmpty(uri)] replaced by [uri.trim().length() <= 0]
                writer.writeStartElement(local);
                writer.setDefaultNamespace(uri);

            } else {
                writer.writeStartElement(prefix, local, uri);
                writer.setPrefix(prefix, uri);
            }
        } else {
            writer.writeStartElement(local);
        }

        // Write out the namespaces
        for (int i = 0; i < reader.getNamespaceCount(); i++) {
            String nsURI = reader.getNamespaceURI(i);
            String nsPrefix = reader.getNamespacePrefix(i);
            if (nsPrefix == null) {
                nsPrefix = "";
            }

            if (nsPrefix.length() == 0) {
                writer.writeDefaultNamespace(nsURI);
            } else {
                writer.writeNamespace(nsPrefix, nsURI);
            }

            if (nsURI.equals(uri) && nsPrefix.equals(prefix)) {
                writeElementNS = false;
            }
        }

        // Check if the namespace still needs to be written.
        // We need this check because namespace writing works
        // different on Woodstox and the RI.
        if (writeElementNS) {
            if (prefix == null || prefix.length() == 0) {
                writer.writeDefaultNamespace(uri);
            } else {
                writer.writeNamespace(prefix, uri);
            }
        }

        // Write out attributes
        for (int i = 0; i < reader.getAttributeCount(); i++) {
            String ns = reader.getAttributeNamespace(i);
            String nsPrefix = reader.getAttributePrefix(i);
            if (ns == null || ns.length() == 0) {
                writer.writeAttribute(reader.getAttributeLocalName(i), reader.getAttributeValue(i));
            } else if (nsPrefix == null || nsPrefix.length() == 0) {
                writer.writeAttribute(reader.getAttributeNamespace(i), reader.getAttributeLocalName(i),
                        reader.getAttributeValue(i));
            } else {
                writer.writeAttribute(reader.getAttributePrefix(i), reader.getAttributeNamespace(i), reader
                        .getAttributeLocalName(i), reader.getAttributeValue(i));
            }

        }
    }

    /**
     * return attribute value of current node
     *
     * @param reader
     * @param attributeName
     * @return
     */
    public static String getAttributeValue(XMLStreamReader reader, String attributeName) {

        for (int i = 0; i < reader.getAttributeCount(); i++) {
            if (reader.getAttributeLocalName(i).equals(attributeName)) {
                return reader.getAttributeValue(i);
            }
        }
        return null;
    }


    /**
     * Write the current node fragment and all its descendant to the provided writer
     * @param reader
     * @param writer
     * @throws TransformerException
     */
    public static void fromStreamReaderFragmentToWriter(XMLStreamReader reader, Writer writer) throws TransformerException {
        StAXSource domSource = new StAXSource(reader);
        StreamResult result = new StreamResult(writer);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        transformer.transform(domSource, result);
    }


    /**
     * Execute {@link XMLStreamReader#nextTag()} and check the tag local name is equals to the given value.
     */
    public static void readNextTagAndValidateLocalName(final XMLStreamReader reader, final String expectedLocalName) throws XMLStreamException {
        reader.nextTag();

        String localName = reader.getLocalName();
        if (!localName.equals(expectedLocalName)) {
            throw new XMLStreamException("Invalid tag local name (expected: " + expectedLocalName + ", actual: " + localName + ").");
        }
    }

    /**
     * Execute {@link XMLStreamReader#next()} until the current value is a tag.
     */
    public static void readUntilNextTag(final XMLStreamReader reader) throws XMLStreamException {
        do {
            reader.next();
        } while (!reader.isStartElement() && !reader.isEndElement());
    }

    /**
     * Create a text element
     * @param writer
     * @param name
     * @param text
     * @return
     * @throws XMLStreamException
     */
    public static XMLStreamWriter writeTextElement(XMLStreamWriter writer , String name, String text) throws XMLStreamException {
        writer.writeStartElement(name);
        writer.writeCharacters(text);
        writer.writeEndElement();
        return writer;
    }

}
