package com.victorbuckservices.vbackbone.common.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.victorbuckservices.vbackbone.common.integration.CommonHeaderContextPropertyName;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.service.ObjectMapperService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created on 02/20/2015
 *
 * @author labrot
 */
@Service
public class LoggingHelper {

    private static final Logger LOG = LoggerFactory.getLogger(LoggingHelper.class);

    @Autowired
    private ObjectMapperService mapperService;


    public String toString(MessageEnvelopeHeader messageEnvelopeHeader, Object body, Exception e) {
        StringBuilder builder = new StringBuilder(200);
        builder.append("VbackboneMessage{");
        builder.append("MessageEnvelopeHeader=").append(messageEnvelopeHeader != null ? toJson(messageEnvelopeHeader) : "null");
        builder.append(", Body=").append(body);
        if (e != null) {
            builder.append(", Exception=").append(e);
        }
        builder.append("}");

        return builder.toString();
    }

    public String toString(MessageHeaders messageHeaders, Exception e) {
        StringBuilder builder = new StringBuilder(200);
        builder.append("VbackboneMessage{");
        builder.append("MessageHeaders=").append(messageHeaders != null ? toJson(messageHeaders) : "null");
        if (e != null) {
            builder.append(", Exception=").append(e);
        }
        builder.append("}");
        return builder.toString();
    }

    public Object lazyToString(MessageEnvelopeHeader messageEnvelopeHeader, Object body, Exception e){
        return new Object(){
            @Override
            public String toString() {
                return LoggingHelper.this.toString(messageEnvelopeHeader , body , e);
            }
        };
    }


    public Object lazyToString(MessageHeaders messageHeaders, Exception e){
        return new Object(){
            @Override
            public String toString() {
                return LoggingHelper.this.toString(messageHeaders , e);
            }
        };
    }

    public void fillMdcWithContextProperties(Map<String, ? extends Object> contextProperties) {
        if (contextProperties == null){
            return;
        }

        for (String key : CommonHeaderContextPropertyName.PROPERTIES_IN_MDC) {
            Object value = contextProperties.get(key);
            if (value != null) {
                MDC.put(key, String.valueOf(value));
            }
        }
    }

    public void clearMdcOfContextProperties() {
        for (String key : CommonHeaderContextPropertyName.PROPERTIES_IN_MDC) {
            MDC.remove(key);
        }
    }

    private String toJson(Object header) {
        try {
            return mapperService.jsonMapper().writeValueAsString(header);
        } catch (JsonProcessingException e) {
            LOG.error(e.getMessage(), e);
            return "Unserializable Object [" + e.getMessage() + "]";
        }
    }
}
