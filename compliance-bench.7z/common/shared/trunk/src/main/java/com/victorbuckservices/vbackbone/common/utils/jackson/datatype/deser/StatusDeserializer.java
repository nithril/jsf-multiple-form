package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.victorbuckservices.vbackbone.common.definition.UnknownStatus;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.shared.definition.Status;

import java.io.IOException;

/**
 * Deserializer for {@link Status}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public class StatusDeserializer extends VbackboneDeserializerBase<Status> {

    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    /**
     * Create a new {@link StatusDeserializer}.
     */
    public StatusDeserializer(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService)
    {
        super(Status.class);
        this.serviceDefinitionDirectoryService = serviceDefinitionDirectoryService;
    }

    @Override
    public Status deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        if (parser.getCurrentToken() != JsonToken.VALUE_STRING) {
            throw context.mappingException("Expected type string.");
        }
        String urn = parser.getText().trim();
        Status status = serviceDefinitionDirectoryService.findStatusByUrn(urn);
        return status == null ? new UnknownStatus(urn) : status;
    }
}
