package com.victorbuckservices.vbackbone.common.integration.message;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import org.springframework.util.MimeType;

/**
 * Contain all the message headers.<br/>
 * Warning: do not mix a {@link MessageHeader} with a {@link MessageEnvelopeHeader}.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public class MessageHeader {

    private String messageId;

    private MimeType contentType;
    private Long timestamp;
    private Action action;
    private ReportLevel statusLevel;

    private String replyTo;
    private String routingKeys;


    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    /**
     * Getter for property 'contentType'.
     *
     * @return Value for property 'contentType'.
     */
    public MimeType getContentType() {
        return contentType;
    }

    /**
     * Setter for property 'contentType'.
     *
     * @param contentType Value to set for property 'contentType'.
     */
    public void setContentType(MimeType contentType) {
        this.contentType = contentType;
    }

    /**
     * Getter for property 'timestamp'.
     *
     * @return Value for property 'timestamp'.
     */
    public Long getTimestamp() {
        return timestamp;
    }

    /**
     * Setter for property 'timestamp'.
     *
     * @param timestamp Value to set for property 'timestamp'.
     */
    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Getter for property 'action'.
     *
     * @return Value for property 'action'.
     */
    public Action getAction() {
        return action;
    }

    /**
     * Setter for property 'action'.
     *
     * @param action Value to set for property 'action'.
     */
    public void setAction(Action action) {
        this.action = action;
    }

    /**
     * Getter for property 'statusLevel'.
     *
     * @return Value for property 'statusLevel'.
     */
    public ReportLevel getStatusLevel() {
        return statusLevel;
    }

    /**
     * Setter for property 'statusLevel'.
     *
     * @param statusLevel Value to set for property 'statusLevel'.
     */
    public void setStatusLevel(ReportLevel statusLevel) {
        this.statusLevel = statusLevel;
    }


    public String getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }


    public String getRoutingKeys() {
        return routingKeys;
    }

    public void setRoutingKeys(String routingKeys) {
        this.routingKeys = routingKeys;
    }


    @Override
    public String toString() {
        return "MessageHeader{" +
                "contentType=" + contentType +
                ", timestamp=" + timestamp +
                ", action=" + action +
                ", statusLevel=" + statusLevel +
                '}';
    }
}
