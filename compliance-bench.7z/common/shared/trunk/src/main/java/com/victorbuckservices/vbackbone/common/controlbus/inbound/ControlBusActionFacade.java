package com.victorbuckservices.vbackbone.common.controlbus.inbound;

import static com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusCommonAction.Constants.START_CONSUMERS_REQUEST;
import static com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusCommonAction.Constants.STOP_CONSUMERS_REQUEST;

import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.annotation.ActionMapping;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class ControlBusActionFacade {

    @Autowired
    private ControlBusActionService controlBusActionService;

    @ActionMapping(urn = START_CONSUMERS_REQUEST)
    public void startConsumers() {
        controlBusActionService.startConsumers();
    }

    @ActionMapping(urn = STOP_CONSUMERS_REQUEST)
    public void stopConsumers() {
        controlBusActionService.stopConsumers();
    }
}
