package com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.handler;

import static com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException.newNackAndDequeueException;
import static com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException.newNackAndRequeueException;

import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.ActionDefinition;
import com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException;
import com.victorbuckservices.vbackbone.common.actionhandler.handler.Handler;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Optional;

/**
 * Created on 02/02/2015
 *
 * @author labrot
 */
public class ActionMappingInterceptor implements Handler {

    private static final Logger LOG = LoggerFactory.getLogger(ActionMappingInterceptor.class);

    private final ActionDefinition actionDefinition;

    public ActionMappingInterceptor(ActionDefinition actionDefinition) {
        this.actionDefinition = actionDefinition;
    }

    @Override
    public boolean test(GenericMessageEnvelope messageEnvelope) {
        Validate.notNull(messageEnvelope);
        return Optional.ofNullable(messageEnvelope.getHeader())
                .map(MessageEnvelopeHeader::getAction)
                .map(action -> actionDefinition.getActionUrn().equals(action.getUrn()))
                .orElse(false);
    }

    @Override
    public Object invoke(GenericMessageEnvelope messageEnvelope) throws InvocationException {

        try {
            return invokeAction(messageEnvelope);

        } catch (IllegalAccessException e) {
            //Bug
            LOG.error(e.getMessage(), e);
            throw newNackAndRequeueException(e);

        } catch (IllegalArgumentException e) {
            //Bug
            LOG.error(e.getMessage(), e);
            throw newNackAndRequeueException(e);

        } catch (InvocationTargetException e) {
            LOG.error(e.getMessage(), e);
            Throwable targetException = e.getTargetException();

            if (actionDefinition.hasNackAndRequeues() || actionDefinition.hasNackAndDequeues()) {
                Pair<Boolean, Boolean> pair = actionDefinition.resolveNackFor(targetException.getClass());
                boolean nack = pair.getLeft();
                boolean requeue = pair.getRight();
                throw InvocationException.newException(e, nack, requeue);

            } else {
                if (targetException instanceof RuntimeException) {
                    // Unexpected, bug?
                    throw newNackAndRequeueException(targetException);
                } else {
                    // Checked, ack
                    throw newNackAndDequeueException(targetException);
                }
            }
        }

    }

    private Object invokeAction(GenericMessageEnvelope<?> messageEnvelope) throws InvocationTargetException, IllegalAccessException {
        Class bodyClass = messageEnvelope.getBody().getClass();
        Action action = messageEnvelope.getHeader().getAction();

        Object[] args = Arrays.stream(actionDefinition.getMethod().getParameters()).map(p -> {
            // TODO: handle Status, MimeType...
            if (p.getType().isAssignableFrom(bodyClass)) {
                return messageEnvelope.getBody();
            } else if (p.getType().isAssignableFrom(GenericMessageEnvelope.class)) {
                return messageEnvelope;
            } else if (p.getType().isAssignableFrom(MessageEnvelopeHeader.class)) {
                return messageEnvelope.getHeader();
            } else if (p.getType().isAssignableFrom(action.getClass())) {
                return action;
            } else {
                return null;
            }
        }).toArray();

        return actionDefinition.getMethod().invoke(actionDefinition.getBean(), args);
    }

    public ActionDefinition getActionDefinition() {
        return actionDefinition;
    }
}
