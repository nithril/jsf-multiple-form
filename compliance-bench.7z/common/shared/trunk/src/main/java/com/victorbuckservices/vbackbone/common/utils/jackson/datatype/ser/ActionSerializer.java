package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.victorbuckservices.vbackbone.shared.definition.Action;

import java.io.IOException;

/**
 * Serializer for {@link com.victorbuckservices.vbackbone.shared.definition.Action}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public final class ActionSerializer extends VbackboneSerializerBase<Action> {
    public static final ActionSerializer INSTANCE = new ActionSerializer();

    private ActionSerializer()
    {
        super(Action.class);
    }

    @Override
    public void serialize(Action action, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeString(action.getUrn());
    }
}
