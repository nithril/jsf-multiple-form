package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import org.springframework.messaging.Message;

import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * https://github.com/nithril/article-fair-consuming-with-rabbitmq
 */
public class FairConsumerSlot {
    private final long quantum;
    private final String queueName;
    private long deficit;
    private long processedMsg;

    private final ConcurrentLinkedDeque<Message<?>> messages = new ConcurrentLinkedDeque<>();

    public FairConsumerSlot(String queueName, long quantum) {
        this.queueName = queueName;
        this.quantum = quantum;
    }

    public void reset(){
        deficit = 0;
    }

    public long reduceDeficit(){
        deficit = deficit + quantum;
        return deficit;
    }

    public long increaseDeficit(long cost){
        deficit = deficit - cost;
        processedMsg = processedMsg + 1;
        return deficit;
    }

    public long getDeficit() {
        return deficit;
    }

    public long getQuantum() {
        return quantum;
    }

    public long getProcessedMsg() {
        return processedMsg;
    }

    public String getQueueName() {
        return queueName;
    }

    public void addMessage(Message<?> message){
        messages.add(message);
    }

    public boolean hasMessage(){
        return !messages.isEmpty();
    }

    public Collection<Message<?>> getMessages() {
        return Collections.unmodifiableCollection(messages);
    }

    public Message<?> poll(){
        return messages.poll();
    }


    @Override
    public String toString() {
        return "FairConsumerSlot{" +
                "quantum=" + quantum +
                ", queueName='" + queueName + '\'' +
                ", deficit=" + deficit +
                ", processedMsg=" + processedMsg +
                '}';
    }
}
