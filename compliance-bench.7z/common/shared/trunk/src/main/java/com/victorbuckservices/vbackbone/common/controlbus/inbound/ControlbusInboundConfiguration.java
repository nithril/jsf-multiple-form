package com.victorbuckservices.vbackbone.common.controlbus.inbound;

import com.victorbuckservices.vbackbone.common.actionhandler.ActionDispatcher;
import com.victorbuckservices.vbackbone.common.controlbus.helper.ControlbusHelper;
import com.victorbuckservices.vbackbone.common.service.IdentificationService;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.amqp.inbound.AmqpInboundChannelAdapter;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.StandardIntegrationFlow;
import org.springframework.integration.dsl.amqp.Amqp;
import org.springframework.integration.dsl.channel.MessageChannels;
import org.springframework.messaging.MessageChannel;

/**
 * Created on 08/20/2015
 *
 * @author labrot
 */
@Configuration
public class ControlbusInboundConfiguration {

    public static final String CHANNEL_CONTROLBUS_SERVICE_IN = "controlbus.service.in.channel";

    public static final String BEAN_CONTROLBUS_INBOUND_ADAPTER = "controlbusInboundAdapter";

    //The controlbus exchange name is defined in the bus builder project
    //TODO: analyse if it is pertinent to depends on the busbuilder
    @Value("${vbackbone.controlbus.exchange.name:vbackbone.controlbus.exchange}")
    private String controlbusExchangeName;

    @Autowired
    private IdentificationService identificationService;


    @Bean
    @Profile("production")
    public Queue controlBusQueue() {
        return new Queue(ControlbusHelper.constructControlbusQueueName(identificationService.getName(), identificationService.getInstanceId()), false, true, false);
    }

    @Bean
    @Profile("production")
    public Binding controlbusQueueToExchange() {
        return BindingBuilder.bind(controlBusQueue()).to(new DirectExchange(controlbusExchangeName)).with(ControlbusHelper.constructControlbusRoutingKey(identificationService.getName(), identificationService.getInstanceId()));
    }

    /**
     * @return Configured {@link org.springframework.messaging.MessageChannel} of name {@link #CHANNEL_CONTROLBUS_SERVICE_IN}
     */
    @Bean(name = CHANNEL_CONTROLBUS_SERVICE_IN)
    public MessageChannel controlbusServiceInChannel() {
        return MessageChannels.direct(CHANNEL_CONTROLBUS_SERVICE_IN).get();
    }


    /**
     * @return Configured AMQP outbound adapter linked to the {@link #controlbusServiceInChannel()}.
     */
    @Bean
    public IntegrationFlow controlbusServiceInboundFlow(ActionDispatcher actionDispatcher) {
        return IntegrationFlows.from(controlbusServiceInChannel()).handle(actionDispatcher::dispatch).get();
    }

    /**
     * @return Configured AMQP outbound adapter linked to the {@link #controlbusServiceInChannel()}.
     */
    @Bean
    @Profile("production")
    public IntegrationFlow amqpControlbusServiceInboundFlow(ConnectionFactory connectionFactory, AmqpHeaderMapper mapAllHeadersHeaderMapper) {
        StandardIntegrationFlow standardIntegrationFlow = IntegrationFlows
                .from(
                        Amqp.inboundAdapter(connectionFactory, controlBusQueue())
                                .acknowledgeMode(AcknowledgeMode.MANUAL)
                                .headerMapper(mapAllHeadersHeaderMapper)
                )
                .channel(controlbusServiceInChannel())
                .get();

        //Find the AmqpInboundChannelAdapter and set its name
        AmqpInboundChannelAdapter controlbusInboundAdapter = standardIntegrationFlow
                .getIntegrationComponents()
                .stream()
                .filter(AmqpInboundChannelAdapter.class::isInstance)
                .map(AmqpInboundChannelAdapter.class::cast)
                .findFirst()
                .get();

        controlbusInboundAdapter.setBeanName(BEAN_CONTROLBUS_INBOUND_ADAPTER);

        return standardIntegrationFlow;
    }

    @Bean
    public ControlBusActionFacade controlBusActionFacade() {
        return new ControlBusActionFacade();
    }

    @Bean
    public ControlBusActionService controlBusActionService() {
        return new ControlBusActionService();
    }


}
