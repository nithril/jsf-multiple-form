package com.victorbuckservices.vbackbone.shared.definition.dto;

import com.victorbuckservices.vbackbone.shared.definition.Status;

/**
 * DTO sent when the response message represent a problem.
 *
 * @author Marc Plouhinec
 *         Created on 11/21/2014.
 */
public class Problem {

    private Status status;
    private String title;
    private String detail;

    /**
     * Getter for property 'status'.
     *
     * @return Value for property 'status'.
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Setter for property 'status'.
     *
     * @param status Value to set for property 'status'.
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Getter for property 'title'.
     *
     * @return Value for property 'title'.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Setter for property 'title'.
     *
     * @param title Value to set for property 'title'.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Getter for property 'detail'.
     *
     * @return Value for property 'detail'.
     */
    public String getDetail() {
        return detail;
    }

    /**
     * Setter for property 'detail'.
     *
     * @param detail Value to set for property 'detail'.
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Override
    public String toString() {
        return "Problem{" +
                "status=" + status +
                ", title='" + title + '\'' +
                ", detail='" + detail + '\'' +
                '}';
    }
}
