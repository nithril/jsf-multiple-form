package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import com.victorbuckservices.vbackbone.common.integration.fairconsuming.exception.NormallyStopConsumingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.endpoint.MessageProducerSupport;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
public class FairAggregator extends MessageProducerSupport implements MessageProducer, MessageHandler {
    private static final Logger LOG = LoggerFactory.getLogger(FairAggregator.class);

    public static final int MESSAGE_WEIGHT = 4;

    private final List<FairConsumerSlot> slots;

    private volatile boolean stopProcessing;
    private Semaphore consumerToken = new Semaphore(0);

    private ExecutorService messageExecutorService;

    private volatile String outputChannelName;


    public FairAggregator(List<FairConsumerSlot> slots) {
        this.slots = new CopyOnWriteArrayList<>(slots);
    }

    public FairAggregator(List<FairConsumerSlot> slots, ExecutorService executorService, String outputChannelName) {
        this(slots);
        this.messageExecutorService = executorService;
        this.outputChannelName = outputChannelName;
    }

    public FairAggregator(List<FairConsumerSlot> slots, ExecutorService executorService, MessageChannel outputChannel) {
        this(slots);
        this.messageExecutorService = executorService;
        setOutputChannel(outputChannel);
    }


    @Override
    protected void onInit() {
        if (outputChannelName != null) {
            setOutputChannel(getChannelResolver().resolveDestination(outputChannelName));
        }
        super.onInit();
    }

    @Override
    public void handleMessage(Message<?> m) throws MessagingException {
        consumerToken.release();
        String queueName = (String) m.getHeaders().get(AmqpHeaders.CONSUMER_QUEUE);
        FairConsumerSlot slot = slots.stream().filter(s -> s.getQueueName().equals(queueName)).findFirst().get();
        slot.addMessage(m);
    }

    public void setOutputChannelName(String outputChannelName) {
        this.outputChannelName = outputChannelName;
    }

    @Override
    protected void doStart() {
        stopProcessing = false;
        messageExecutorService.execute(this::run);
    }


    @Override
    protected void doStop() {
        stopProcessing = true;

        try {
            messageExecutorService.shutdownNow();
            messageExecutorService.awaitTermination(120, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            LOG.error(e.getMessage(), e);
        }
    }


    protected void run() {

        try { // TODO can I remove this try block and add Exception to signature?

            while (!stopProcessing) {
                //Try to acquire a consumer token, wait for 5 seconds
                if (consumerToken.tryAcquire(1, 5, TimeUnit.SECONDS)) {
                    //We got a token, a delivery is available
                    int processedMessageCounter = 0;
                    try {
                        for (FairConsumerSlot slot : slots) {

                            checkIfProcessingMustStopped();

                            //Each iteration reduces the deficit
                            slot.reduceDeficit();

                            //Loop until the slot does not contain any deliveries or until the slot deficit is bellow the message weight
                            while (slot.hasMessage() && slot.getDeficit() >= MESSAGE_WEIGHT) {

                                checkIfProcessingMustStopped();

                                Message<?> message = slot.poll();

                                slot.increaseDeficit(MESSAGE_WEIGHT);

                                //Consume
                                messageExecutorService.execute(() -> {
                                    try {
                                        sendMessage(message);
                                    } catch (Exception e) {
                                        LOG.error(e.getMessage(), e);
                                    }
                                });

                                processedMessageCounter++;
                            }

                            //If the slot does not contain any deliveries, reset the deficit
                            if (!slot.hasMessage()) {
                                slot.reset();
                            }
                        }
                    } finally {
                        if (processedMessageCounter > 0) {
                            //If we have processed message, we must acquire the number of processed message minus the first acquire
                            consumerToken.acquire(processedMessageCounter - 1);
                        } else {
                            //If we do not have processed message (because all deficit where < weight) we must release the token
                            consumerToken.release();
                        }
                    }
                }
            }
        } catch (InterruptedException e) {
            LOG.warn(e.getMessage(), e);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }


    private void checkIfProcessingMustStopped() throws NormallyStopConsumingException {
        if (stopProcessing) {
            throw new NormallyStopConsumingException();
        }
    }


}
