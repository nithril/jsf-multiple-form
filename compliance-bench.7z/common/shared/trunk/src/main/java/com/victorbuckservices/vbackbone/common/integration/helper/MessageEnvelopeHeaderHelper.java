package com.victorbuckservices.vbackbone.common.integration.helper;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.service.IdentificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZonedDateTime;

/**
 * Factory methods for {@link MessageEnvelopeHeader}
 *
 * @author Nicolas Labrot
 *         Created on 11/12/2014.
 */
@Component
public class MessageEnvelopeHeaderHelper {

    private static final Logger LOG = LoggerFactory.getLogger(MessageEnvelopeHeaderHelper.class);

    @Autowired
    private IdentificationService identificationService;

    /**
     * Factory method used to create a {@link MessageEnvelopeHeader.Builder} with pre-filled technical properties.
     */
    public MessageEnvelopeHeader.Builder newMessageEnvelopeHeaderBuilder() {
        return MessageEnvelopeHeader.newBuilder()
                .instant(ZonedDateTime.now().toInstant())
                .sourceHostname(identificationService.getHostname())
                .sourceServiceInstanceId(identificationService.getServiceInstanceId());
    }


    /**
     * Factory method used to create a {@link MessageEnvelopeHeader.Builder} with pre-filled technical properties and
     * with a copy of the given header context properties.
     */
    public MessageEnvelopeHeader.Builder newMessageEnvelopeHeaderBuilder(MessageEnvelopeHeader headerWithContextPropertiesToCopy) {
        return newMessageEnvelopeHeaderBuilder()
                .contextProperties(headerWithContextPropertiesToCopy.getContextProperties());
    }

    /**
     * Factory method used to create a {@link MessageEnvelopeHeader} with pre-filled technical properties.
     */
    public MessageEnvelopeHeader newMessageEnvelopeHeader() {
        return newMessageEnvelopeHeaderBuilder().build();
    }

    /**
     * Factory method used to create a {@link MessageEnvelopeHeader} with pre-filled technical properties and
     * with a copy of the given header context properties.
     */
    public MessageEnvelopeHeader newMessageEnvelopeHeader(MessageEnvelopeHeader headerWithContextPropertiesToCopy) {
        return newMessageEnvelopeHeaderBuilder(headerWithContextPropertiesToCopy).build();
    }
}
