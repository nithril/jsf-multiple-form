package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.victorbuckservices.vbackbone.common.definition.UnknownService;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.shared.definition.Service;

import java.io.IOException;

/**
 * Deserializer for {@link Service}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public class ServiceDeserializer extends VbackboneDeserializerBase<Service> {

    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    /**
     * Create a new {@link ServiceDeserializer}.
     */
    public ServiceDeserializer(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService)
    {
        super(Service.class);
        this.serviceDefinitionDirectoryService = serviceDefinitionDirectoryService;
    }

    @Override
    public Service deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        if (parser.getCurrentToken() != JsonToken.VALUE_STRING) {
            throw context.mappingException("Expected type string.");
        }
        String urn = parser.getText().trim();
        Service service = serviceDefinitionDirectoryService.findServiceByUrn(urn);
        return service == null ? new UnknownService(urn) : service;
    }
}
