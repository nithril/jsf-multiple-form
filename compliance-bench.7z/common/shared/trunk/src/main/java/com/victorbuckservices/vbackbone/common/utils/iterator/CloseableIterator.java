package com.victorbuckservices.vbackbone.common.utils.iterator;

import java.io.Closeable;
import java.util.Iterator;

/**
 * Closeable iterator
 *
 * Created on 15/09/2015
 *
 * @author labrot
 */
public interface CloseableIterator<T> extends Iterator<T>, Closeable {

}
