package com.victorbuckservices.vbackbone.common.integration.message;

/**
 * The goal of the envelope is to define an internal header and body inside the message payload.
 * The reason to not directly use the message header is the possibility to have an unlimited number
 * of custom properties without performance drop with RabbitMQ.
 *
 * @author nlabrot
 *         Created on 12/02/2014.
 */
public class GenericMessageEnvelope<T> {

    protected MessageEnvelopeHeader header;
    protected T body;

    /**
     * Create a new {@link com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope}.
     */
    public GenericMessageEnvelope() {
    }

    /**
     * Create a new {@link com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope}.
     */
    public GenericMessageEnvelope(MessageEnvelopeHeader header, T body) {
        this.header = header;
        this.body = body;
    }

    /**
     * Getter for property 'header'.
     *
     * @return Value for property 'header'.
     */
    public MessageEnvelopeHeader getHeader() {
        return header;
    }

    /**
     * Setter for property 'header'.
     *
     * @param header Value to set for property 'header'.
     */
    public void setHeader(MessageEnvelopeHeader header) {
        this.header = header;
    }

    /**
     * Getter for property 'body'.
     *
     * @return Value for property 'body'.
     */
    public T getBody() {
        return body;
    }

    /**
     * Setter for property 'body'.
     *
     * @param body Value to set for property 'body'.
     */
    public void setBody(T body) {
        this.body = body;
    }


    @Override
    public String toString() {
        return "GenericMessageEnvelope{" +
                "header=" + header +
                '}';
    }
}
