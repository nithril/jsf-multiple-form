package com.victorbuckservices.vbackbone.common.transaction;

import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.function.Consumer;

/**
 * Created on 02/26/2015
 *
 * @author labrot
 */
public final class SynchronizationTransactionHelper {

    private SynchronizationTransactionHelper() {
    }

    public static void registerAfterCommit(Runnable runnable){
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter(){
            public void afterCommit(){
                runnable.run();
            }
        });
    }

    public static void registerAfterCompletion(Consumer<Integer> consumer){
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter(){
            @Override
            public void afterCompletion(int status) {
                consumer.accept(status);
            }
        });
    }


}
