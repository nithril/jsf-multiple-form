package com.victorbuckservices.vbackbone.common.service;

import com.victorbuckservices.vbackbone.common.definition.CommonAction;
import com.victorbuckservices.vbackbone.common.definition.CommonService;
import com.victorbuckservices.vbackbone.common.definition.CommonVbbMimeType;
import com.victorbuckservices.vbackbone.shared.ServiceDefinition;
import com.victorbuckservices.vbackbone.shared.service.ServiceDefinitionProviderService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

/**
 * Default implementation of {@link CommonServiceDefinitionProviderService}.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
@Service
public class CommonServiceDefinitionProviderService implements ServiceDefinitionProviderService {

    public ServiceDefinition getServiceDefinition() {
        ServiceDefinition serviceDefinition = new ServiceDefinition();
        serviceDefinition.setServices(Arrays.asList(CommonService.values()));
        serviceDefinition.setActions(Arrays.asList(CommonAction.values()));
        serviceDefinition.setVbbMimeTypes(Arrays.asList(CommonVbbMimeType.values()));
        return serviceDefinition;
    }
}
