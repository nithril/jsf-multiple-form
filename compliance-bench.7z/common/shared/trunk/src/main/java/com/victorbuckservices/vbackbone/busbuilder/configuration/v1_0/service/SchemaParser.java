package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition.BusBuilderSchemaDefinition;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.exception.BusBuilderException;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.Map;

/**
 * Created by nithril on 18/11/14.
 */
public interface SchemaParser {

    Logger LOG = LoggerFactory.getLogger(SchemaParser.class);

    ObjectMapper objectMapper = new ObjectMapper(new YAMLFactory());

    static BusBuilderSchemaDefinition parse(InputStream file, Map<String, Object> args)  {

        try {
            StringTemplateLoader stringLoader = new StringTemplateLoader();
            Configuration configuration = new Configuration();
            configuration.setTemplateLoader(stringLoader);

            Template t = new Template("name", new InputStreamReader(file), configuration);

            StringWriter writer = new StringWriter();
            t.process(args, writer);

            YAMLFactory factory = new YAMLFactory();
            JsonParser parser = factory.createParser(writer.toString());
            parser.nextToken();
            parser.nextToken();

            String fieldName = parser.getCurrentName();

            parser.nextToken();
            BusBuilderSchemaDefinition busBuilderSchemaDefinition = objectMapper.readValue(parser, BusBuilderSchemaDefinition.class);

            busBuilderSchemaDefinition.setSchemaName(fieldName);

            return busBuilderSchemaDefinition;
        } catch (Exception e) {
            LOG.error(e.getMessage() , e);
            throw new BusBuilderException(e.getMessage(), e);
        }
    }


}
