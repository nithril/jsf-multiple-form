package com.victorbuckservices.vbackbone.common.actionhandler.actionmapping;

import com.victorbuckservices.vbackbone.common.actionhandler.ActionHandlerDirectories;
import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.annotation.ActionMapping;
import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.handler.ActionMappingHandler;
import org.reflections.ReflectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.Set;

/**
 * Created by nlabrot on 28/11/14.
 */
@Service
public class ActionMappingPostProcessor implements BeanPostProcessor, DestructionAwareBeanPostProcessor, Ordered {

    private static final Logger LOG = LoggerFactory.getLogger(ActionMappingPostProcessor.class);

    @Autowired
    private ActionHandlerDirectories actionInterceptorDirectories;

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

        Set<Method> resources = ReflectionUtils.getAllMethods(bean.getClass());

        for (Method method : resources) {
            AnnotationAttributes attributes = AnnotatedElementUtils.getAnnotationAttributes(method, ActionMapping.class.getName());

            if (attributes != null) {
                ActionDefinition actionDefinition = new ActionDefinition(bean, method, (String) attributes.get("urn"), (String) attributes.get("mimeType"),
                        (Class<? extends Throwable>[]) attributes.get("nackAndDequeueFor"), (Class<? extends Throwable>[]) attributes.get("nackAndRequeueFor")
                );

                ActionMappingHandler actionMappingInterceptor = new ActionMappingHandler(actionDefinition);

                actionInterceptorDirectories.addHandler(actionMappingInterceptor);

                LOG.info("Add ActionMapping Handler [{}]" , method);
            }
        }
        return bean;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }


    @Override
    public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException {
        actionInterceptorDirectories.removeIf(i -> i instanceof ActionMappingHandler && ((ActionMappingHandler) i).getActionDefinition().getBean() == bean);
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
