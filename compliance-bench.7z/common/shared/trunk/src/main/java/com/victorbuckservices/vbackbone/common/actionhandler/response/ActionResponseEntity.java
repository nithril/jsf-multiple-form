package com.victorbuckservices.vbackbone.common.actionhandler.response;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class ActionResponseEntity<T> {

    private final T body;

    private final ActionStatus status;

    public ActionResponseEntity(T body, ActionStatus status) {
        this.body = body;
        this.status = status;
    }

    public T getBody() {
        return body;
    }

    public ActionStatus getStatus() {
        return status;
    }


    public static final <T> ActionResponseEntity<T> ok(T body) {
        return new ActionResponseEntity(body, ActionStatus.OK);
    }

    public static final <T> ActionResponseEntity<T> error(T body) {
        return new ActionResponseEntity(body, ActionStatus.ERROR);
    }

    public static final <T> ActionResponseEntity<T> error() {
        return new ActionResponseEntity(null, ActionStatus.ERROR);
    }
}
