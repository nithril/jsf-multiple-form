package com.victorbuckservices.vbackbone.common.actionhandler.exception;

/**
 * Unexpected exception
 *
 * Created on 02/02/2015
 *
 * @author labrot
 */
public class UnexpectedException extends RuntimeException {

    public UnexpectedException(String message, Throwable cause) {
        super(message, cause);
    }
}
