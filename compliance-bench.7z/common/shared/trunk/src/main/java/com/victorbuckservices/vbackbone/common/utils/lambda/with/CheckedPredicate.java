package com.victorbuckservices.vbackbone.common.utils.lambda.with;


import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

import java.util.function.Predicate;

/**
 * Created by nlabrot on 10/03/15.
 */
@FunctionalInterface
public interface CheckedPredicate<T> extends Predicate<T> {

    boolean checkedTest(T t) throws Exception;

    @Override
    default boolean test(T t) throws UncheckedExecutionException{
        try {
            return checkedTest(t);
        } catch (Exception e) {
            throw new UncheckedExecutionException(e);
        }
    }
}
