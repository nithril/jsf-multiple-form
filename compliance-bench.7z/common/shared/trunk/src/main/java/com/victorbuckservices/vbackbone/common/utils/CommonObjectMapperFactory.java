package com.victorbuckservices.vbackbone.common.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.guava.GuavaModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.VbackboneModule;

/**
 * Create a configured {@link ObjectMapper}.
 *
 * @author Marc Plouhinec
 *         Created on 22/10/2014.
 */
public final class CommonObjectMapperFactory {

    private CommonObjectMapperFactory(){
    }

    /**
     * @return new configured {@link ObjectMapper} with a
     * {@link ServiceDefinitionDirectoryService}
     * See {@link #newObjectMapper()}
     */
    public static ObjectMapper newObjectMapper(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService) {
        ObjectMapper objectMapper = newObjectMapper();
        objectMapper.registerModule(new VbackboneModule(serviceDefinitionDirectoryService));
        return objectMapper;
    }

    /**
     * @return new configured {@link ObjectMapper} with a
     * {@link DeserializationFeature#FAIL_ON_UNKNOWN_PROPERTIES}
     * {@link DeserializationFeature#ACCEPT_SINGLE_VALUE_AS_ARRAY}
     * {@link JavaTimeModule}
     */
    public static ObjectMapper newObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new GuavaModule());
        return objectMapper;
    }
}
