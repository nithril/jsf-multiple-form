package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.common.actionhandler.ActionDispatcher;
import com.victorbuckservices.vbackbone.common.busbuilder.BusBuilderService;
import com.victorbuckservices.vbackbone.common.controlbus.inbound.ControlBusActionService;
import com.victorbuckservices.vbackbone.common.monitoring.MonitoringLogger;
import com.victorbuckservices.vbackbone.common.service.IdentificationService;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
@Configuration
@EnableScheduling
public class MonitoringConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(MonitoringConfiguration.class);

    @Autowired
    private IdentificationService identificationService;

    @Autowired
    private BusBuilderService busBuilderService;

    @Autowired
    private ControlBusActionService controlBusActionService;

    @Autowired
    private ActionDispatcher actionDispatcher;

    @Value("${monitoring.rabbitmq.excludedQueues:archiving.*}")
    private String[] excludedQueues = new String[]{"archiving.*"};

    @Bean
    public Runnable identificationScheduledTask() {

        return new Runnable() {
            @Override
            @Scheduled(fixedDelayString = "${monitoring.identification.delay:10000}")
            public void run() {
                MonitoringLogger.identification(identificationService);
            }
        };
    }


    @Bean
    @Profile("production")
    public Runnable queues(RabbitAdmin rabbitAdmin) {
        return new Runnable() {
            @Override
            @Scheduled(fixedDelayString = "${monitoring.identification.delay:10000}")
            public void run() {
                int queueMessageCount = -1;
                try {
                    queueMessageCount = getMonitoredQueues().stream()
                            .mapToInt(q -> {
                                Properties queueProperties = rabbitAdmin.getQueueProperties(q.getName());
                                if (queueProperties != null) {
                                    return (int) queueProperties.get("QUEUE_MESSAGE_COUNT");
                                } else {
                                    return 0;
                                }
                            }).sum();
                } catch (Exception e) {
                    LOG.warn(e.getMessage() , e);
                }
                MonitoringLogger.rabbitStatus(identificationService, controlBusActionService.isRunning(), queueMessageCount, actionDispatcher.getOngoingProcess());
            }
        };
    }


    public List<Queue> getMonitoredQueues(){
        return busBuilderService.getQueues().stream()
                .filter(q -> isQueueMonitored(q.getName()))
                .collect(Collectors.toList());
    }

    private boolean isQueueMonitored(String name) {
        for (String queuePatternStr : excludedQueues) {
            Pattern pattern = Pattern.compile(queuePatternStr);
            if (pattern.matcher(name).matches()) {
                return false;
            }
        }
        return true;
    }

}
