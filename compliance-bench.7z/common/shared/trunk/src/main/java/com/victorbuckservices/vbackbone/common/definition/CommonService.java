package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Service;

/**
 * Common {@link Service}s.
 *
 * @author Marc Plouhinec
 *         Created on 28/10/2014.
 */
public enum CommonService implements Service {
    UNKNOWN_SERVICE("urn:vbs:service:vbackbone:unknown:1.0", "Unknown");

    private final String urn;
    private final String name;

    CommonService(String urn, String name) {
        this.urn = urn;
        this.name = name;
    }

    @Override
    public String getUrn() {
        return this.urn;
    }

    @Override
    public String getName() {
        return name;
    }
}
