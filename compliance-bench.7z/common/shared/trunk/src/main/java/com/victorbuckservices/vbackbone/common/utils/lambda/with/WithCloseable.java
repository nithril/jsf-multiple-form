package com.victorbuckservices.vbackbone.common.utils.lambda.with;


import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

/**
 * Created by nlabrot on 10/03/15.
 */
public class WithCloseable<T extends AutoCloseable> {

    private final T with;

    protected WithCloseable(T with) {
        this.with = with;
    }

    public <R> R apply(CheckedFunction<T, R> f) throws UncheckedExecutionException {
        try (T is = with) {
            return f.apply(is);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }


    public static <T extends AutoCloseable> WithCloseable withResource(T with) {
        return new WithCloseable(with);
    }

    public static <T extends AutoCloseable,R> R withResource(T with, CheckedFunction<T, R> f) throws UncheckedExecutionException {
        WithCloseable<T> closeable = new WithCloseable(with);
        return closeable.apply(f);
    }
}
