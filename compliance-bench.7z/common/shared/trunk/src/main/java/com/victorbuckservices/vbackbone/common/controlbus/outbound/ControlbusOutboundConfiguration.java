package com.victorbuckservices.vbackbone.common.controlbus.outbound;

import com.victorbuckservices.vbackbone.common.integration.GenericGateway;
import com.victorbuckservices.vbackbone.common.utils.messagesqueue.MessagesQueueEndpoint;
import com.victorbuckservices.vbackbone.shared.definition.VbackboneHeaders;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.amqp.Amqp;
import org.springframework.integration.dsl.channel.MessageChannels;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

/**
 * Created on 08/20/2015
 *
 * @author labrot
 */
@Configuration
public class ControlbusOutboundConfiguration {

    public static final String CHANNEL_CONTROLBUS_OUT = "controlbus.out.channel";

    public static final String BEAN_CONTROLBUS_OUTBOUND_ADAPTER = "controlbusOutboundAdapter";

    //The controlbus exchange name is defined in the bus builder project
    //TODO: analyse if it is pertinent to depends on the busbuilder
    @Value("${vbackbone.controlbus.exchange.name:vbackbone.controlbus.exchange}")
    private String controlbusExchangeName;

    /**
     * @return Configured {@link org.springframework.messaging.MessageChannel} of name {@link #CHANNEL_CONTROLBUS_OUT}
     */
    @Bean(name = CHANNEL_CONTROLBUS_OUT)
    public MessageChannel controlbusOutChannel() {
        return MessageChannels.direct(CHANNEL_CONTROLBUS_OUT).get();
    }


    /**
     *
     * @return Configured {@link com.victorbuckservices.vbackbone.shared.integration.Gateway} of name dataManagerClientOutboundAdapter
     */
    @Bean(name = BEAN_CONTROLBUS_OUTBOUND_ADAPTER)
    public Gateway controlbusOutboundAdapter() {
        return new GenericGateway(controlbusOutChannel());
    }


    /**
     * @return Configured AMQP outbound adapter linked to the {@link #controlbusOutChannel()}.
     */
    @Bean
    @Profile("production")
    public IntegrationFlow amqpControlbusOutboundFlow(AmqpTemplate amqpTemplate, AmqpHeaderMapper mapAllHeadersHeaderMapper) {
        return IntegrationFlows
                .from(controlbusOutChannel())
                .handle(Amqp.outboundAdapter(amqpTemplate)
                        .exchangeName(controlbusExchangeName)
                        .routingKeyExpression(VbackboneHeaders.ROUTING_KEY_EXPRESSION)
                        .headerMapper(mapAllHeadersHeaderMapper)).get();
    }


    @Bean
    @Profile("test-controlbus-outbound-integration")
    public MessagesQueueEndpoint normalizationClientQueueOutbound() {
        return new MessagesQueueEndpoint();
    }

    @Bean
    @Profile("test-controlbus-outbound-integration")
    public IntegrationFlow normalizationClientServiceActivator(MessagesQueueEndpoint normalizationClientQueueOutbound) {
        return IntegrationFlows.from(controlbusOutChannel())
                .handle(m -> normalizationClientQueueOutbound.handleMessage((Message<byte[]>) m))
                .get();
    }



    @Bean
    public ControlbusOutboundApi controlbusOutboundApi(){
        return new ControlbusOutboundApi();
    }


}
