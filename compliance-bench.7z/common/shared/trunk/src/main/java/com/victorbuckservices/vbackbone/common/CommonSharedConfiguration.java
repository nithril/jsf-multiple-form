package com.victorbuckservices.vbackbone.common;

import com.victorbuckservices.vbackbone.common.configuration.UuidGeneratorConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.integration.annotation.IntegrationComponentScan;

/**
 * Configuration of the Common shared module.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
@Configuration
@ImportResource({"classpath:spring/common-rabbit-integration.xml"})
@Import({
        UuidGeneratorConfiguration.class
})
@ComponentScan({
        "com.victorbuckservices.vbackbone.common.service",
        "com.victorbuckservices.vbackbone.common.logging",
        "com.victorbuckservices.vbackbone.common.integration.helper",
        "com.victorbuckservices.vbackbone.common.actionhandler",
})
@IntegrationComponentScan("com.victorbuckservices.vbackbone.common.integration")
public class CommonSharedConfiguration {

}
