package com.victorbuckservices.vbackbone.common.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationPid;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * Created on 06/11/2015
 *
 * @author labrot
 */
@Configuration
public class InjectServiceNameAndPidPropertiesConfiguration {

    public static final String PID_KEY = "PID";
    public static final String SERVICE_NAME_KEY = "SERVICE_NAME";

    @Value("${service.name}")
    private String serviceName;

    @PostConstruct
    public void injectSystemProperties() {
        if (System.getProperty(PID_KEY) == null) {
            System.setProperty(PID_KEY, new ApplicationPid().toString());
        }
        if (System.getProperty(SERVICE_NAME_KEY) == null) {
            System.setProperty(SERVICE_NAME_KEY, serviceName);
        }
    }
}
