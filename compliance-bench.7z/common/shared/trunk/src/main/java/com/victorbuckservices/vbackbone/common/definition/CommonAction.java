package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;

/**
 * Common {@link Action}s.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public enum CommonAction implements Action {
    UNKNOWN_ACTION(
            "urn:vbs:action:vbackbone:common:unknown:1.0",
            "Unknown action",
            "When a message header contains an unknown action, the JSON deserializer instantiate an UnknownAction with an unknown action. " +
                    "The goal is to allow a service like Vgate or the Dashboard to be able to process a message even if it doesn't know a " +
                    "particular action.",
            CommonService.UNKNOWN_SERVICE
    );

    private final String urn;
    private final String name;
    private final String description;
    private final Service service;

    CommonAction(String urn, String name, String description, Service service) {
        this.urn = urn;
        this.name = name;
        this.description = description;
        this.service = service;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public Service getService() {
        return service;
    }
}
