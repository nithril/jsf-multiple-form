package com.victorbuckservices.vbackbone.common.controlbus.inbound;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.amqp.inbound.AmqpInboundChannelAdapter;

import java.util.Map;
import java.util.stream.Stream;

import static com.victorbuckservices.vbackbone.common.controlbus.inbound.ControlbusInboundConfiguration.BEAN_CONTROLBUS_INBOUND_ADAPTER;

/**
 *
 * AmqpInboundChannelAdapter could not be injected as a map {@code @Autowired Map<String,AmqpInboundChannelAdapter>} as the {@link AmqpInboundChannelAdapter} are constructed using spring integration dsl
 * and thus are not immediately available
 *
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class ControlBusActionService {

    @Autowired
    private ApplicationContext applicationContext;

    public void startConsumers() {
        filterMap().forEach(AmqpInboundChannelAdapter::start);
    }

    public void stopConsumers() {
        filterMap().forEach(AmqpInboundChannelAdapter::stop);
    }

    public boolean isRunning() {
        return filterMap().anyMatch(AmqpInboundChannelAdapter::isRunning);
    }

    private Stream<AmqpInboundChannelAdapter> filterMap() {
        return getBeansOfAmqpInboundChannelAdapterType().entrySet().stream()
                .filter(e -> !e.getKey().equals(BEAN_CONTROLBUS_INBOUND_ADAPTER))
                .map(Map.Entry::getValue);
    }

    private Map<String, AmqpInboundChannelAdapter> getBeansOfAmqpInboundChannelAdapterType(){
        return applicationContext.getBeansOfType(AmqpInboundChannelAdapter.class);
    }
}
