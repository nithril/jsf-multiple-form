package com.victorbuckservices.vbackbone.common.actionhandler.listener.processid;

import static com.victorbuckservices.vbackbone.common.integration.CommonHeaderContextPropertyName.PROCESS_ID;
import static org.apache.commons.lang3.StringUtils.isBlank;

import com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PreInvocationListener;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created on 08/24/2015
 *
 * @author labrot
 */
public class ProcessIdValidatorListener implements PreInvocationListener {

    private static final Logger LOG = LoggerFactory.getLogger(ProcessIdValidatorListener.class);

    @Override
    public void apply(GenericMessageEnvelope requestMessageEnvelope) throws InvocationException {

        if (requestMessageEnvelope.getHeader().getContextProperties() == null ||
                isBlank((String) requestMessageEnvelope.getHeader().getContextProperties().get(PROCESS_ID))) {
            LOG.error("Process Id is not set for action {}" , requestMessageEnvelope.getHeader().getAction());
            throw new InvocationException("Process ID is not set", null, true, false);
        }
    }
}
