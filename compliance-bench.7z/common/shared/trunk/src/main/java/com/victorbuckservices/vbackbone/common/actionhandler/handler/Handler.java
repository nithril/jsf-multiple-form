package com.victorbuckservices.vbackbone.common.actionhandler.handler;

import com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;

import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Created on 02/02/2015
 *
 * @author labrot
 */
public interface Handler<T, R> {

    boolean test(GenericMessageEnvelope<?> messageEnvelope);

    R invoke(GenericMessageEnvelope<T> messageEnvelope) throws InvocationException;

    static <T, R> Handler<T, R> of(Predicate<GenericMessageEnvelope<?>> accept, Function<GenericMessageEnvelope<T>, R> function) {
        return new Handler<T, R>() {
            @Override
            public boolean test(GenericMessageEnvelope<?> messageEnvelope) {
                return accept.test(messageEnvelope);
            }

            @Override
            public R invoke(GenericMessageEnvelope<T> messageEnvelope) throws InvocationException {
                return function.apply(messageEnvelope);
            }
        };
    }

}
