package com.victorbuckservices.vbackbone.common.actionhandler;

import com.rabbitmq.client.Channel;
import com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException;
import com.victorbuckservices.vbackbone.common.actionhandler.handler.Handler;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PostInvocationListener;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PreInvocationListener;
import com.victorbuckservices.vbackbone.common.actionhandler.response.ActionResponseEntity;
import com.victorbuckservices.vbackbone.common.actionhandler.response.ActionStatus;
import com.victorbuckservices.vbackbone.common.integration.CommonHeaderContextPropertyName;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.common.logging.LoggingHelper;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import com.victorbuckservices.vbackbone.common.utils.Lambdas;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import com.victorbuckservices.vbackbone.process.logger.ProcessLogger;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Predicate;

import static com.nurkiewicz.typeof.TypeOf.whenTypeOf;
import static java.util.Collections.synchronizedList;
import static java.util.concurrent.TimeUnit.MINUTES;

/**
 * Created by nlabrot on 30/11/14.
 */
@Service
public class ActionDispatcher {

    private static final Logger LOG = LoggerFactory.getLogger(ActionDispatcher.class);

    @Autowired
    private CommonConversionService commonConversionService;

    @Autowired
    private ActionHandlerDirectories actionHandlerDirectories;

    @Autowired
    private LoggingHelper loggingHelper;

    @Autowired
    private UuidGeneratorService uuidGeneratorService;

    private LongAdder ongoingProcess = new LongAdder();

    private final List<PreInvocationListener<? super Object>> preInvocationListeners = synchronizedList(new ArrayList<>());

    private final List<PostInvocationListener<? super Object>> postInvocationListeners = synchronizedList(new ArrayList<>());


    private long threshold = MINUTES.toMillis(10);

    private boolean requeueMessageIfNoActionFound = false;


    public void dispatch(Message<?> message) {

        ongoingProcess.increment();

        try {


            Channel channel = message.getHeaders().get(AmqpHeaders.CHANNEL, Channel.class);
            Long deliveryTag = message.getHeaders().get(AmqpHeaders.DELIVERY_TAG, Long.class);

            boolean manualAck = channel != null;
            RabbitAction rabbitAction = RabbitAction.NACK_AND_REQUEUE;
            String contextUuid = uuidGeneratorService.generateUuid();

            AtomicReference<GenericMessageEnvelope<?>> genericMessageEnvelopeReference = new AtomicReference<>();


            try {
                genericMessageEnvelopeReference.set(commonConversionService.parseMessageEnvelopeHeaderAndBody(message.getHeaders(), (byte[]) message.getPayload()));

                //Construct callee ContextProperties
                constructCalleeContextProperties(contextUuid, genericMessageEnvelopeReference.get());

                //Fill the MDC
                loggingHelper.fillMdcWithContextProperties(genericMessageEnvelopeReference.get().getHeader().getContextProperties());
                //Start Event
                ProcessLogger.startAction(genericMessageEnvelopeReference.get().getHeader().getAction());


                LOG.debug("Dispatch request [{}]", loggingHelper.lazyToString(genericMessageEnvelopeReference.get().getHeader(), genericMessageEnvelopeReference.get().getBody(), null));

                //Search for handler
                Optional<Handler> handler = actionHandlerDirectories.findFirst(genericMessageEnvelopeReference.get());

                if (handler.isPresent()) {
                    //Invoke the handler
                    CompletableFuture<?> futureResult = invokeHandler(genericMessageEnvelopeReference.get(), handler.get());

                    if (futureResult.isDone() || !manualAck) {
                        //If the result is already available it can be returned synchronously
                        //Must retrieve the result if the ack mode is not MANUAL
                        Pair<Object, Throwable> pair = Lambdas.get(futureResult);
                        rabbitAction = handleResult(genericMessageEnvelopeReference.get(), pair.getLeft(), pair.getRight());
                    } else {
                        //The result is not yet available
                        //Add a result processing completion stage
                        futureResult.whenCompleteAsync((result, e) -> {
                            RabbitAction asyncRabbitAction = handleResult(genericMessageEnvelopeReference.get(), result, e);
                            handleReturn(channel, deliveryTag, manualAck, asyncRabbitAction);
                        });
                        rabbitAction = RabbitAction.FUTURE;
                    }


                } else {
                    LOG.error("No action mapping found for the message [{}], message requeued [{}]", loggingHelper.lazyToString(genericMessageEnvelopeReference.get().getHeader(), genericMessageEnvelopeReference.get().getBody(), null), requeueMessageIfNoActionFound);
                    if (requeueMessageIfNoActionFound) {
                        rabbitAction = RabbitAction.NACK_AND_REQUEUE;
                    } else {
                        rabbitAction = RabbitAction.NACK_AND_DEQUEUE;
                    }

                    ProcessLogger.endActionWithError(genericMessageEnvelopeReference.get().getHeader().getAction());
                }
            } catch (Exception e) {
                LOG.error("An error occures when processing the message [{}], message requeued", loggingHelper.lazyToString(message.getHeaders(), e), e);
                rabbitAction = RabbitAction.NACK_AND_REQUEUE;
            }

            // Handle the return
            handleReturn(channel, deliveryTag, manualAck, rabbitAction);

        } finally {
            ongoingProcess.decrement();
            loggingHelper.clearMdcOfContextProperties();
        }

    }

    private void constructCalleeContextProperties(String contextUuid, GenericMessageEnvelope<?> genericMessageEnvelope) {
        //Clone
        Map<String, Object> calleeContextProperties = new HashMap<>(genericMessageEnvelope.getHeader().getContextProperties());
        //Get the caller urn
        String callerContextUrn = (String) calleeContextProperties.get(CommonHeaderContextPropertyName.PROCESS_URN);
        //Construct the new context urn
        String calleeContextUrn = callerContextUrn + ":" + contextUuid;
        //Set the new context urn
        calleeContextProperties.put(CommonHeaderContextPropertyName.PROCESS_URN, calleeContextUrn);
        //Save the caller urn
        calleeContextProperties.put(CommonHeaderContextPropertyName.CALLER_PROCESS_URN, callerContextUrn);
        //Set the new context properties map
        genericMessageEnvelope.getHeader().setContextProperties(calleeContextProperties);
    }

    private void handleReturn(Channel channel, Long deliveryTag, boolean manualAck, RabbitAction rabbitAction) {
        switch (rabbitAction) {
            case FUTURE:
                break;
            case ACK:
                if (manualAck) {
                    ack(channel, deliveryTag);
                }
                break;
            case NACK_AND_DEQUEUE:
                if (manualAck) {
                    nackAndDequeue(channel, deliveryTag);
                } else {
                    throw new AmqpRejectAndDontRequeueException("Nack and dequeue");
                }
                break;
            case NACK_AND_REQUEUE:
            default:
                if (manualAck) {
                    //TODO: nack and requeue could only be managed when we will be able to manage the number of retry
                    //nackAndRequeue(channel, deliveryTag);
                    nackAndDequeue(channel, deliveryTag);
                } else {
                    throw new AmqpException("Nack and requeue");
                }
                break;
        }
    }

    private RabbitAction handleResult(GenericMessageEnvelope<?> messageEnvelope, Object result, Throwable exception) {
        RabbitAction rabbitAction;
        if (exception == null) {
            rabbitAction = RabbitAction.ACK;

            Object body = result;
            ActionStatus actionStatus = ActionStatus.OK;

            //Result may be an instance of ActionResponseEntity
            if (result instanceof ActionResponseEntity) {
                body = ((ActionResponseEntity) result).getBody();
                actionStatus = ((ActionResponseEntity) result).getStatus();
            }

            doPostInvocations(messageEnvelope, body);

            //Test if the action is successful
            if (ActionStatus.OK == actionStatus) {
                ProcessLogger.endAction(messageEnvelope.getHeader().getAction());
            } else {
                ProcessLogger.endActionWithError(messageEnvelope.getHeader().getAction());
            }


        } else {
            rabbitAction = whenTypeOf(exception).is(InvocationException.class).thenReturn(e -> {
                if (e.isNack()) {
                    if (e.isRequeue()) {
                        return RabbitAction.NACK_AND_REQUEUE;
                    } else {
                        return RabbitAction.NACK_AND_DEQUEUE;
                    }
                } else {
                    return RabbitAction.ACK;
                }
            }).orElse(RabbitAction.NACK_AND_DEQUEUE);
            LOG.error("An error occures when processing the message [{}], message requeued [{}]", loggingHelper.lazyToString(messageEnvelope.getHeader(), messageEnvelope.getBody(), null), rabbitAction);

            ProcessLogger.endActionWithError(messageEnvelope.getHeader().getAction());
        }

        return rabbitAction;
    }

    private CompletableFuture invokeHandler(GenericMessageEnvelope<?> messageEnvelope, Handler handler) {
        CompletableFuture completableFuture = null;
        try {
            doPreInvocations(messageEnvelope);
            Object result = handler.invoke(messageEnvelope);
            if (result instanceof CompletableFuture) {
                // We finally got a future and an asynchronous service!
                completableFuture = (CompletableFuture) result;
            } else {
                // No future, Bootstrap it
                completableFuture = CompletableFuture.completedFuture(result);
            }
        } catch (Exception e) {
            // Create a future and completes it exceptionally
            completableFuture = new CompletableFuture();
            completableFuture.completeExceptionally(e);
        }
        return completableFuture;
    }

    private void doPreInvocations(GenericMessageEnvelope<?> messageEnvelope) throws Exception {
        for (PreInvocationListener preInvocationListener : preInvocationListeners) {
            boolean invoke = !(preInvocationListener instanceof Predicate) || ((Predicate) preInvocationListener).test(messageEnvelope);
            if (invoke) {
                preInvocationListener.apply(messageEnvelope);
            }
        }
    }

    private void doPostInvocations(GenericMessageEnvelope genericMessageEnvelope, Object result) {
        for (PostInvocationListener<? super Object> postInvocationListener : postInvocationListeners) {
            try {
                boolean invoke = !(postInvocationListener instanceof Predicate) || ((Predicate) postInvocationListener).test(result);
                if (invoke) {
                    postInvocationListener.apply(genericMessageEnvelope, result, null);
                }
            } catch (Exception e) {
                LOG.error("Error invoking post invocation listener [{}]", postInvocationListener, e);
            }
        }
    }

    public ActionDispatcher addPreInvocationListener(PreInvocationListener listener) {
        preInvocationListeners.add(listener);
        return this;
    }

    public ActionDispatcher addPostInvocationListener(PostInvocationListener listener) {
        postInvocationListeners.add(listener);
        return this;
    }


    private void ack(Channel channel, Long deliveryTag) {
        try {
            channel.basicAck(deliveryTag, false);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void nackAndRequeue(Channel channel, Long deliveryTag) {
        nack(channel, deliveryTag, true);
    }

    private void nackAndDequeue(Channel channel, Long deliveryTag) {
        nack(channel, deliveryTag, false);
    }

    private void nack(Channel channel, Long deliveryTag, boolean requeue) {
        try {
            channel.basicNack(deliveryTag, false, requeue);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    public long getThreshold() {
        return threshold;
    }

    public void setThreshold(long threshold) {
        this.threshold = threshold;
    }

    public ActionHandlerDirectories getActionHandlerDirectories() {
        return actionHandlerDirectories;
    }

    public void setActionHandlerDirectories(ActionHandlerDirectories actionHandlerDirectories) {
        this.actionHandlerDirectories = actionHandlerDirectories;
    }

    public int getOngoingProcess() {
        return ongoingProcess.intValue();
    }


    private enum RabbitAction {
        ACK,
        NACK_AND_DEQUEUE,
        NACK_AND_REQUEUE,
        FUTURE
    }
}
