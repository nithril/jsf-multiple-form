package com.victorbuckservices.vbackbone.common.service;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationPid;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Identification service which provided common service information (name, version, discriminant...)
 *
 * Created on 06/08/2015
 *
 * @author labrot
 */
@Service
public class IdentificationService {

    private static final Logger LOG = LoggerFactory.getLogger(IdentificationService.class);

    @Value("${service.name}")
    private String name;

    @Value("${service.version}")
    private String version;

    @Value("${service.discriminant}")
    private String discriminant;

    @Value("${service.hostname:}")
    private String hostname;

    private ApplicationPid pid = new ApplicationPid();

    public String getName() {
        return name;
    }

    public String getVersion() {
        return version;
    }

    public String getDiscriminant() {
        return discriminant;
    }

    public String getHostname() {
        if (StringUtils.isBlank(hostname)) {
            try {
                hostname = InetAddress.getLocalHost().getCanonicalHostName();
            } catch (UnknownHostException e) {
                LOG.error(e.getMessage(), e);
            }
        }
        return hostname;
    }

    public String getProcessId() {
        return pid.toString();
    }

    public String getInstanceId() {
        return getHostname() + "@" + pid.toString();
    }


    public String getServiceInstanceId(){
        return "service." + name + "." + getInstanceId();
    }
}
