package com.victorbuckservices.vbackbone.common.utils.lambda.with;


import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

import java.util.function.Function;

/**
 * Created by nlabrot on 10/03/15.
 */
@FunctionalInterface
public interface CheckedFunction<T, R> extends Function<T, R> {

    R checkedApply(T t) throws Exception;

    @Override
    default R apply(T t) throws UncheckedExecutionException{
        try {
            return checkedApply(t);
        } catch (Exception e) {
            throw new UncheckedExecutionException(e);
        }
    }
}
