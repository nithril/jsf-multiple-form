package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.common.actionhandler.ActionDispatcher;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.replyto.ReplyToListener;
import com.victorbuckservices.vbackbone.common.integration.GenericGateway;
import com.victorbuckservices.vbackbone.common.utils.messagesqueue.MessagesQueueEndpoint;
import com.victorbuckservices.vbackbone.shared.definition.VbackboneHeaders;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.amqp.Amqp;
import org.springframework.integration.dsl.channel.MessageChannels;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

/**
 * Rabbit reply to pattern configuration
 * <p/>
 * <p>
 * Default configuration:
 * <ul>
 * <li>Channel {@link #CHANNEL_VBACKBONE_DEFAULT_REPLYTO}</li>
 * <li>Gateway {@link #BEAN_REPLYTO_OUTBOUND_ADAPTER} which publish to {@link #CHANNEL_VBACKBONE_DEFAULT_REPLYTO} channel</li>
 * </ul>
 * </p>
 * <p/>
 * <p>
 * "production" profile:
 * <ul>
 * <li>Flow {@link #amqpReplyToOutboundFlow} which consumes message from {@link #CHANNEL_VBACKBONE_DEFAULT_REPLYTO} and publishes their to Rabbit</li>
 * </ul>
 * </p>
 * <p/>
 * <p>
 * "test-shared-client-integration" profile:
 * <ul>
 * <li>A {@link MessagesQueueEndpoint} bean of name {@link #BEAN_REPLYTO_OUTBOUND_MESSAGES_ENDPOINT} which holds messages published to {@link #CHANNEL_VBACKBONE_DEFAULT_REPLYTO} channel</li>
 * <li>Flow {@link #replyToOutboundMessagesEndpointFlow}</li>
 * </ul>
 * </p>
 * <p/>
 * This configuration requires beans of type {@link RabbitTemplate} and {@link AmqpHeaderMapper}
 * <p/>
 * Created on 02/02/2015
 *
 * @author labrot
 */
@Configuration
public class RabbitReplyToConfiguration {

    public static final String CHANNEL_VBACKBONE_DEFAULT_REPLYTO = "vbackbone.replyTo.channel";

    public static final String BEAN_REPLYTO_OUTBOUND_ADAPTER = "replyToOutboundAdapter";

    public static final String BEAN_REPLYTO_OUTBOUND_MESSAGES_ENDPOINT = "replyToOutboundMessagesEndpoint";


    @Bean
    public ReplyToListener replyToListener(ActionDispatcher actionDispatcher){
        ReplyToListener replyToListener = new ReplyToListener();
        actionDispatcher.addPostInvocationListener(replyToListener);
        return replyToListener;
    }


    /**
     * @return Configured {@link org.springframework.messaging.MessageChannel} of name {@link #CHANNEL_VBACKBONE_DEFAULT_REPLYTO}
     */
    @Bean(name = CHANNEL_VBACKBONE_DEFAULT_REPLYTO)
    public MessageChannel replyToChannel() {
        return MessageChannels.direct(CHANNEL_VBACKBONE_DEFAULT_REPLYTO).get();
    }


    /**
     * @return Configured {@link com.victorbuckservices.vbackbone.shared.integration.Gateway} on the channel {@link #replyToChannel}
     */
    @Bean(name = BEAN_REPLYTO_OUTBOUND_ADAPTER)
    public Gateway replyToOutboundAdapter() {
        return new GenericGateway(replyToChannel());
    }


    /**
     * @return Configured AMQP outbound adapter linked to the {@link #replyToChannel()}.
     */
    @Bean
    @Profile("production")
    public IntegrationFlow amqpReplyToOutboundFlow(RabbitTemplate amqpTemplate, AmqpHeaderMapper mapAllHeadersHeaderMapper) {
        return IntegrationFlows
                .from(replyToChannel())
                .handle(Amqp.outboundAdapter(amqpTemplate)
                        .routingKeyExpression("headers." + VbackboneHeaders.HEADER_ROUTING_KEY)
                        .headerMapper(mapAllHeadersHeaderMapper)).get();
    }


    /**
     * Queue messages send to {@link #replyToChannel} through {@link #replyToOutboundAdapter}
     *
     * @return Configured outbound adapter linked to the {@link #replyToChannel()}.
     */
    @Bean(name = BEAN_REPLYTO_OUTBOUND_MESSAGES_ENDPOINT)
    @Profile("test-shared-client-integration")
    public MessagesQueueEndpoint replyToOutboundMessagesEndpoint() {
        return new MessagesQueueEndpoint();
    }

    /**
     * Bind the reply to channel to the {@link #replyToOutboundMessagesEndpoint}
     *
     * @return Configured AMQP outbound adapter linked to the {@link #replyToChannel()}.
     */
    @Bean
    @Profile("test-shared-client-integration")
    public IntegrationFlow replyToOutboundMessagesEndpointFlow() {
        MessagesQueueEndpoint messageQueueInbound = replyToOutboundMessagesEndpoint();
        return IntegrationFlows.from(replyToChannel()
        ).handle(m -> messageQueueInbound.handleMessage((Message<byte[]>) m)).get();
    }
}

