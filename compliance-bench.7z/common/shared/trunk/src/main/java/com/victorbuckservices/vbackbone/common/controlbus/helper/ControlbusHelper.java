package com.victorbuckservices.vbackbone.common.controlbus.helper;

/**
 * Created on 26/08/2015
 *
 * @author labrot
 */
public class ControlbusHelper {

    private ControlbusHelper() {
    }

    public static String constructControlbusQueueName(String name, String instanceId) {
        return "vbackbone.controlbus.queue." + name + "." + instanceId;
    }

    public static String constructControlbusRoutingKey(String name, String instanceId) {
        return constructControlbusQueueName(name, instanceId);
    }

}
