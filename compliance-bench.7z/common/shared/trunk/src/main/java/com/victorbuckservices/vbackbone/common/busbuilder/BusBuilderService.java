package com.victorbuckservices.vbackbone.common.busbuilder;

import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition.BusBuilderSchemaDefinition;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import org.apache.commons.lang3.tuple.Pair;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created on 08/12/2015
 *
 * @author labrot
 */
public class BusBuilderService {

    private Map<String, BusBuilderSchemaDefinition> busConfiguration;

    public BusBuilderService(Map<String, BusBuilderSchemaDefinition> busConfiguration) {
        this.busConfiguration = new ConcurrentHashMap<>(busConfiguration);
    }

    public List<Queue> getQueues() {
        return busConfiguration.entrySet().stream()
                .flatMap(e -> Stream.concat(
                        e.getValue().getPrioritizedQueues().values().stream()
                                .flatMap(p -> p.resolveQueues().stream())
                                .map(Pair::getLeft),
                        e.getValue().getQueues().values().stream()))
                .collect(Collectors.toList());
    }

    public BusBuilderSchemaDefinition findByService(String service){
        return busConfiguration.get(service);
    }

    public Map<String, BusBuilderSchemaDefinition> getBusConfiguration() {
        return busConfiguration;
    }
}
