package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.victorbuckservices.vbackbone.common.definition.UnknownVbbMimeType;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

import java.io.IOException;

/**
 * Deserializer for {@link VbbMimeType}s.
 *
 * @author Marc Plouhinec
 * Created on 11/12/2014.
 */
public class VbbMimeTypeDeserializer extends VbackboneDeserializerBase<VbbMimeType>
{
    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    /**
     * Create a new {@link VbbMimeTypeDeserializer}.
     */
    public VbbMimeTypeDeserializer(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService)
    {
        super(VbbMimeType.class);
        this.serviceDefinitionDirectoryService = serviceDefinitionDirectoryService;
    }

    @Override
    public VbbMimeType deserialize(JsonParser parser, DeserializationContext context) throws IOException
    {
        if (parser.getCurrentToken() != JsonToken.VALUE_STRING) {
            throw context.mappingException("Expected type string.");
        }
        String name = parser.getText().trim();
        VbbMimeType vbbMimeType = serviceDefinitionDirectoryService.findVbbMimeTypeByName(name);
        return vbbMimeType == null ? new UnknownVbbMimeType(name) : vbbMimeType;
    }
}
