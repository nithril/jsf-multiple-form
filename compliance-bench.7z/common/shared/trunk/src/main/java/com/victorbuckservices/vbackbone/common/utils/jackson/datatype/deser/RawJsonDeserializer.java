package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.TokenBuffer;

import java.io.IOException;

/**
 * @author Marc Plouhinec
 * Created on 11/18/2014.
 */
public class RawJsonDeserializer extends JsonDeserializer<byte[]>
{
    @Override
    public byte[] deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        TokenBuffer tokenBuffer = jp.readValueAs(TokenBuffer.class);
        ObjectMapper objectMapper = (ObjectMapper) jp.getCodec();
        return objectMapper.writeValueAsBytes(tokenBuffer);
    }
}
