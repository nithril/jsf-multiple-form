package com.victorbuckservices.vbackbone.common.integration;

/**
 * Name of the context properties that can be set in the header.
 *
 * @see com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader#setContextProperties(java.util.Map)
 * @see com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader#getContextProperties()
 *
 * @author Marc Plouhinec
 * Created on 11/19/2014.
 */
public interface CommonHeaderContextPropertyName {
    String PROCESS_URN = "processUrn";
    String CALLER_PROCESS_URN = "callerContextUrn";
    String ANCESTOR_PROCESS_URNS = "ancestorProcessUrns";
    String COMPANY_CODE = "companyCode";
    String TOP_COMPANY_CODE = "topCompanyCode";
    String DATA_SET_ID = "dataSetId";
    String FILE_SET_ID = "fileSetId";
    String PROCESS_ID = "processId";
    String EXTERNAL_PROCESS_REFERENCE = "externalProcessReference";
    String DOCUMENT_TYPE = "documentType";

    String[] PROPERTIES_IN_MDC = {PROCESS_ID, PROCESS_URN, TOP_COMPANY_CODE, COMPANY_CODE, DOCUMENT_TYPE, EXTERNAL_PROCESS_REFERENCE};
}
