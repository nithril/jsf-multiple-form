package com.victorbuckservices.vbackbone.common.busbuilder;

import com.victorbuckservices.vbackbone.rabbit.management.client.domain.binding.Binding;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.exchange.Exchange;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created on 08/12/2015
 *
 * @author labrot
 */
public class BusBuilderServiceConfiguration {

    private Map<String, Exchange> exchanges = Collections.emptyMap();
    private Map<String, Queue> queues = Collections.emptyMap();
    private List<Binding> bindings = Collections.emptyList();

    public Map<String, Exchange> getExchanges() {
        return exchanges;
    }

    public void setExchanges(Map<String, Exchange> exchanges) {
        this.exchanges = exchanges;
    }

    public Map<String, Queue> getQueues() {
        return queues;
    }

    public void setQueues(Map<String, Queue> queues) {
        this.queues = queues;
    }

    public List<Binding> getBindings() {
        return bindings;
    }

    public void setBindings(List<Binding> bindings) {
        this.bindings = bindings;
    }
}
