package com.victorbuckservices.vbackbone.common.exception;

/**
 * Created on 06/12/2015
 *
 * @author labrot
 */
public class BadConfigurationException extends Exception {

    public BadConfigurationException() {
    }

    public BadConfigurationException(String message) {
        super(message);
    }

    public BadConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    public BadConfigurationException(Throwable cause) {
        super(cause);
    }

    public BadConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
