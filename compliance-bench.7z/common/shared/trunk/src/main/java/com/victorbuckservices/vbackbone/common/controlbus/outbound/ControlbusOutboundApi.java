package com.victorbuckservices.vbackbone.common.controlbus.outbound;

import com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusCommonAction;
import com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusVbbMimeType;
import com.victorbuckservices.vbackbone.common.controlbus.definition.dto.StartConsumersRequest;
import com.victorbuckservices.vbackbone.common.controlbus.definition.dto.StopConsumersRequest;
import com.victorbuckservices.vbackbone.common.controlbus.helper.ControlbusHelper;
import com.victorbuckservices.vbackbone.common.integration.helper.MessageEnvelopeHeaderHelper;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.util.Map;

import static com.victorbuckservices.vbackbone.common.controlbus.outbound.ControlbusOutboundConfiguration.BEAN_CONTROLBUS_OUTBOUND_ADAPTER;

/**
 * Created on 08/20/2015
 *
 * @author labrot
 */
public class ControlbusOutboundApi {

    @Autowired
    @Qualifier(value = BEAN_CONTROLBUS_OUTBOUND_ADAPTER)
    private Gateway controlbusOutboundAdapter;

    @Autowired
    private MessageEnvelopeHeaderHelper messageEnvelopeHeaderHelper;

    public void requestStopConsumers(@Nonnull Map<String, Object> contexts, @Nonnull String serviceName, @Nonnull String serviceInstanceId) throws IOException {
        Validate.notNull(contexts);
        Validate.notBlank(serviceName);
        Validate.notBlank(serviceInstanceId);

        String routingKey = ControlbusHelper.constructControlbusRoutingKey(serviceName, serviceInstanceId);

        MessageEnvelopeHeader messageEnvelopeHeader = messageEnvelopeHeaderHelper.newMessageEnvelopeHeaderBuilder()
                .action(ControlBusCommonAction.STOP_CONSUMERS_REQUEST)
                .contentType(ControlBusVbbMimeType.STOP_CONSUMERS_REQUEST)
                .contextProperties(contexts).build();

        StopConsumersRequest stopConsumersRequest = new StopConsumersRequest();
        stopConsumersRequest.setInstanceId(serviceInstanceId);

        controlbusOutboundAdapter.sendMessage(routingKey, messageEnvelopeHeader, stopConsumersRequest);
    }

    public void requestStartConsumers(@Nonnull Map<String, Object> contexts, @Nonnull String serviceName, @Nonnull String serviceInstanceId) throws IOException {
        Validate.notNull(contexts);
        Validate.notBlank(serviceName);
        Validate.notBlank(serviceInstanceId);

        String routingKey = ControlbusHelper.constructControlbusRoutingKey(serviceName, serviceInstanceId);

        MessageEnvelopeHeader messageEnvelopeHeader = messageEnvelopeHeaderHelper.newMessageEnvelopeHeaderBuilder()
                .action(ControlBusCommonAction.START_CONSUMERS_REQUEST)
                .contentType(ControlBusVbbMimeType.START_CONSUMERS_REQUEST)
                .contextProperties(contexts).build();

        StartConsumersRequest startConsumersRequest = new StartConsumersRequest();
        startConsumersRequest.setInstanceId(serviceInstanceId);

        controlbusOutboundAdapter.sendMessage(routingKey, messageEnvelopeHeader, startConsumersRequest);
    }

}
