package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition;

import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.PrioritizedQueue;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.binding.Binding;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.exchange.Exchange;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.permission.Permission;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.policy.Policy;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.user.User;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.vhost.Vhost;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by nithril on 18/11/14.
 */
public class BusBuilderSchemaDefinition {

    private String schemaName;

    private List<Vhost> vhosts = Collections.emptyList();
    private List<User> users = Collections.emptyList();

    private List<Permission> permissions = Collections.emptyList();

    private List<Policy> policies = Collections.emptyList();

    private Map<String, Exchange> exchanges = Collections.emptyMap();
    private Map<String, Queue> queues = Collections.emptyMap();
    private Map<String, PrioritizedQueue> prioritizedQueues = Collections.emptyMap();
    private List<Binding> bindings = Collections.emptyList();


    public Map<String, Exchange> getExchanges() {
        return exchanges;
    }

    public void setExchanges(Map<String, Exchange> exchanges) {
        this.exchanges = exchanges;
    }

    public Map<String, Queue> getQueues() {
        return queues;
    }

    public void setQueues(Map<String, Queue> queues) {
        this.queues = queues;
    }

    public List<Binding> getBindings() {
        return bindings;
    }

    public void setBindings(List<Binding> bindings) {
        this.bindings = bindings;
    }

    public List<Vhost> getVhosts() {
        return vhosts;
    }

    public void setVhosts(List<Vhost> vhosts) {
        this.vhosts = vhosts;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<Permission> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<Permission> permissions) {
        this.permissions = permissions;
    }

    public List<Policy> getPolicies() {
        return policies;
    }

    public void setPolicies(List<Policy> policies) {
        this.policies = policies;
    }

    public Map<String, PrioritizedQueue> getPrioritizedQueues() {
        return prioritizedQueues;
    }

    public void setPrioritizedQueues(Map<String, PrioritizedQueue> prioritizedQueues) {
        this.prioritizedQueues = prioritizedQueues;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }
}
