package com.victorbuckservices.vbackbone.common.uuid.namebased;

import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.NameBasedGenerator;
import com.victorbuckservices.vbackbone.common.service.IdentificationService;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import com.victorbuckservices.vbackbone.common.uuid.exception.UuidBadPidException;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.management.ManagementFactory;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.PostConstruct;

/**
 * Type 5 {@link UuidGeneratorService}.
 * <p/>
 * Name is construct using the following pattern:
 * <p/>
 * {@code ttttttccccpph*}
 * <p/>
 * t: timestamp in ms since epoch (6 bytes)
 * c: counter (4 bytes)
 * p: process id  (2 bytes)
 * h: hostname (* bytes)
 * <p/>
 * counter is initialized using a {@link SecureRandom#nextInt}
 *
 * @author nlabrot
 */
public class NameBasedUuidGeneratorService implements UuidGeneratorService {

    private static final int MAX_PID = 65536;

    public static final int TIMESTAMP_SIZE = 6;
    public static final int COUNTER_SIZE = 4;
    public static final int PID_SIZE = 2;
    public static final int PID = processId();

    private static final AtomicInteger COUNTER = new AtomicInteger(new SecureRandom().nextInt());

    private final NameBasedGenerator nameBasedGenerator = Generators.nameBasedGenerator(NameBasedGenerator.NAMESPACE_OID);

    private byte[] referenceName;

    @Autowired
    private IdentificationService identificationService;

    /**
     * NLA: Retrieve from https://github.com/groupon/locality-uuid.java
     * <p/>
     * Get the process id of this JVM. I haven't tested this extensively so its possible that this performs differently
     * on esoteric JVMs. I copied this from:
     * http://stackoverflow.com/questions/35842/how-can-a-java-program-get-its-own-process-id
     *
     * @return Id of the current JVM process.
     */
    private static int processId() {
        // Note: may fail in some JVM implementations
        // something like '<pid>@<hostname>', at least in SUN / Oracle JVMs
        final String jvmName = ManagementFactory.getRuntimeMXBean().getName();
        final int index = jvmName.indexOf('@');

        if (index < 1)
            throw new UuidBadPidException(index);

        try {
            return Integer.parseInt(jvmName.substring(0, index)) % MAX_PID;
        } catch (NumberFormatException e) {
            throw new UuidBadPidException(index, e);
        }
    }

    @PostConstruct
    public void init() {
        byte[] hostname = identificationService.getHostname().getBytes();

        referenceName = new byte[TIMESTAMP_SIZE + COUNTER_SIZE + PID_SIZE + hostname.length];

        referenceName[TIMESTAMP_SIZE + COUNTER_SIZE] = (byte) (PID >> 8);
        referenceName[TIMESTAMP_SIZE + COUNTER_SIZE + 1] = (byte) (PID);

        System.arraycopy(hostname, 0, referenceName, TIMESTAMP_SIZE + COUNTER_SIZE + PID_SIZE, hostname.length);
    }

    @Override
    public String generateUuid() {
        long timestamp = System.currentTimeMillis();

        byte[] name = Arrays.copyOf(referenceName, referenceName.length);

        // copy timestamp into content
        name[0] = (byte) (timestamp >> 40);
        name[1] = (byte) (timestamp >> 32);
        name[2] = (byte) (timestamp >> 24);
        name[3] = (byte) (timestamp >> 16);
        name[4] = (byte) (timestamp >> 8);
        name[5] = (byte) (timestamp);

        int count = COUNTER.addAndGet(1);
        // get the count in order and place into content
        name[6] = (byte) (count >> 24);
        name[7] = (byte) (count >> 16);
        name[8] = (byte) (count >> 8);
        name[9] = (byte) (count);

        return nameBasedGenerator.generate(name).toString();
    }
}
