package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue;

import org.apache.commons.lang3.Validate;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-09-10.
 */
public enum QueuePriority {

    LOW("low", 0),
    MEDIUM("medium", 1),
    HIGH("high", 2),
    BOOST("boost", 32);

    private final String name;
    private final int value;
    private final long weight;

    QueuePriority(String name, int value) {
        Validate.isTrue(value <= 32);

        this.name = name;
        this.value = value;
        this.weight = 1L << value;    // equiv to this.weight = Math.pow(2, value);
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }

    public static QueuePriority findByValue(int value) {
        for (QueuePriority priority : QueuePriority.values()) {
            if (priority.getValue() == value) return priority;
        }
        return null;
    }


    public long getWeight() {
        return weight;
    }
}
