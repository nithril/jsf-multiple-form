package com.victorbuckservices.vbackbone.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by nlabrot on 04/03/15.
 */
public final class UrnHelper {

    public static final String VERSION_REGEXP = "(\\d+\\.\\d+(\\.\\d+)?)$";
    public static final Pattern VERSION_PATTERN = Pattern.compile(VERSION_REGEXP);

    private UrnHelper() {
    }

    public static String extractVersion(String urn){
        Matcher matcher = VERSION_PATTERN.matcher(urn);
        if (matcher.find()){
            return matcher.group();
        }else{
            throw new IllegalStateException("Urn invalid, the version is not found [" + urn + ']');
        }
    }

}
