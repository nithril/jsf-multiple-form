package com.victorbuckservices.vbackbone.common.uuid.locality;

import java.util.Arrays;

/**
 * Created on 03/24/2015
 *
 * @author labrot
 */
public class LocalityUuid {

    private final byte[] uuid;

    public LocalityUuid(byte[] uuid) {
        this.uuid = Arrays.copyOf(uuid, uuid.length);
    }

    public long getTimestamp() {
        return (toLong(uuid[0]) << 40)
                | (toLong(uuid[1]) << 32)
                | (toLong(uuid[2]) << 24)
                | (toLong(uuid[3]) << 16)
                | (toLong(uuid[4]) << 8)
                | (toLong(uuid[5]));
    }

    public long getCounter() {
        return (toLong(uuid[12]) << 24)
                | (toLong(uuid[13]) << 16)
                | (toLong(uuid[14]) << 8)
                | (toLong(uuid[15]));
    }

    public byte getVersion() {
        return (byte) (toLong(uuid[6]) >> 4);
    }

    public long getDiscriminant() {
        return ((toLong(uuid[6]) & 15) << 16) | (toLong(uuid[7]) << 8) | (toLong(uuid[8]));
    }

    public long getEnvDiscriminant() {
        return (((toLong(uuid[6]) & 15) << 16) | (toLong(uuid[7]) << 8) | (toLong(uuid[8]))) >> 14;
    }

    public long getVmDiscriminant() {
        return (((toLong(uuid[6]) & 15) << 16) | (toLong(uuid[7]) << 8) | (toLong(uuid[8]))) & ((1 << 14) - 1);
    }

    public long getPid() {
        return (toLong(uuid[10]) << 8) | (toLong(uuid[11]));
    }

    public long getServiceDiscriminant() {
        return toLong(uuid[9]);
    }

    private long toLong(byte b) {
        return (long) b & 0xFF;
    }
}
