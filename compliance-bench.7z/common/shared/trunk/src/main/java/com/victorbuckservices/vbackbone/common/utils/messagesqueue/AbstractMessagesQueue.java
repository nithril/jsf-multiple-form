package com.victorbuckservices.vbackbone.common.utils.messagesqueue;

import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Abstract Messages Queue which store message
 *
 * Created by nlabrot on 12/01/2014.
 */
public class AbstractMessagesQueue {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractMessagesQueue.class);
    private static final long DEFAULT_TIMEOUT_MILLIS = 5000;

    protected final BlockingQueue<GenericMessageEnvelope<?>> messages = new LinkedBlockingQueue<>();
    private final long timeoutMillis;

    /**
     * Create a new {@link AbstractMessagesQueue}.
     */
    public AbstractMessagesQueue(long timeoutMillis) {
        this.timeoutMillis = timeoutMillis;
    }

    /**
     * Create a new {@link AbstractMessagesQueue}.
     */
    public AbstractMessagesQueue() {
        this(DEFAULT_TIMEOUT_MILLIS);
    }


    /**
     * Wait until a message has been received.
     *
     * @param expectedClass Expected body class (a normal DTO or a {@link com.victorbuckservices.vbackbone.shared.definition.dto.Problem}).
     * @return GenericMessageEnvelope with {@link com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope#getBody()} type or subclass of {@code expectedClass}
     * @throws TimeoutException
     */
    public <T> GenericMessageEnvelope<T> receiveNextHeaderAndBody(Class<T> expectedClass) throws TimeoutException {
        return receiveNextHeaderAndBody(expectedClass , timeoutMillis);
    }


    public <T> GenericMessageEnvelope<T> receiveNextHeaderAndBody(Class<T> expectedClass, long timeoutMillis) throws TimeoutException {

        GenericMessageEnvelope<T> messageEnvelope = receiveNextHeaderAndBody(timeoutMillis);

        if (expectedClass.isAssignableFrom(messageEnvelope.getBody().getClass())) {
            return messageEnvelope;
        } else {
            throw new IllegalArgumentException("[" + expectedClass.getCanonicalName() + "] not assignable from [" + messageEnvelope.getBody().getClass().getCanonicalName() + "]");
        }
    }

    /**
     * Wait until a message has been received.
     *
     * @return a GenericMessageEnvelope
     * @throws TimeoutException
     */
    public <T> GenericMessageEnvelope<T> receiveNextHeaderAndBody() throws TimeoutException {
        return receiveNextHeaderAndBody(timeoutMillis);
    }

    public <T> GenericMessageEnvelope<T> receiveNextHeaderAndBody(long timeoutMillis) throws TimeoutException {

        GenericMessageEnvelope<T> messageEnvelope = null;
        try {
            messageEnvelope = (GenericMessageEnvelope<T>) messages.poll(timeoutMillis, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            LOG.error("Message reception interrupted.", e);
        }

        if (messageEnvelope == null) {
            throw new TimeoutException();
        }
        return messageEnvelope;
    }

    /**
     * Shortcut for {@code receiveNextHeaderAndBody(expectedClass).getBody()}
     * See {@link #receiveNextHeaderAndBody(Class)}
     *
     * @throws TimeoutException
     */
    public <T> T receiveNextBody(Class<T> expectedClass) throws TimeoutException {
        return receiveNextBody(expectedClass , timeoutMillis);
    }

    public <T> T receiveNextBody(Class<T> expectedClass, long timeoutMillis) throws TimeoutException {
        return receiveNextHeaderAndBody(expectedClass,timeoutMillis).getBody();
    }

    /**
     * Shortcut for {@code receiveNextHeaderAndBody().getBody()}
     * See {@link #receiveNextHeaderAndBody()}
     *
     * @throws TimeoutException
     */
    public <T> T receiveNextBody() throws TimeoutException {
        return receiveNextBody(timeoutMillis);
    }

    public <T> T receiveNextBody(long timeoutMillis) throws TimeoutException {
        return this.<T>receiveNextHeaderAndBody().getBody();
    }

    /**
     * Clear the queue
     */
    public void clear() {
        messages.clear();
    }

    /**
     * Queue a message
     *
     * @param message
     */
    protected void queueMessage(GenericMessageEnvelope<?> message) {
        messages.add(message);
    }
}
