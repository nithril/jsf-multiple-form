package com.victorbuckservices.vbackbone.shared.definition;

/**
 * Define the status sent in the responses.
 *
 * @author Marc Plouhinec
 *         Created on 14/10/2014
 */
public interface Status {

    /**
     * E.g. "urn:vbs:status:vbackbone:filegateway:fileset-classified"
     * @return Unique identifier for a specific status version.
     */
    String getUrn();

    /**
     * E.g. "Timeout"
     * @return Status name
     */
    String getName();
}
