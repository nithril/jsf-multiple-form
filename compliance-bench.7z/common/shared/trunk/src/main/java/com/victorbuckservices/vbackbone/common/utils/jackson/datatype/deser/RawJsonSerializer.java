package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.SerializableString;
import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * Json Serializer
 *
 * @author labrot
 */
public class RawJsonSerializer extends JsonSerializer<byte[]> {

    @Override
    public void serialize(byte[] value, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
        /**
         * {@link SerializableString#getValue} will be called by {@link JsonGenerator#writeRawValue},  {@link SerializableString#asUnquotedUTF8} by {@link UTF8JsonGenerator#writeRawValue}
         */
        jgen.writeRawValue(new SerializableString() {
            @Override
            public String getValue() {
                return new String(value);
            }

            @Override
            public int charLength() {
                throw new UnsupportedOperationException();
            }

            @Override
            public char[] asQuotedChars() {
                throw new UnsupportedOperationException();
            }

            @Override
            public byte[] asUnquotedUTF8() {
                return value;
            }

            @Override
            public byte[] asQuotedUTF8() {
                throw new UnsupportedOperationException();
            }

            @Override
            public int appendQuotedUTF8(byte[] buffer, int offset) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int appendQuoted(char[] buffer, int offset) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int appendUnquotedUTF8(byte[] buffer, int offset) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int appendUnquoted(char[] buffer, int offset) {
                throw new UnsupportedOperationException();
            }

            @Override
            public int writeQuotedUTF8(OutputStream out) throws IOException {
                throw new UnsupportedOperationException();
            }

            @Override
            public int writeUnquotedUTF8(OutputStream out) throws IOException {
                throw new UnsupportedOperationException();
            }

            @Override
            public int putQuotedUTF8(ByteBuffer buffer) throws IOException {
                throw new UnsupportedOperationException();
            }

            @Override
            public int putUnquotedUTF8(ByteBuffer out) throws IOException {
                throw new UnsupportedOperationException();
            }
        });

    }
}
