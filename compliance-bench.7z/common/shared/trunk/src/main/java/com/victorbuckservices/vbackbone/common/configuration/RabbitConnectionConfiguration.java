package com.victorbuckservices.vbackbone.common.configuration;

import com.rabbitmq.client.Channel;
import com.victorbuckservices.vbackbone.common.integration.rabbit.RabbitConnectionChecker;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.RabbitUtils;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.amqp.support.DefaultAmqpHeaderMapper;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static com.victorbuckservices.vbackbone.common.utils.Lambdas.quietFunction;

/**
 * Rabbit connection configuration
 * <p/>
 * <p>
 * Default configuration:
 * <ul>
 * <li>
 * Bean {@link #mapAllHeadersHeaderMapper} which define a map all headers ${link AmqpHeaderMapper}
 * </li>
 * </ul>
 * </p>
 * <p/>
 * <p>
 * <p/>
 * Production profile
 * <ul>
 * <li>Bean {@link #connectionFactory} of type ConnectionFactory</li>
 * <li>Bean {@link #amqpTemplate} of type RabbitTemplate</li>
 * </ul>
 * <p/>
 * </p>
 * <p/>
 * <p/>
 *
 * @author labrot
 */
@Configuration
public class RabbitConnectionConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(RabbitConnectionConfiguration.class);

    /**
     * @return Configured {@link AmqpHeaderMapper}.
     */
    @Bean
    public AmqpHeaderMapper mapAllHeadersHeaderMapper() {
        DefaultAmqpHeaderMapper amqpHeaderMapper = new DefaultAmqpHeaderMapper();
        amqpHeaderMapper.setReplyHeaderNames("*");
        amqpHeaderMapper.setRequestHeaderNames("*");
        return amqpHeaderMapper;
    }


    @Bean
    @ConfigurationProperties(prefix = "rabbit.connectionFactory")
    @Profile("production")
    public RabbitConnectionProperties rabbitConnectionProperties(){
        return new RabbitConnectionProperties();
    }

    /**
     * @return Configured {@link ConnectionFactory}.
     */
    @Bean
    @Profile("production")
    public ConnectionFactory connectionFactory(RabbitConnectionProperties rabbitConnectionProperties) {
        com.rabbitmq.client.ConnectionFactory rabbitConnectionFactory = new com.rabbitmq.client.ConnectionFactory();

        rabbitConnectionFactory.setHost(rabbitConnectionProperties.getHost());
        rabbitConnectionFactory.setPort(rabbitConnectionProperties.getPort());
        //rabbitConnectionFactory.setAutomaticRecoveryEnabled(true);
        //rabbitConnectionFactory.setTopologyRecoveryEnabled(true);
        rabbitConnectionFactory.setUsername(rabbitConnectionProperties.getUsername());
        rabbitConnectionFactory.setPassword(rabbitConnectionProperties.getPassword());
        rabbitConnectionFactory.setVirtualHost(rabbitConnectionProperties.getVirtualHost());

        rabbitConnectionFactory.setConnectionTimeout(rabbitConnectionProperties.getConnectionTimeout());
        rabbitConnectionFactory.setRequestedHeartbeat((int) TimeUnit.MILLISECONDS.toSeconds(rabbitConnectionProperties.getRequestedHeartbeat()));

        CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory(rabbitConnectionFactory);



        if (StringUtils.isNotBlank(rabbitConnectionProperties.getAddresses())) {
            cachingConnectionFactory.setAddresses(rabbitConnectionProperties.getAddresses());
        }

        cachingConnectionFactory.addChannelListener((channel, transactional) -> {
            channel.addShutdownListener(cause -> {
                if (!RabbitUtils.isNormalChannelClose(cause)){
                    Object channelNumber = quietFunction((Channel c) -> c.getChannelNumber(), null).apply(channel);
                    Object address = quietFunction((Channel c) -> c.getConnection().getAddress(), null).apply(channel);

                    LOG.error("Abnormal channel shutdown channelNumber:[{}] address:[{}]", channelNumber, address, cause);
                }
            });

            try {
                channel.basicQos(rabbitConnectionProperties.getQosPrefetchCount());
            } catch (IOException e) {
                LOG.error(e.getMessage() , e);
                throw new IllegalStateException("Unable to set the QoS to [" +  rabbitConnectionProperties.getQosPrefetchCount() + "]", e);
            }
        });

        return cachingConnectionFactory;
    }

    /**
     * @return Configured {@link RabbitTemplate}.
     */
    @Bean
    @Profile("production")
    public RabbitTemplate amqpTemplate(RabbitConnectionProperties rabbitConnectionProperties) {
        return new RabbitTemplate(connectionFactory(rabbitConnectionProperties));
    }


    @Bean
    @Profile("production")
    public RabbitAdmin rabbitAdmin(RabbitConnectionProperties rabbitConnectionProperties){
        return new RabbitAdmin(connectionFactory(rabbitConnectionProperties));
    }


    @Bean
    @Profile("production")
    public RabbitConnectionChecker rabbitConnectionChecker(RabbitTemplate amqpTemplate){
        return new RabbitConnectionChecker(amqpTemplate);
    }

}
