package com.victorbuckservices.vbackbone.common.logging.message;

import net.logstash.logback.argument.StructuredArgument;
import net.logstash.logback.argument.StructuredArguments;

/**
 * @author Raval
 *         Created on 11/09/2015
 */
public interface Message {

    String MESSAGE_CODE = "messageCode";

    String getCode();

    default StructuredArgument valueCode() {
        return StructuredArguments.v(MESSAGE_CODE, getCode());
    }
}
