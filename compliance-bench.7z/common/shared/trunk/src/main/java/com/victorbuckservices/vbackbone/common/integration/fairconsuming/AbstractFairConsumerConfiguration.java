package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import com.victorbuckservices.vbackbone.common.actionhandler.ActionDispatcher;
import com.victorbuckservices.vbackbone.common.busbuilder.BusBuilderService;
import com.victorbuckservices.vbackbone.common.exception.BadConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.amqp.Amqp;
import org.springframework.integration.dsl.channel.MessageChannels;

import java.util.Arrays;
import java.util.List;

import static com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairAggregatorSpec.fairAggregator;
import static com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairAmqpConsummerFactory.newThreadPoolTaskExecutor;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
public abstract class AbstractFairConsumerConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractFairConsumerConfiguration.class);

    @Autowired
    protected ActionDispatcher actionDispatcher;

    @Autowired
    protected BusBuilderService busBuilderService;

    @Autowired
    protected AmqpHeaderMapper mapAllHeadersHeaderMapper;

    @Autowired
    protected FairConsumerHelper fairConsumerHelper;

    @Value("${vbackbone.fairConsumer.prefetch:50}")
    protected int fairConsumerPrefetch;

    @Bean
    public IntegrationFlow serviceDispatcherFlow() {
        return IntegrationFlows.from(MessageChannels.direct(getServiceInChannelName())).handle(actionDispatcher::dispatch).get();
    }

    @Bean
    @Profile("production")
    public IntegrationFlow amqpFairServiceInboundFlow(IntegrationFlow serviceDispatcherFlow, ConnectionFactory connectionFactory, RabbitTemplate amqpTemplate, AmqpAdmin amqpAdmin) throws BadConfigurationException {
        checkQueuesExist(amqpAdmin);

        String[] queuesName = getFairConsumerSlots().stream().map(FairConsumerSlot::getQueueName).toArray(String[]::new);

        return IntegrationFlows.from(
                Amqp.inboundAdapter(connectionFactory, queuesName)
                        .prefetchCount(10)
                        .acknowledgeMode(AcknowledgeMode.MANUAL)
                        .headerMapper(mapAllHeadersHeaderMapper))
                .handle(fairAggregator().taskExecutor(newThreadPoolTaskExecutor(10)).outputChannelName(getServiceInChannelName()).slots(getFairConsumerSlots())).get();
    }

    private void checkQueuesExist(AmqpAdmin amqpAdmin) throws BadConfigurationException {

        Object[] queuesInError = getFairConsumerSlots().stream()
                .filter(s -> amqpAdmin.getQueueProperties(s.getQueueName()) == null)
                .toArray();

        if (queuesInError.length > 0) {
            LOG.error("The queues [{}] does not exist", queuesInError);
            throw new BadConfigurationException("The queues [" + Arrays.toString(queuesInError) + "] does not exist");
        }
    }

    protected abstract String getServiceInChannelName();

    protected abstract List<FairConsumerSlot> getFairConsumerSlots();

}
