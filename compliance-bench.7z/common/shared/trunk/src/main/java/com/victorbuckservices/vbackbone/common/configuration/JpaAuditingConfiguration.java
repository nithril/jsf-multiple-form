package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.common.utils.date.DateTimeService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.util.Calendar;

/**
 * Created on 04/28/2015
 *
 * @author labrot
 */
@Configuration
@EnableJpaAuditing(dateTimeProviderRef = JpaAuditingConfiguration.BEAN_AUDITING_DATETIME_PROVIDER)
public class JpaAuditingConfiguration {

    public static final String BEAN_AUDITING_DATETIME_PROVIDER = "auditingDateTimeProvider";

    @Bean(name = BEAN_AUDITING_DATETIME_PROVIDER)
    public DateTimeProvider auditingDateTimeProvider(DateTimeService dateTimeService){
        return () -> {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateTimeService.nowAsDate());
            return calendar;
        };
    }
}
