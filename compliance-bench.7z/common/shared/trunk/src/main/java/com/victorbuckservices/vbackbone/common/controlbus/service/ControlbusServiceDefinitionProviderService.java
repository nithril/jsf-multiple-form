package com.victorbuckservices.vbackbone.common.controlbus.service;

import com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusCommonAction;
import com.victorbuckservices.vbackbone.common.controlbus.definition.ControlBusVbbMimeType;
import com.victorbuckservices.vbackbone.shared.ServiceDefinition;
import com.victorbuckservices.vbackbone.shared.service.ServiceDefinitionProviderService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

/**
 * Default implementation of {@link ControlbusServiceDefinitionProviderService}.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
@Service
public class ControlbusServiceDefinitionProviderService implements ServiceDefinitionProviderService {

    public ServiceDefinition getServiceDefinition() {
        ServiceDefinition serviceDefinition = new ServiceDefinition();
        serviceDefinition.setActions(Arrays.asList(ControlBusCommonAction.values()));
        serviceDefinition.setVbbMimeTypes(Arrays.asList(ControlBusVbbMimeType.values()));
        return serviceDefinition;
    }
}
