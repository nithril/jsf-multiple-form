package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import com.victorbuckservices.vbackbone.common.uuid.locality.LocalityUuidGeneratorService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Created on 03/24/2015
 *
 * @author labrot
 */
@Configuration
public class UuidGeneratorConfiguration {


    @Bean
    @Profile("test-with-frozen-uuidgenerator")
    public FrozenUuidGeneratorService frozenUuidGeneratorService(){
        return new FrozenUuidGeneratorService();
    }

    @Bean
    @Profile("!test-with-frozen-uuidgenerator")
    public LocalityUuidGeneratorService localityUuidGeneratorService(){
        return new LocalityUuidGeneratorService();
    }


}
