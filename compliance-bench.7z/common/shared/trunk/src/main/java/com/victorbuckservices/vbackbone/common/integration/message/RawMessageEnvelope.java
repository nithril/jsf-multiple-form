package com.victorbuckservices.vbackbone.common.integration.message;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.RawJsonDeserializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.RawJsonSerializer;

/**
 * The goal of the envelope is to define an internal header and body inside the message payload.
 * The reason to not directly use the message header is the possibility to have an unlimited number
 * of custom properties without performance drop with RabbitMQ.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public class RawMessageEnvelope extends GenericMessageEnvelope<byte[]> {

    /**
     * Create a new {@link RawMessageEnvelope}.
     */
    public RawMessageEnvelope() {
    }

    /**
     * Create a new {@link RawMessageEnvelope}.
     */
    public RawMessageEnvelope(MessageEnvelopeHeader header, byte[] body) {
        super(header, body);
    }


    /**
     * Getter for property 'body'.
     *
     * @return Value for property 'body'.
     */
    @JsonSerialize(using = RawJsonSerializer.class)
    public byte[] getBody() {
        return super.getBody();
    }

    /**
     * Setter for property 'body'.
     *
     * @param body Value to set for property 'body'.
     */
    @JsonDeserialize(using = RawJsonDeserializer.class)
    public void setBody(byte[] body) {
        super.setBody(body);
    }

    @Override
    public String toString() {
        return "MessageEnvelope{" +
                "header=" + getHeader() +
                '}';
    }

}
