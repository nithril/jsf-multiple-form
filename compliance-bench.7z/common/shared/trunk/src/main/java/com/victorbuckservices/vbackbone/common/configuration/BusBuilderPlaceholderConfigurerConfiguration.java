package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition.BusBuilderSchemaDefinition;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.service.SchemaParser;
import com.victorbuckservices.vbackbone.common.busbuilder.BusBuilderService;
import org.springframework.beans.factory.config.YamlProcessor;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 *
 * This configuration creates a Spring placeholder from all the bus builder YAML files available on the classpath.
 * The resource resolver scans classpath for YAML configuation with the following expressions {@link #RESOURCES_LOCATION}.
 *
 * Thereby, queue and exchange names become available through placeholder resolution.
 *
 * Created on 02/23/2015
 *
 * @author labrot
 */
@Configuration
public class BusBuilderPlaceholderConfigurerConfiguration implements ResourceLoaderAware {

    public static final String BEAN_BUS_CONFIGURATION_AS_PROPERTIES = "busConfigurationAsProperties";
    public static final String RESOURCES_LOCATION = "classpath*:/bus/configuration/**/*-latest.yaml";

    private ResourcePatternResolver resourceLoader;

    @Bean
    public BusBuilderService busBuilderService() throws IOException {
        Resource[] resources = resourceLoader.getResources(RESOURCES_LOCATION);
        Map<String,BusBuilderSchemaDefinition> objectMap = new HashMap<>();
        for (Resource resource : resources) {
            try(InputStream inputStream = resource.getInputStream()){
                BusBuilderSchemaDefinition schemaDefinition = SchemaParser.parse(inputStream, Collections.emptyMap());
                objectMap.put(schemaDefinition.getSchemaName(), schemaDefinition);
            }
        }
        return new BusBuilderService(objectMap);
    }


    @Bean(name = BEAN_BUS_CONFIGURATION_AS_PROPERTIES)
    public Properties busConfigurationAsProperties() throws IOException {
        PathMatchingResourcePatternResolver resourcesResolver = new PathMatchingResourcePatternResolver(resourceLoader);
        YamlPropertiesFactoryBean factoryBean = new YamlPropertiesFactoryBean();
        factoryBean.setResources(resourcesResolver.getResources(RESOURCES_LOCATION));
        factoryBean.setResolutionMethod(YamlProcessor.ResolutionMethod.OVERRIDE);
        return factoryBean.getObject();
    }

    @Bean
    public PropertySourcesPlaceholderConfigurer busConfigurationPropertySourcesPlaceholderConfigurer() throws IOException {
        PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
        configurer.setProperties(busConfigurationAsProperties());
        return configurer;
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = (ResourcePatternResolver) resourceLoader;
    }
}
