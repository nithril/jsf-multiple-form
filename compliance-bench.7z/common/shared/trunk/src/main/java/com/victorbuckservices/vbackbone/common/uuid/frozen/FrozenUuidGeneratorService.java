package com.victorbuckservices.vbackbone.common.uuid.frozen;

import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;

import java.time.Instant;
import java.util.Collection;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Frozen implementation of {@link UuidGeneratorService}.
 * <p/>
 * Created by lardinois on 26/11/2014.
 */
public class FrozenUuidGeneratorService implements UuidGeneratorService {
    private Deque<String> uuids = new ConcurrentLinkedDeque<>();

    @Override
    public String generateUuid() {
        return uuids.pop();
    }

    /**
     * Getter for property 'uuids'.
     *
     * @return Value for property 'uuids'.
     */

    public Collection<String> getUuids() {
        return uuids;
    }

    /**
     * Setter for property 'uuids'.
     *
     * @param uuids Value to set for property 'uuids'.
     */
    public void setUuids(Collection<String> uuids) {
        this.uuids = new ConcurrentLinkedDeque<>(uuids);
    }

    @Override
    public Instant toInstant(String uuid) {
        // First we remove the dashes
        String uuidWithoutDashes = uuid.replace("-", "");

        String hexDate = uuidWithoutDashes.substring(0, 12);

        long millis = Long.parseLong(hexDate, 16);

        return Instant.ofEpochMilli(millis);
    }

    @Override
    public int toService(String uuid) {
        // First we remove the dashes
        String uuidWithoutDashes = uuid.replace("-", "");
        String hexService = uuidWithoutDashes.substring(18, 20);
        return Integer.parseInt(hexService, 16);
    }
}
