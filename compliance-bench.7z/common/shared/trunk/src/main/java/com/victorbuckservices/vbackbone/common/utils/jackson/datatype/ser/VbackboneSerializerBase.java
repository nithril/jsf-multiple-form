package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Base class that indicates that all Vbackbone datatypes are serialized as scalar JSON types.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
abstract class VbackboneSerializerBase <T> extends StdSerializer<T> {

    protected VbackboneSerializerBase(Class<T> supportedType)
    {
        super(supportedType);
    }

    @Override
    public void serializeWithType(T value, JsonGenerator generator, SerializerProvider provider,
                                  TypeSerializer serializer) throws IOException
    {
        serializer.writeTypePrefixForScalar(value, generator);
        this.serialize(value, generator, provider);
        serializer.writeTypeSuffixForScalar(value, generator);
    }
}
