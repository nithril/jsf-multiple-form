package com.victorbuckservices.vbackbone.common.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.victorbuckservices.vbackbone.common.utils.CommonObjectMapperFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * This class hold the jackson {link ObjectMapper}s initialized with the {@link ServiceDefinitionDirectoryService}
 * {link ObjectMapper} is thread safe and can be shared across the application
 *
 * Created on 02/20/2015
 *
 * @author labrot
 */
@Service
public class ObjectMapperService {

    private ObjectMapper jsonMapper;

    @Autowired
    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    /**
     * Initialize the {@link ObjectMapper}.
     */
    @PostConstruct
    public void initMapper() {
        this.jsonMapper = CommonObjectMapperFactory.newObjectMapper(serviceDefinitionDirectoryService);
    }

    public ObjectMapper jsonMapper() {
        return jsonMapper;
    }
}
