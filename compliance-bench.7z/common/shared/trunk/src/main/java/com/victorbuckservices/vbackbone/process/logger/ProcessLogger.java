package com.victorbuckservices.vbackbone.process.logger;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.logstash.logback.argument.StructuredArguments.kv;
import static net.logstash.logback.argument.StructuredArguments.v;

/**
 * Created on 07/02/2015
 *
 * @author labrot
 */
public class ProcessLogger {

    public static final String PROCESS_LOGGER_NAME = "com.victorbuckservices.vbackbone.process.logger.ProcessLogger";
    public static final String ACTION_LOGGER_NAME = "com.victorbuckservices.vbackbone.process.logger.ActionLogger";

    public static final Logger PROCESS_LOG = LoggerFactory.getLogger(PROCESS_LOGGER_NAME);
    public static final Logger ACTION_LOG = LoggerFactory.getLogger(ACTION_LOGGER_NAME);


    public static void startProcess(Service service){
        PROCESS_LOG.info("{} {}" , v("status" , "START") , kv("service", service));
    }

    public static void endProcess(Service service){
        PROCESS_LOG.info("{} {}" , v("status" , "END") , kv("service", service));
    }

    public static void endProcessWithError(Service service){
        PROCESS_LOG.info("{} {}", v("status", "ERROR"), kv("service", service));
    }


    public static void startAction(Action action){
        ACTION_LOG.info("{} {} {}" , v("status" , "START") , kv("service", action.getService()) , kv("action" , action));
    }

    public static void endAction(Action action){
        ACTION_LOG.info("{} {} {}" , v("status" , "END") , kv("service", action.getService()) , kv("action" , action));
    }

    public static void endActionWithError(Action action){
        ACTION_LOG.info("{} {} {}", v("status", "ERROR"), kv("service", action.getService()), kv("action", action));
    }


    protected ProcessLogger() {
    }
}
