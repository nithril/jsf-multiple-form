package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.dsl.core.MessageHandlerSpec;

import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
public class FairAggregatorSpec extends MessageHandlerSpec<FairAggregatorSpec, FairAggregator> {
    private static final Logger LOG = LoggerFactory.getLogger(FairAggregatorSpec.class);

    private String outputChannelName;
    private List<FairConsumerSlot> slots;
    private ExecutorService executorService;


    FairAggregatorSpec slots(List<FairConsumerSlot> slots){
        this.slots = slots;
        return this;
    }

    public FairAggregatorSpec taskExecutor(ExecutorService taskExecutor) {
        this.executorService = taskExecutor;
        return this;
    }

    public FairAggregatorSpec outputChannelName(String outputChannelName) {
        this.outputChannelName = outputChannelName;
        return this;
    }

    @Override
    protected FairAggregator doGet() {
        return new FairAggregator(slots , executorService, outputChannelName);
    }



    public static final FairAggregatorSpec fairAggregator(){
        return new FairAggregatorSpec();
    }
}
