package com.victorbuckservices.vbackbone.common.integration.fairconsuming.exception;

/**
 * Created on 22/09/2015
 *
 * @author labrot
 */
public class NormallyStopConsumingException extends Exception {

    public NormallyStopConsumingException() {
    }

    public NormallyStopConsumingException(String message) {
        super(message);
    }

    public NormallyStopConsumingException(String message, Throwable cause) {
        super(message, cause);
    }

    public NormallyStopConsumingException(Throwable cause) {
        super(cause);
    }

    public NormallyStopConsumingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
