package com.victorbuckservices.vbackbone.common.controlbus.definition;

import com.victorbuckservices.vbackbone.common.controlbus.definition.dto.StartConsumersRequest;
import com.victorbuckservices.vbackbone.common.controlbus.definition.dto.StopConsumersRequest;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public enum ControlBusVbbMimeType implements VbbMimeType {

    START_CONSUMERS_REQUEST(
            "application/vnd.vbs.vbackbone.common.controlbus.start-consumers-request-1.0+json;charset=UTF-8;v=1.0", StartConsumersRequest.class),
    STOP_CONSUMERS_REQUEST(
            "application/vnd.vbs.vbackbone.common.controlbus.stop-consumers-request-1.0+json;charset=UTF-8;v=1.0", StopConsumersRequest.class);

    private final String name;
    private final Class<?> contentClass;

    ControlBusVbbMimeType(String name, Class<?> contentClass) {
        this.name = name;
        this.contentClass = contentClass;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Class<?> getContentClass() {
        return contentClass;
    }
}
