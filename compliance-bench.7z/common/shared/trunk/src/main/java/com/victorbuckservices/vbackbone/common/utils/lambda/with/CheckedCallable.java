package com.victorbuckservices.vbackbone.common.utils.lambda.with;

import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

import java.util.concurrent.Callable;

/**
 * Created on 4/09/2015
 *
 * @author labrot
 */
public interface CheckedCallable<V> extends Callable<V> {

    V checkedCall() throws Exception;

    @Override
    default V call() throws UncheckedExecutionException {
        try {
            return checkedCall();
        } catch (Exception e) {
            throw new UncheckedExecutionException(e);
        }
    }
}
