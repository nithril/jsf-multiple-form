package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.common.controlbus.inbound.ControlbusInboundConfiguration;
import com.victorbuckservices.vbackbone.common.controlbus.outbound.ControlbusOutboundConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
@Configuration
@Import({
        ControlbusInboundConfiguration.class
        , ControlbusOutboundConfiguration.class
})
@ComponentScan("com.victorbuckservices.vbackbone.common.controlbus.service")
public class ControlBusConfiguration {

}
