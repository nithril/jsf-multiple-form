package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.victorbuckservices.vbackbone.shared.definition.Service;

import java.io.IOException;

/**
 * Serializer for Java 8 temporal {@link Service}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public final class ServiceSerializer extends VbackboneSerializerBase<Service> {
    public static final ServiceSerializer INSTANCE = new ServiceSerializer();

    private ServiceSerializer() {
        super(Service.class);
    }

    @Override
    public void serialize(Service vbackboneService, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeString(vbackboneService.getUrn());
    }
}
