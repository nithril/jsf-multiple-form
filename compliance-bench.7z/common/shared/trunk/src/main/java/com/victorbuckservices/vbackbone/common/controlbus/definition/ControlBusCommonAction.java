package com.victorbuckservices.vbackbone.common.controlbus.definition;

import com.victorbuckservices.vbackbone.common.definition.CommonService;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;


/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public enum ControlBusCommonAction implements Action {

    START_CONSUMERS_REQUEST(
            Constants.START_CONSUMERS_REQUEST,
            "Start consumer request",
            "Start consumer request",
            CommonService.UNKNOWN_SERVICE),

    STOP_CONSUMERS_REQUEST(
            Constants.STOP_CONSUMERS_REQUEST,
            "Stop consumer request",
            "Stop consumer request",
            CommonService.UNKNOWN_SERVICE);

    /**
     * Holds the urn as constants
     *
     */
    public static class Constants {
        public static final String START_CONSUMERS_REQUEST = "urn:vbs:action:vbackbone:common:controlbus:start-consumers:1.0";
        public static final String STOP_CONSUMERS_REQUEST = "urn:vbs:action:vbackbone:common:controlbus:stop-consumers:1.0";
    }

    private final String urn;
    private final String name;
    private final String description;
    private final Service service;

    ControlBusCommonAction(String urn, String name, String description, Service service) {
        this.urn = urn;
        this.name = name;
        this.description = description;
        this.service = service;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public Service getService() {
        return service;
    }

}
