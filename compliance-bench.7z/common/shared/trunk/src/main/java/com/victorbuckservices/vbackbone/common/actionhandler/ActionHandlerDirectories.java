package com.victorbuckservices.vbackbone.common.actionhandler;

import com.victorbuckservices.vbackbone.common.actionhandler.handler.Handler;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Created by nlabrot on 28/11/14.
 */
@Service
public class ActionHandlerDirectories {

    private static final Logger LOG = LoggerFactory.getLogger(ActionHandlerDirectories.class);

    private Deque<Handler> handlers = new ConcurrentLinkedDeque<>();

    /**
     * Add a new handler
     * @param handler
     */
    public void addHandler(Handler handler) {
        handlers.add(handler);
    }

    /**
     * Add a new handler
     * @param accept Predicate what will matche {@link GenericMessageEnvelope}
     * @param consumer Consumer of a {@link GenericMessageEnvelope}
     */
    public <T, R> void addHandler(Predicate<GenericMessageEnvelope<?>> accept, Function<GenericMessageEnvelope<T>, R> consumer) {
        handlers.add(Handler.of(accept, consumer));
    }

    /**
     * Find the first handler which matches the {@code messageEnvelope}
     * @param messageEnvelope
     * @return
     */
    public Optional<Handler> findFirst(GenericMessageEnvelope messageEnvelope) {
        return handlers.stream().filter(i -> i.test(messageEnvelope)).findFirst();
    }

    /**
     * Remove handlers according to a predicate
     * @param predicate
     * @return
     */
    public boolean removeIf(Predicate<Handler> predicate){
        return handlers.removeIf(predicate);
    }


    /**
     *
     * @return A list copy of the handlers
     */
    public List<Handler> getHandlers() {
        return new ArrayList<>(handlers);
    }

    public void clearHandlers(){
        handlers.clear();
    }
}
