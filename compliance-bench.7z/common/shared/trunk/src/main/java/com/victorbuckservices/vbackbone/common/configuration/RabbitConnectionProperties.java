package com.victorbuckservices.vbackbone.common.configuration;

/**
 * Rabbit connection properties
 *
 * @author labrot
 */
public class RabbitConnectionProperties {

    private String host;
    private int port;

    private String addresses;

    private String username;
    private String password;

    private String virtualHost;

    private int connectionTimeout = 5000;
    private int requestedHeartbeat = 30000;

    private int qosPrefetchCount = 5;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVirtualHost() {
        return virtualHost;
    }

    public void setVirtualHost(String virtualHost) {
        this.virtualHost = virtualHost;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public int getRequestedHeartbeat() {
        return requestedHeartbeat;
    }

    public void setRequestedHeartbeat(int requestedHeartbeat) {
        this.requestedHeartbeat = requestedHeartbeat;
    }

    public int getQosPrefetchCount() {
        return qosPrefetchCount;
    }

    public void setQosPrefetchCount(int qosPrefetchCount) {
        this.qosPrefetchCount = qosPrefetchCount;
    }

    public String getAddresses() {
        return addresses;
    }

    public void setAddresses(String addresses) {
        this.addresses = addresses;
    }
}
