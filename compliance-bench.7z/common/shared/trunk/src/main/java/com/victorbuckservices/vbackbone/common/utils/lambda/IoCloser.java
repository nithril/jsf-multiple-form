package com.victorbuckservices.vbackbone.common.utils.lambda;

import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Created on 03/16/2015
 *
 * @author labrot
 */
public class IoCloser {

    List<CompletableFuture> completableFutures = new ArrayList<>();

    public static IoCloser ioCloser() {
        return new IoCloser();

    }

    public IoCloser close(AutoCloseable... closeables) {
        for (AutoCloseable closeable : closeables) {
            silentClose(closeable::close);
        }
        return this;
    }

    public IoCloser close(XMLStreamReader... streams) {
        for (XMLStreamReader stream : streams) {
            silentClose(stream::close);
        }
        return this;
    }

    public IoCloser close(XMLStreamWriter... streams) {
        for (XMLStreamWriter stream : streams) {
            silentClose(stream::close);
        }
        return this;
    }


    public IoCloser close(Object... objects) {
        for (Object o : objects) {
            if (o instanceof AutoCloseable) {
                close((AutoCloseable) o);
            } else if (o instanceof XMLStreamReader) {
                close((XMLStreamReader) o);
            } else if (o instanceof XMLStreamWriter) {
                close((XMLStreamWriter) o);
            }
        }
        return this;
    }

    /**
     * Get the result or throw exception if any occurs
     *
     * @throws Exception
     */
    public boolean get() throws Exception {
        try {
            CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[]{})).get();
            return true;
        } catch (Exception e) {
            throw e;
        }
    }

    private void silentClose(ThrowableRunnable c) {
        CompletableFuture completableFuture = new CompletableFuture();
        try {
            c.run();
            completableFuture.complete(true);
        } catch (Exception e) {
            completableFuture.completeExceptionally(e);
        }
        completableFutures.add(completableFuture);
    }

    @FunctionalInterface
    private interface ThrowableRunnable {
        void run() throws Exception;
    }

}
