package com.victorbuckservices.vbackbone.shared.definition;

/**
 * Created by labrot on 01/22/2015.
 */
public class VbackboneHeaders {

    public static final String PREFIX = "vbb_";

    public static final String HEADER_VBB_CONTENT_TYPE = "contentType";
    public static final String HEADER_VBB_TIMESTAMP = "timestamp";
    public static final String HEADER_VBB_ACTION_URN = "vbb-action-urn";
    public static final String HEADER_VBB_STATUS_LEVEL = "vbb-status-level";

    public static final String HEADER_ROUTING_KEY = "routingKey";

    public static final String ROUTING_KEY = "routingKey";
    public static final String ROUTING_KEY_EXPRESSION = "headers.routingKey";

    protected VbackboneHeaders() {
    }
}
