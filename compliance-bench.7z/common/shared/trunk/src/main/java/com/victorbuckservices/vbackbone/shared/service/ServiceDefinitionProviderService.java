package com.victorbuckservices.vbackbone.shared.service;

import com.victorbuckservices.vbackbone.shared.ServiceDefinition;

/**
 * Each Vbackbone service must implement this service that expose its {@link ServiceDefinition}.
 *
 * @author Marc Plouhinec
 * Created on 11/12/2014.
 */
public interface ServiceDefinitionProviderService
{
    /**
     * @return a {@link com.victorbuckservices.vbackbone.shared.ServiceDefinition}.
     */
    ServiceDefinition getServiceDefinition();
}
