package com.victorbuckservices.vbackbone.shared.integration;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;

import java.io.IOException;

/**
 * All Vbackbone services must define a {@link Gateway} in order to standardize the way to send messages in RabbitMQ.
 * For example the "Data Manager" service must create a DataManagerInputGateway. Vgate will thus use the
 * DataManagerInputGateway to send a message to the input queue of the "Data Manager".
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public interface Gateway {

    /**
     * @return Spring Integration {@link MessageChannel} used to send message in a specific channel.
     */
    MessageChannel getMessageChannel();


    /**
     * Send a message with a specific routing key
     * Used for replyTo response
     *
     * @param routingKey
     * @param header
     * @param body
     * @return
     * @throws IOException
     */
    boolean sendMessage(String routingKey, MessageEnvelopeHeader header, Object body) throws IOException;

    /**
     * Same as {@link #sendMessage(String, MessageEnvelopeHeader, Object)} but doesn't throw any exception.
     */
    default boolean sendMessageQuietly(String routingKey, MessageEnvelopeHeader header, Object body) {
        try {
            return sendMessage(routingKey, header, body);
        } catch (IOException e) {
            LoggerFactory.getLogger(getClass()).error("Unable to send a message (header = [{}], body = [{}]).", header , body , e);
            return false;
        }
    }


    /**
     * Convert and send a message.
     *
     * @return true if the message was successfully sent, false if not.
     */
    boolean sendMessage(MessageEnvelopeHeader header, Object body) throws IOException;

    /**
     * Same as {@link #sendMessage(MessageEnvelopeHeader, Object)} but doesn't throw any exception.
     */
    default boolean sendMessageQuietly(MessageEnvelopeHeader header, Object body) {
        try {
            return sendMessage(header, body);
        } catch (IOException e) {
            LoggerFactory.getLogger(getClass()).error("Unable to send a message (header = [{}], body = [{}]).", header , body , e);
            return false;
        }
    }

}
