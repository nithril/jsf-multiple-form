package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.integration.amqp.support.AmqpHeaderMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.amqp.Amqp;
import org.springframework.integration.util.CallerBlocksPolicy;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static com.victorbuckservices.vbackbone.common.integration.fairconsuming.FairAggregatorSpec.fairAggregator;
import static java.util.concurrent.TimeUnit.HOURS;

/**
 * Created on 5/10/2015
 *
 * @author labrot
 */
public class FairAmqpConsummerFactory {

    public static IntegrationFlow newAmqpFairConsummer(List<FairConsumerSlot> slots, ConnectionFactory connectionFactory, int prefetch, AmqpHeaderMapper headerMapper, String outputChannelName, int nbOfConcurrentProcessing) {
        Validate.notNull(slots);
        Validate.notNull(connectionFactory);
        Validate.notNull(connectionFactory);
        Validate.isTrue(prefetch > 0);
        Validate.notNull(headerMapper);
        Validate.notNull(outputChannelName);
        Validate.isTrue(nbOfConcurrentProcessing > 0);

        String[] queuesName = slots.stream().map(FairConsumerSlot::getQueueName).toArray(String[]::new);

        return IntegrationFlows.from(
                Amqp.inboundAdapter(connectionFactory, queuesName)
                        .prefetchCount(prefetch)
                        .acknowledgeMode(AcknowledgeMode.MANUAL)
                        .headerMapper(headerMapper))
                .handle(fairAggregator().outputChannelName(outputChannelName).taskExecutor(newThreadPoolTaskExecutor(nbOfConcurrentProcessing)).slots(slots)).get();
    }


    public static ExecutorService newThreadPoolTaskExecutor(int nbOfConcurrentProcessing) {
        Validate.isTrue(nbOfConcurrentProcessing > 0);

        //TODO: set the capacity to 0
        ThreadPoolExecutor messageExecutorService = new ThreadPoolExecutor(nbOfConcurrentProcessing + 1, nbOfConcurrentProcessing + 1,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(1));

        messageExecutorService.setRejectedExecutionHandler(new CallerBlocksPolicy(HOURS.toMillis(4)));

        return messageExecutorService;
    }
}
