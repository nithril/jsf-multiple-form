package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.binding.Binding;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 23/09/2015
 *
 * @author labrot
 */
public class PrioritizedQueue {

    @JsonProperty("queue_name_prefix")
    private String queueNamePrefix;

    @JsonProperty("queue_durable")
    private boolean queueDurable;

    @JsonProperty("exchange_source")
    private String exchangeSource;

    @JsonProperty("exchange_routing_key_prefix")
    private String exchangeRoutingKeyPrefix;

    @JsonProperty("bindings")
    private List<PrioritizedQueueBinding> bindings;


    public String getQueueNamePrefix() {
        return queueNamePrefix;
    }

    public void setQueueNamePrefix(String queueNamePrefix) {
        this.queueNamePrefix = queueNamePrefix;
    }

    public boolean isQueueDurable() {
        return queueDurable;
    }

    public void setQueueDurable(boolean queueDurable) {
        this.queueDurable = queueDurable;
    }

    public String getExchangeSource() {
        return exchangeSource;
    }

    public void setExchangeSource(String exchangeSource) {
        this.exchangeSource = exchangeSource;
    }

    public String getExchangeRoutingKeyPrefix() {
        return exchangeRoutingKeyPrefix;
    }

    public void setExchangeRoutingKeyPrefix(String exchangeRoutingKeyPrefix) {
        this.exchangeRoutingKeyPrefix = exchangeRoutingKeyPrefix;
    }

    public List<PrioritizedQueueBinding> getBindings() {
        return bindings;
    }

    public void setBindings(List<PrioritizedQueueBinding> bindings) {
        this.bindings = bindings;
    }


    public List<Pair<Queue, QueuePriority>> resolveQueues() {
        return Arrays.stream(QueuePriority.values())
                .map(p -> Pair.of(new Queue().withName(constructQueueName(p)).withDurable(queueDurable), p))
                .collect(Collectors.toList());
    }


    public List<Binding> resolveBindings() {

        if (bindings == null || bindings.isEmpty()) {
            return Arrays.stream(QueuePriority.values())
                    .map(p -> resolveBinding(exchangeSource, exchangeRoutingKeyPrefix, p))
                    .collect(Collectors.toList());
        } else {

            return bindings.stream()
                    .flatMap(
                            b -> Arrays.stream(QueuePriority.values())
                                    .map(p -> resolveBinding(b.getExchangeSource(), b.getExchangeRoutingKeyPrefix(), p))
                    )
                    .collect(Collectors.toList());
        }
    }

    private Binding resolveBinding(String exchangeSource, String exchangeRoutingKeyPrefix, QueuePriority p) {
        return new Binding()
                .withDestination(constructQueueName(p))
                .withSource(exchangeSource)
                .withRoutingKey(constructRoutingKey(exchangeRoutingKeyPrefix, p))
                .withDestinationType("queue");
    }

    private String constructQueueName(QueuePriority p) {
        return queueNamePrefix + "." + p.getValue();
    }


    private String constructRoutingKey(String exchangeRoutingKeyPrefix, QueuePriority p) {
        return exchangeRoutingKeyPrefix + "." + p.getValue();
    }


}
