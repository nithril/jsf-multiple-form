package com.victorbuckservices.vbackbone.common.actionhandler.response;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public enum ActionStatus {
    OK,
    ERROR
}
