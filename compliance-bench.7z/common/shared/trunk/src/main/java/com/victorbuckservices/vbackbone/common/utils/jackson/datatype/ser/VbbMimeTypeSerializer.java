package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

import java.io.IOException;

/**
 * Serializer for {@link VbbMimeType}s.
 *
 * @author Marc Plouhinec
 *         Created on 20/10/2014.
 */
public final class VbbMimeTypeSerializer extends VbackboneSerializerBase<VbbMimeType> {
    public static final VbbMimeTypeSerializer INSTANCE = new VbbMimeTypeSerializer();

    private VbbMimeTypeSerializer() {
        super(VbbMimeType.class);
    }

    @Override
    public void serialize(VbbMimeType vbbMimeType, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeString(vbbMimeType.getName());
    }
}
