package com.victorbuckservices.vbackbone.common.monitoring;

import static net.logstash.logback.argument.StructuredArguments.kv;

import com.victorbuckservices.vbackbone.common.service.IdentificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class MonitoringLogger {

    public static final String IDENTIFICATION_MONITORING_LOGGER_NAME = "com.victorbuckservices.vbackbone.common.monitoring.identification.IdentificationLogger";
    public static final String RABBIT_STATUS_MONITORING_LOGGER_NAME = "com.victorbuckservices.vbackbone.common.monitoring.rabbitstatus.RabbitStatusLogger";

    public static final Logger IDENTIFICATION_MONITORING_LOGGER = LoggerFactory.getLogger(IDENTIFICATION_MONITORING_LOGGER_NAME);
    public static final Logger RABBIT_STATUS_MONITORING_LOGGER = LoggerFactory.getLogger(RABBIT_STATUS_MONITORING_LOGGER_NAME);

    protected MonitoringLogger() {
    }

    public static void identification(IdentificationService identificationService) {
        IDENTIFICATION_MONITORING_LOGGER.info("{} {} {} {} {} {}"
                , kv("name", identificationService.getName())
                , kv("version", identificationService.getVersion())
                , kv("discriminant", identificationService.getDiscriminant())
                , kv("hostname", identificationService.getHostname())
                , kv("processId", identificationService.getProcessId())
                , kv("instanceId", identificationService.getInstanceId())
        );
    }

    public static void rabbitStatus(IdentificationService identificationService, boolean isRunning , int queuedMessages, int ongoingProcess) {
        RABBIT_STATUS_MONITORING_LOGGER.info("{} {} {} {} {}"
                , kv("name", identificationService.getName())
                , kv("instanceId", identificationService.getInstanceId())
                , kv("running" , isRunning)
                , kv("queuedMessages" , queuedMessages)
                , kv("ongoingProcess" , ongoingProcess)
        );
    }

}
