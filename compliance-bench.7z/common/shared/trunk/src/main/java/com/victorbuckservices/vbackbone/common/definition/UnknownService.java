package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Service;

/**
 * Class used to parse a {@link Service} that is not registered in the {@link com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService}.
 * Note: this class should normally never be used.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
public class UnknownService implements Service {

    private final String urn;

    /**
     * Create a new {@link UnknownService}.
     */
    public UnknownService(String urn) {
        this.urn = urn;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return urn;
    }

    @Override
    public String getVersion() {
        return "0";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UnknownService that = (UnknownService) o;

        return urn.equals(that.urn);

    }

    @Override
    public int hashCode() {
        return urn.hashCode();
    }
}
