package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;

import java.io.IOException;

/**
 * Base class that indicates that all Vbackbone datatypes are deserialized from scalar JSON types.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
abstract class VbackboneDeserializerBase<T> extends StdScalarDeserializer<T> {

    protected VbackboneDeserializerBase(Class<T> supportedType)
    {
        super(supportedType);
    }

    @Override
    public Object deserializeWithType(JsonParser parser, DeserializationContext context, TypeDeserializer deserializer)
            throws IOException
    {
        return deserializer.deserializeTypedFromAny(parser, context);
    }
}
