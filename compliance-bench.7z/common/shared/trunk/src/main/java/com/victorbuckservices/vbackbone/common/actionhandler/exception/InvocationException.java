package com.victorbuckservices.vbackbone.common.actionhandler.exception;

/**
 * Exception occuring during the invocation of an action interceptor.
 *
 * Created on 02/02/2015
 *
 * @author labrot
 */
public class InvocationException extends Exception {

    private final boolean nack;
    private final boolean requeue;


    public InvocationException(String message, Throwable cause, boolean nack, boolean requeue) {
        super(message, cause);
        this.nack = nack;
        this.requeue = requeue;
    }

    public boolean isNack() {
        return nack;
    }

    public boolean isRequeue() {
        return requeue;
    }

    public static final InvocationException newNackAndRequeueException(Throwable cause){
        return new InvocationException(cause.getMessage() , cause , true, true);
    }

    public static final InvocationException newNackAndDequeueException(Throwable cause){
        return new InvocationException(cause.getMessage() , cause , true, false);
    }

    public static final InvocationException newException(Throwable cause, boolean nack, boolean requeue){
        return new InvocationException(cause.getMessage() , cause , nack, requeue);
    }

}
