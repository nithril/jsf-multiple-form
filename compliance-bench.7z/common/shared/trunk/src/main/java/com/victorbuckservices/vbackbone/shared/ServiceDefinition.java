package com.victorbuckservices.vbackbone.shared;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Contain the definition of a Vbackbone service.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public class ServiceDefinition {
    private List<Service> services = Collections.emptyList();
    private List<Action> actions = Collections.emptyList();
    private List<Status> statuses = Collections.emptyList();
    private List<VbbMimeType> vbbMimeTypes = Collections.emptyList();

    /**
     * Getter for property 'services'.
     *
     * @return Value for property 'services'.
     */
    public List<Service> getServices() {
        return new ArrayList<>(services);
    }

    /**
     * Setter for property 'services'.
     *
     * @param services Value to set for property 'services'.
     */
    public void setServices(List<Service> services) {
        this.services = new ArrayList<>(services);
    }

    /**
     * Getter for property 'actions'.
     *
     * @return Value for property 'actions'.
     */
    public List<Action> getActions() {
        return new ArrayList<>(actions);
    }

    /**
     * Setter for property 'actions'.
     *
     * @param actions Value to set for property 'actions'.
     */
    public void setActions(List<Action> actions) {
        this.actions = new ArrayList<>(actions);
    }

    /**
     * Getter for property 'statuses'.
     *
     * @return Value for property 'statuses'.
     */
    public List<Status> getStatuses() {
        return new ArrayList<>(statuses);
    }

    /**
     * Setter for property 'statuses'.
     *
     * @param statuses Value to set for property 'statuses'.
     */
    public void setStatuses(List<Status> statuses) {
        this.statuses = new ArrayList<>(statuses);
    }

    /**
     * Getter for property 'vbbMimeTypes'.
     *
     * @return Value for property 'vbbMimeTypes'.
     */
    public List<VbbMimeType> getVbbMimeTypes() {
        return new ArrayList<>(vbbMimeTypes);
    }

    /**
     * Setter for property 'vbbMimeTypes'.
     *
     * @param vbbMimeTypes Value to set for property 'vbbMimeTypes'.
     */
    public void setVbbMimeTypes(List<VbbMimeType> vbbMimeTypes) {
        this.vbbMimeTypes = new ArrayList<>(vbbMimeTypes);
    }

}
