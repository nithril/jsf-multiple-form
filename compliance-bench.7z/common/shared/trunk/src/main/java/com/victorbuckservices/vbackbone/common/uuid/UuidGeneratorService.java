package com.victorbuckservices.vbackbone.common.uuid;

import java.time.Instant;

/**
 * Service for generating UUIDs.
 * <p/>
 * Created by lardinois on 26/11/2014.
 */

public interface UuidGeneratorService {
    /**
     * @return new generated UUID.
     */
    String generateUuid();

    default Instant toInstant(String uuid) {
        throw new UnsupportedOperationException("UuidGeneratorService.toDate()");
    }

    default int toService(String uuid) {
        throw new UnsupportedOperationException("UuidGeneratorService.toService()");
    }
}
