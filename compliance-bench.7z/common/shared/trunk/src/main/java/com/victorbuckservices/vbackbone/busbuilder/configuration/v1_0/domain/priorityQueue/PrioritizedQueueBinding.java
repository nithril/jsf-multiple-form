package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created on 23/09/2015
 *
 * @author labrot
 */
public class PrioritizedQueueBinding {

    @JsonProperty("exchange_source")
    private String exchangeSource;

    @JsonProperty("exchange_routing_key_prefix")
    private String exchangeRoutingKeyPrefix;


    public String getExchangeSource() {
        return exchangeSource;
    }

    public void setExchangeSource(String exchangeSource) {
        this.exchangeSource = exchangeSource;
    }

    public String getExchangeRoutingKeyPrefix() {
        return exchangeRoutingKeyPrefix;
    }

    public void setExchangeRoutingKeyPrefix(String exchangeRoutingKeyPrefix) {
        this.exchangeRoutingKeyPrefix = exchangeRoutingKeyPrefix;
    }
}
