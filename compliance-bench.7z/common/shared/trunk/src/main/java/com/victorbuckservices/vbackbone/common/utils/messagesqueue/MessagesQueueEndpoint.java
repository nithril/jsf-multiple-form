package com.victorbuckservices.vbackbone.common.utils.messagesqueue;

import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.io.IOException;

/**
 * Messages queue endpoint which could be used as a service activator.
 * <p/>
 * Created by Raval on 10/16/2014.
 */
public class MessagesQueueEndpoint extends AbstractMessagesQueue {
    private static final Logger LOG = LoggerFactory.getLogger(MessagesQueueEndpoint.class);

    @Autowired
    private CommonConversionService commonConversionService;

    /**
     * Create a new {@link MessagesQueueEndpoint}.
     */
    public MessagesQueueEndpoint(long timeoutMillis) {
        super(timeoutMillis);
    }

    /**
     * Create a new {@link MessagesQueueEndpoint}.
     */
    public MessagesQueueEndpoint() {
        super();
    }

    /**
     * Handle the given {@link Message}.
     */
    public void handleMessage(Message<byte[]> message) {
        try {
            queueMessage(commonConversionService.parseMessageEnvelopeHeaderAndBody(message.getHeaders(), message.getPayload()));
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    /**
     * Handle the given {@link Message}.
     */
    public void handleMessage(GenericMessageEnvelope<?> message) {
        queueMessage(message);
    }
}
