package com.victorbuckservices.vbackbone.common.integration.rabbit;

import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

/**
 * Check RabbitMQ connection when an {@code org.springframework.context.ApplicationContext} gets initialized or refreshed.
 * <p/>
 * @author labrot
 */
public class RabbitConnectionChecker implements ApplicationListener<ContextRefreshedEvent> {

    private static final Logger LOG = LoggerFactory.getLogger(RabbitConnectionChecker.class);

    private final RabbitTemplate rabbitTemplate;

    public RabbitConnectionChecker(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        try {
            LOG.info("Check RabbitMQ connection...");
            Validate.isTrue(rabbitTemplate.execute(c -> c.getConnection().isOpen()));
            LOG.info("Check RabbitMQ connection: [OK]");
        } catch (Exception e) {
            LOG.error("Check RabbitMQ connection: [FAILED]", e);
            throw new IllegalStateException(e);
        }
    }

    public RabbitTemplate getRabbitTemplate() {
        return rabbitTemplate;
    }
}
