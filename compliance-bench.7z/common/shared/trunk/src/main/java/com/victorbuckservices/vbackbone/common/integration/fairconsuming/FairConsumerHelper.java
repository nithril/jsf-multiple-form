package com.victorbuckservices.vbackbone.common.integration.fairconsuming;

import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.definition.BusBuilderSchemaDefinition;
import com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.domain.priorityQueue.PrioritizedQueue;
import com.victorbuckservices.vbackbone.common.busbuilder.BusBuilderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * https://github.com/nithril/article-fair-consuming-with-rabbitmq
 */
@Service
public class FairConsumerHelper {

    @Autowired
    private BusBuilderService busBuilderService;


    public List<FairConsumerSlot> toFairConsumerSlot(PrioritizedQueue prioritizedQueue) {
        return prioritizedQueue.resolveQueues().stream()
                .map(qp -> new FairConsumerSlot(qp.getLeft().getName(), qp.getRight().getWeight())).collect(Collectors.toList());
    }


    public List<FairConsumerSlot> getFairConsumerSlotsFromService(String bbService) {
        BusBuilderSchemaDefinition schemaDefinition = busBuilderService.findByService(bbService);
        return schemaDefinition.getPrioritizedQueues().values().stream()
                .flatMap(pq -> toFairConsumerSlot(pq).stream())
                .collect(Collectors.toList());
    }

    public List<FairConsumerSlot> getFairConsumerSlotsFromService(String bbService, List<String> prefixesIncluded) {
        BusBuilderSchemaDefinition schemaDefinition = busBuilderService.findByService(bbService);
        return schemaDefinition.getPrioritizedQueues().values().stream()
                .filter(pq -> prefixesIncluded.contains(pq.getQueueNamePrefix()))
                .flatMap(pq -> toFairConsumerSlot(pq).stream())
                .collect(Collectors.toList());
    }
}
