package com.victorbuckservices.vbackbone.common.transaction;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * Created on 02/26/2015
 *
 * @author labrot
 */
public class DoInTransactionService {


    /**
     * Execute with the {@link Propagation#REQUIRED} propagation
     * @param callable
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public <R> R execute(Callable<R> callable) throws Exception {
        return callable.call();
    }


    /**
     * Execute with the {@link Propagation#REQUIRES_NEW} propagation
     * @param callable
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public <R> R executeRequiresNew(Callable<R> callable) throws Exception {
        return callable.call();
    }


    public void executeAfterCommit(Runnable runnable){
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter(){
            public void afterCommit(){
                runnable.run();
            }
        });
    }

    public void executeAfterCompletion(Consumer<Integer> afterCompletion) {
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCompletion(int status) {
                afterCompletion.accept(status);
            }
        });
    }


}
