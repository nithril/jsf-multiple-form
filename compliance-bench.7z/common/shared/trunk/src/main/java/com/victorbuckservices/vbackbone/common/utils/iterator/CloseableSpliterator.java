package com.victorbuckservices.vbackbone.common.utils.iterator;

import java.io.Closeable;
import java.util.Spliterator;

/**
 * Closeable iterator
 *
 * Created on 15/09/2015
 *
 * @author labrot
 */
public interface CloseableSpliterator<T> extends Spliterator<T>, Closeable {

}
