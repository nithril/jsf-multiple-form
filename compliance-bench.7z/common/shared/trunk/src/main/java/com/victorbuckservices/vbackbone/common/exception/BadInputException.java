package com.victorbuckservices.vbackbone.common.exception;

/**
 * Created by labrot on 12/08/2014.
 */
public class BadInputException extends RuntimeException {

    public BadInputException(Throwable cause) {
        super(cause);
    }
}
