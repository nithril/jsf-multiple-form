package com.victorbuckservices.vbackbone.common.service;

import com.victorbuckservices.vbackbone.shared.ServiceDefinition;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;
import com.victorbuckservices.vbackbone.shared.service.ServiceDefinitionProviderService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;

/**
 * Default implementation of {@link ServiceDefinitionDirectoryService}.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
@org.springframework.stereotype.Service
public class ServiceDefinitionDirectoryService  {

    @Autowired
    private ServiceDefinitionProviderService[] serviceDefinitionProviderServices;

    private Map<String, Service> serviceByUrn;
    private Map<String, Action> actionByUrn;
    private Map<String, Status> statusByUrn;
    private Map<String, VbbMimeType> vbbMimeTypeByName;

    /**
     * Create an index of service definition enums.
     */
    @PostConstruct
    public void indexServiceDefinitions() {
        serviceByUrn = new LinkedHashMap<>();
        actionByUrn = new LinkedHashMap<>();
        statusByUrn = new LinkedHashMap<>();
        vbbMimeTypeByName = new LinkedHashMap<>();

        for (ServiceDefinitionProviderService serviceDefinitionProviderService : serviceDefinitionProviderServices) {
            ServiceDefinition serviceDefinition = serviceDefinitionProviderService.getServiceDefinition();
            for (Service service : serviceDefinition.getServices()) {
                serviceByUrn.put(service.getUrn(), service);
            }
            for (Action action : serviceDefinition.getActions()) {
                actionByUrn.put(action.getUrn(), action);
            }
            for (Status status : serviceDefinition.getStatuses()) {
                statusByUrn.put(status.getUrn(), status);
            }
            for (VbbMimeType vbbMimeType : serviceDefinition.getVbbMimeTypes()) {
                vbbMimeTypeByName.put(vbbMimeType.getName(), vbbMimeType);
            }
        }
    }

    /**
     * @return The {@link com.victorbuckservices.vbackbone.shared.definition.Service} that matches the given URN or null if unknown.
     */
    public Service findServiceByUrn(String urn) {
        return serviceByUrn.get(urn);
    }


    /**
     * @return All {@link Service}s.
     */
    public List<Service> findAllServices() {
        return new ArrayList<>(serviceByUrn.values());
    }


    /**
     * @return The {@link com.victorbuckservices.vbackbone.shared.definition.Action} that matches the given URN or null if unknown.
     */
    public Action findActionByUrn(String urn) {
        return actionByUrn.get(urn);
    }

    /**
     * @return All {@link Action}s.
     */
    public List<Action> findAllActions() {
        return new ArrayList<>(actionByUrn.values());
    }

    /**
     * @return The {@link com.victorbuckservices.vbackbone.shared.definition.Status} that matches the given URN or null if unknown.
     */
    public Status findStatusByUrn(String urn) {
        return statusByUrn.get(urn);
    }

    /**
     * @return All {@link Status}es.
     */
    public List<Status> findAllStatuses() {
        return new ArrayList<>(statusByUrn.values());
    }

    /**
     * @return The {@link com.victorbuckservices.vbackbone.shared.definition.VbbMimeType} that matches the given name or null if unknown.
     */
    public VbbMimeType findVbbMimeTypeByName(String name) {
        return vbbMimeTypeByName.get(name);
    }

    /**
     * @return All {@link VbbMimeType}s.
     */
    public List<VbbMimeType> findAllVbbMimeTypes() {
        return new ArrayList<>(vbbMimeTypeByName.values());
    }
}
