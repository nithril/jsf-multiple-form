package com.victorbuckservices.vbackbone.common.utils.lambda.with;


import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

import java.util.function.Consumer;

/**
 * Created by nlabrot on 10/03/15.
 */
@FunctionalInterface
public interface CheckedConsumer<T> extends Consumer<T> {

    void checkedApply(T t) throws Exception;

    @Override
    default void accept(T t) throws UncheckedExecutionException{
        try {
            checkedApply(t);
        } catch (Exception e) {
            throw new UncheckedExecutionException(e);
        }
    }
}
