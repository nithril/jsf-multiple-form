package com.victorbuckservices.vbackbone.busbuilder.configuration.v1_0.exception;

/**
 * @author labrot
 *         Created on 11/19/2014
 */
public class BusBuilderException extends RuntimeException {
    public BusBuilderException() {
    }

    public BusBuilderException(String s) {
        super(s);
    }

    public BusBuilderException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public BusBuilderException(Throwable throwable) {
        super(throwable);
    }

    public BusBuilderException(String s, Throwable throwable, boolean b, boolean b2) {
        super(s, throwable, b, b2);
    }
}
