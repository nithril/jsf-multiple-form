package com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.victorbuckservices.vbackbone.shared.definition.Status;

import java.io.IOException;

/**
 * Serializer for Java 8 temporal {@link Status}s.
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public final class StatusSerializer extends VbackboneSerializerBase<Status> {
    public static final StatusSerializer INSTANCE = new StatusSerializer();

    private StatusSerializer() {
        super(Status.class);
    }

    @Override
    public void serialize(Status status, JsonGenerator generator, SerializerProvider provider) throws IOException {
        generator.writeString(status.getUrn());
    }
}
