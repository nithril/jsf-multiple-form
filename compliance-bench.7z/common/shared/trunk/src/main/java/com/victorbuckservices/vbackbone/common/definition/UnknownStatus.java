package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Status;

/**
 * Class used to parse a {@link Status} that is not registered in the {@link com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService}.
 * Note: this class should normally never be used.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
public class UnknownStatus implements Status {

    private final String urn;

    /**
     * Create a new {@link UnknownStatus}.
     */
    public UnknownStatus(String urn) {
        this.urn = urn;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return urn;
    }
}
