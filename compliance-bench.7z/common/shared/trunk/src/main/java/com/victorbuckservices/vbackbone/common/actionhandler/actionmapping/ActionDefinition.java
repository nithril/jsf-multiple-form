package com.victorbuckservices.vbackbone.common.actionhandler.actionmapping;

import org.apache.commons.lang3.tuple.Pair;

import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Created by nlabrot on 28/11/14.
 */
public class ActionDefinition {

    private final Object bean;
    private final Method method;

    private final String actionUrn;
    private final String mimeTypeUrn;

    private final Class<? extends Throwable>[] nackAndRequeues;
    private final Class<? extends Throwable>[] nackAndDequeues;

    public ActionDefinition(Object bean, Method method, String actionUrn, String mimeTypeUrn, Class<? extends Throwable>[] nackAndRequeues, Class<? extends Throwable>[] nackAndDequeues) {
        this.bean = bean;
        this.method = method;
        this.actionUrn = actionUrn;
        this.mimeTypeUrn = mimeTypeUrn;
        this.nackAndRequeues = Arrays.copyOf(nackAndRequeues, nackAndRequeues.length);
        this.nackAndDequeues = Arrays.copyOf(nackAndDequeues, nackAndDequeues.length);
    }

    public Object getBean() {
        return bean;
    }

    public Method getMethod() {
        return method;
    }

    public String getActionUrn() {
        return actionUrn;
    }

    public String getMimeTypeUrn() {
        return mimeTypeUrn;
    }


    public Class<? extends Throwable>[] getNackAndRequeues() {
        return nackAndRequeues;
    }

    public Class<? extends Throwable>[] getNackAndDequeues() {
        return nackAndDequeues;
    }

    public boolean hasNackAndRequeues() {
        return nackAndRequeues.length > 0;
    }

    public boolean hasNackAndDequeues() {
        return nackAndDequeues.length > 0;
    }


    public Pair<Boolean, Boolean> resolveNackFor(Class<? extends Throwable> throwableClass) {
        boolean nack = false;
        boolean requeue = false;

        if (Arrays.stream(nackAndDequeues).filter(n -> n.isAssignableFrom(throwableClass)).findFirst().isPresent()){
            nack = true;
        }else if (Arrays.stream(nackAndRequeues).filter(n -> n.isAssignableFrom(throwableClass)).findFirst().isPresent()){
            nack = true;
            requeue = true;
        }

        return Pair.of(nack , requeue);
    }


}
