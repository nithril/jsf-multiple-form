package com.victorbuckservices.vbackbone.common.controlbus.definition.dto;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class StartConsumersRequest {

    private String instanceId;

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }
}
