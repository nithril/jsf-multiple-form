package com.victorbuckservices.vbackbone.common.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created on 23/09/2015
 *
 * @author labrot
 */
@Configuration
@ComponentScan("com.victorbuckservices.vbackbone.common.integration.fairconsuming")
public class FairConsumingConfiguration
{

}
