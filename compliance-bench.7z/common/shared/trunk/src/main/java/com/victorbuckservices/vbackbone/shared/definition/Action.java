package com.victorbuckservices.vbackbone.shared.definition;

import com.victorbuckservices.vbackbone.common.utils.UrnHelper;

/**
 * Enum interface that defines the the action the message must trigger.
 *
 * @author Marc Plouhinec
 *         Created on 14/10/2014
 */
public interface Action {

	/**
	 * E.g. "urn:vbs:action:vbackbone:datamanager:unpack-files-request:1.0"
	 *
	 * @return Unique identifier for a specific action version.
	 */
	String getUrn();

	/**
	 * E.g. "Request for unpacking files."
	 *
	 * @return Action name.
	 */
	String getName();

	/**
	 * @return A description of the action.
	 */
	default String getDescription() {
		return "";
	}

	/**
	 * E.g. "1.0"
	 *
	 * @return action version.
	 */
	default String getVersion() {
		return UrnHelper.extractVersion(getUrn());
	}

	/**
	 * @return {@link Service} that defines this action.
	 */
	Service getService();
}
