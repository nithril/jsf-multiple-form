package com.victorbuckservices.vbackbone.shared.definition;

import com.victorbuckservices.vbackbone.common.utils.UrnHelper;

import java.util.Collections;
import java.util.List;

/**
 * Enum interface that defines the the action the message must trigger.
 *
 * @author Marc Plouhinec
 *         Created on 14/10/2014
 */
public interface Action
{

    /**
     * E.g. "urn:vbs:action:vbackbone:datamanager:unpack-files-request:1.0"
     *
     * @return Unique identifier for a specific action version.
     */
    String getUrn();

    /**
     * E.g. "Request for unpacking files."
     *
     * @return Action name.
     */
    String getName();

    /**
     * @return A description of the action.
     */
    default String getDescription() {
        return "";
    }

    /**
     * E.g. "1.0"
     *
     * @return action version.
     */
    default String getVersion(){
        return UrnHelper.extractVersion(getUrn());
    }

    /**
     * @return {@link Service} that defines this action.
     */
    Service getService();

    /**
     * An action must always provide at least one {@link VbbMimeType}. In case of an empty body, the value
     * {@link com.victorbuckservices.vbackbone.common.definition.CommonVbbMimeType#EMPTY} must be set.
     * Moreover, an action can also provide one or more {@link VbbMimeType}s related to {@link org.springframework.beans.factory.parsing.Problem}s.
     * However, the first - and only the first - must be a {@link VbbMimeType} that is NOT related to a
     * {@link org.springframework.beans.factory.parsing.Problem}.
     *
     * @return {@link VbbMimeType}s of the body that can be provided for this action.
     */
    List<VbbMimeType> getContentTypes();

    /**
     * @return If any, list of {@link ConfigurableActionParameter}s that can be configured in a tool like Vgate.
     */
    List<ConfigurableActionParameter> getConfigurableActionParameters();

    /**
     * @return The {@link Status}es the header may contain with this action.
     */
    default List<Status> getStatuses() {
        return Collections.emptyList();
    }

}
