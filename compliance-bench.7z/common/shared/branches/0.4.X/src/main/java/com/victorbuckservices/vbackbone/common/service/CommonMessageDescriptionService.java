package com.victorbuckservices.vbackbone.common.service;

import com.victorbuckservices.vbackbone.common.definition.CommonService;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.service.MessageDescriptionService;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Common version of the {@link com.victorbuckservices.vbackbone.shared.service.MessageDescriptionService}.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
@org.springframework.stereotype.Service
public class CommonMessageDescriptionService implements MessageDescriptionService {

    @Override
    public String buildDescription(MessageEnvelopeHeader header, Object body) throws IOException {
        return "Action: '" + header.getAction().getName() + "'" + (header.getStatus() == null ? "." : ", status: '" + header.getStatus().getName() + "'.");
    }

    @Override
    public List<Service> getSupportedServices() {
        return Arrays.asList(CommonService.values());
    }
}
