package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;
import org.springframework.util.MimeType;

/**
 * Class used to parse an {@link VbbMimeType} that is not registered in the {@link com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService}.
 * Note: this class should normally never be used.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public class UnknownVbbMimeType implements VbbMimeType {

    private final String name;
    private final String version;

    /**
     * Create a new {@link UnknownVbbMimeType}.
     */
    public UnknownVbbMimeType(String name) {
        this.name = name;
        this.version = MimeType.valueOf(name).getParameter(VERSION_PARAMETER);
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public String getName() {
        return name;
    }
}
