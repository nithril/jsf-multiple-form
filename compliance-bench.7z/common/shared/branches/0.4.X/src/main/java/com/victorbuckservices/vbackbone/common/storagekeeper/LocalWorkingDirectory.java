package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.storagekeeper.exception.LocalFolderAlreadyExistingException;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.LocalFolderCreationException;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.StorageContainerAlreadyExistingException;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.StorageFolderCreationException;

import java.io.File;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public class LocalWorkingDirectory {

    private File localBase;
    private File storageContainer;

    private File input;
    private File output;
    private File temp;

    private String processUuid;

    boolean isMain = false;
    boolean isSub = true;

    public LocalWorkingDirectory() {
    }

    private void init() {
        input = new File(localBase, "input");
        output = new File(localBase, "output");
        temp = new File(localBase, "temp");
    }

    public File getLocalBase() {
        return localBase;
    }

    public void setLocalBase(String baseFolder) {
        localBase = new File(baseFolder);

        if (localBase.exists()) {
            throw new LocalFolderAlreadyExistingException(localBase.getAbsolutePath());
        }

        this.init();
    }

    public String getProcessUuid() {
        return processUuid;
    }

    public void setProcessUuid(String processUuid) {
        this.processUuid = processUuid;
    }

    public void setLocalBase(LocalWorkingDirectory localWorkingDirectory, String subFolder) {
        localBase = new File(localWorkingDirectory.getLocalBase(), "temp_" + subFolder);

        if (localBase.exists()) {
            throw new LocalFolderAlreadyExistingException(localBase.getAbsolutePath());
        }

        this.init();
    }

    public File getStorageContainer() {
        return storageContainer;
    }

    public void setStorageContainer(String baseFolder) {
        storageContainer = new File(baseFolder);

        if (storageContainer.exists()) {
            throw new StorageContainerAlreadyExistingException(storageContainer.getAbsolutePath());
        }
    }

    public void makeLocalDirs() {
        if (!localBase.mkdirs()) {
            throw new LocalFolderCreationException(localBase.getAbsolutePath());
        }
        if (!temp.mkdirs()) {
            throw new LocalFolderCreationException(temp.getAbsolutePath());
        }
        if (!input.mkdirs()) {
            throw new LocalFolderCreationException(input.getAbsolutePath());
        }
        if (!output.mkdirs()) {
            throw new LocalFolderCreationException(output.getAbsolutePath());
        }
    }

    public void makeStorageDirs() {
        // If the folder already exists, the mkdirs() will return false
        if (!storageContainer.getParentFile().exists() && !storageContainer.getParentFile().mkdirs()) {
            throw new StorageFolderCreationException(storageContainer.getParentFile().getAbsolutePath());
        }
    }

    public File input() {
        return input;
    }

    public File output() {
        return output;
    }

    public File temp() {
        return temp;
    }

    public boolean isMain() {
        return isMain;
    }

    public boolean isSub() {
        return isSub;
    }
}
