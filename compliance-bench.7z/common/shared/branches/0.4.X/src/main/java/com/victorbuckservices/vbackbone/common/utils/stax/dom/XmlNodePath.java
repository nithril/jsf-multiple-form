package com.victorbuckservices.vbackbone.common.utils.stax.dom;

import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Lardinois
 *         Created on 25/02/2015
 */
public class XmlNodePath {

    private final String nodePath;

    /**
     * Create new {@link XmlNodePath}
     * @param nodePath
     */
    public XmlNodePath(String nodePath) {
        this.nodePath = nodePath;
    }

    /**
     * Create new {@link XmlNodePath}
     * @param nodeList
     */
    public XmlNodePath(List<String> nodeList) {
        this.nodePath = toNodePath(nodeList);
    }

    /**
     * Getter for property 'nodePath'.
     *
     * @return Value for property 'nodePath'.
     */
    public String getNodePath() {
        return nodePath;
    }

    public List<String> getPathElement(){
        return Arrays.asList(StringUtils.split(nodePath, "/"));
    }

    public List<String> getAllParentNodePath(){

        List<String> nodeList = this.getPathElement();
        List<String> PathList = new ArrayList<String>();

        StringBuffer buffer = new StringBuffer(nodeList.size()*10);
        for (int i = 0; i < nodeList.size(); i++) {
            buffer.append("/");
            buffer.append(nodeList.get(i));
            PathList.add(buffer.toString());
        }
        return PathList;
    }


    public static String toNodePath(List<String> nodeList){
        return "/" + StringUtils.join(nodeList, "/");
    }
}
