package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.springframework.core.io.Resource;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;

/**
 * Created on 16/10/2015
 *
 * @author labrot
 */
public class CloseableResourceAdapter implements CloseableResource {

    private final Resource adapter;

    public CloseableResourceAdapter(Resource adapter) {
        this.adapter = adapter;
    }

    @Override
    public void close() throws IOException {
    }

    @Override
    public boolean exists() {
        return adapter.exists();
    }

    @Override
    public boolean isReadable() {
        return adapter.isReadable();
    }

    @Override
    public boolean isOpen() {
        return adapter.isOpen();
    }

    @Override
    public URL getURL() throws IOException {
        return adapter.getURL();
    }

    @Override
    public URI getURI() throws IOException {
        return adapter.getURI();
    }

    @Override
    public File getFile() throws IOException {
        return adapter.getFile();
    }

    @Override
    public long contentLength() throws IOException {
        return adapter.contentLength();
    }

    @Override
    public long lastModified() throws IOException {
        return adapter.lastModified();
    }

    @Override
    public Resource createRelative(String relativePath) throws IOException {
        return adapter.createRelative(relativePath);
    }

    @Override
    public String getFilename() {
        return adapter.getFilename();
    }

    @Override
    public String getDescription() {
        return adapter.getDescription();
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return adapter.getInputStream();
    }

    public static CloseableResource newCloseableAdapter(Resource resource){
        return new CloseableResourceAdapter(resource);
    }
}
