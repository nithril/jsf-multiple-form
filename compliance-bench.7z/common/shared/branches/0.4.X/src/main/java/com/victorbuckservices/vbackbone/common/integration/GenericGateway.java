package com.victorbuckservices.vbackbone.common.integration;

import com.victorbuckservices.vbackbone.shared.definition.Service;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Generic Gateway with abstract methods implemented using final fields
 *
 * @author labrot
 *
 */
public class GenericGateway extends AbstractGateway {

    private static final Logger LOG = LoggerFactory.getLogger(GenericGateway.class);

    private final MessageChannel messageChannel;

    private final List<Service> ownerServices;

    public GenericGateway(MessageChannel messageChannel, List<Service> ownerServices) {
        Validate.notNull(messageChannel);
        Validate.notNull(ownerServices);

        this.messageChannel = messageChannel;
        this.ownerServices = Collections.unmodifiableList(new ArrayList<>(ownerServices));
    }

    public GenericGateway(MessageChannel messageChannel) {
        this(messageChannel , Collections.emptyList());
    }

    @Override
    public MessageChannel getMessageChannel() {
        return messageChannel;
    }

    @Override
    public List<Service> getOwnerServices() {
        return ownerServices;
    }
}
