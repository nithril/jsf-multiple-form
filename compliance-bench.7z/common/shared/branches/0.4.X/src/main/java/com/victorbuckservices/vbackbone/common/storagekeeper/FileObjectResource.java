package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.google.common.net.UrlEscapers;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public class FileObjectResource implements CloseableResource {

    private static final Logger LOG = LoggerFactory.getLogger(FileObjectResource.class);

    private final FileObject resource;
    private final FileSystemManager fileSystemManager;

    public FileObjectResource(FileSystemManager fileSystemManager, FileObject fo) {
        this.fileSystemManager = fileSystemManager;
        resource = fo;
    }

    @Override
    public boolean exists() {
        try {
            return resource.exists();
        } catch (FileSystemException e) {
            LOG.error("FileSystemException in 'exists' method! resource=[{}]", resource);
            throw new RuntimeException("FileSystemException in 'exists' method! resource=[" + resource.toString() + "]", e);
        }
    }

    @Override
    public boolean isReadable() {
        try {
            return resource.isReadable();
        } catch (FileSystemException e) {
            LOG.error("FileSystemException in 'isReadable' method! resource=[{}]", resource);
            throw new RuntimeException("FileSystemException in 'isReadable' method! resource=[" + resource.toString() + "]", e);
        }
    }

    @Override
    public boolean isOpen() {
        return resource.isContentOpen();
    }

    @Override
    public URL getURL() throws IOException {
        return resource.getURL();
    }

    @Override
    public URI getURI() throws IOException {
        String url;
        try {
            url = UrlEscapers.urlFragmentEscaper().escape(resource.getURL().toString());
            return new URI(url);
        } catch (URISyntaxException e) {
            LOG.error("URISyntaxException in 'getURI' method! url=[{}]", resource);
            throw new RuntimeException("URISyntaxException in 'getURI' method! resource=[" + resource.toString() + "]", e);
        }
    }

    @Override
    public String toString() {
        return resource.toString();
    }

    @Override
    public File getFile() throws IOException {
        throw new UnsupportedOperationException("FileObjectResource.getFile()");
    }

    @Override
    public long contentLength() throws IOException {
        FileContent content = resource.getContent();
        long size = content.getSize();
        content.close();
        return size;
    }

    @Override
    public long lastModified() throws IOException {
        FileContent content = resource.getContent();
        long lastModifiedTime = content.getLastModifiedTime();
        content.close();
        return lastModifiedTime;
    }

    @Override
    public Resource createRelative(String s) throws IOException {
        throw new UnsupportedOperationException("FileObjectResource.createRelative()");
    }

    @Override
    public String getFilename() {
        return resource.getName().getBaseName();
    }

    @Override
    public String getDescription() {
        throw new UnsupportedOperationException("FileObjectResource.getDescription()");
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return StorageKeeperUtils.newInputStream(resource);
    }


    @Override
    public void close() throws FileSystemException {
        resource.close();
        fileSystemManager.closeFileSystem(resource.getFileSystem());
    }
}
