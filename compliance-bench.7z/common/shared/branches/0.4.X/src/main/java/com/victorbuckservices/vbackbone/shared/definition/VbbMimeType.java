package com.victorbuckservices.vbackbone.shared.definition;

import org.springframework.util.MimeType;

/**
 * {@link MimeType} specific to Vbackbone.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public interface VbbMimeType {

    String VERSION_PARAMETER = "v";

    /**
     * E.g. "application/vnd.vbs-datamanager.unpack-files-notification+json"
     *
     * @return MimeType name
     */
    String getName();

    /**
     * E.g. "1.0"
     *
     * @return Mime type version.
     */
    String getVersion();

    /**
     * @return Class that defines the content of the message body.
     */
    default Class<?> getContentClass() {
        return Void.class;
    }

    /**
     * Convert the {@link VbbMimeType} into a {@link MimeType}.
     */
    default MimeType toMimeType() {
        return MimeType.valueOf(this.getName());
    }
}
