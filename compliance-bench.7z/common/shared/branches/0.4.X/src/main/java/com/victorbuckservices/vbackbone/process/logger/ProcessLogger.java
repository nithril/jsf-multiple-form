package com.victorbuckservices.vbackbone.process.logger;

import static net.logstash.logback.argument.StructuredArguments.kv;
import static net.logstash.logback.argument.StructuredArguments.v;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created on 07/02/2015
 *
 * @author labrot
 */
public class ProcessLogger {

    public static final Logger PROCESS_LOG = LoggerFactory.getLogger(ProcessLogger.class);

    public static void startProcess(Action action){
        PROCESS_LOG.info("{} {} {}" , v("status" , "START") , kv("service", action.getService()) , kv("action" , action));
    }

    public static void endProcess(Action action){
        PROCESS_LOG.info("{} {} {}" , v("status" , "END") , kv("service", action.getService()) , kv("action" , action));
    }

    public static void endProcessWithError(Action action){
        PROCESS_LOG.info("{} {} {}", v("status", "ERROR"), kv("service", action.getService()), kv("action", action));
    }
}
