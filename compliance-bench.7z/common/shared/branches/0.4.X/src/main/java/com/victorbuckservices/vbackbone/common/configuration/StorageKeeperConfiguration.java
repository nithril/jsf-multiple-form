package com.victorbuckservices.vbackbone.common.configuration;

import com.victorbuckservices.vbackbone.common.storagekeeper.nfs.NfsStorageKeeper;
import com.victorbuckservices.vbackbone.common.storagekeeper.sftp.SftpStorageKeeper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-28.
 */
@Configuration
public class StorageKeeperConfiguration {

    @Bean
    @Profile("!test-with-sftpstoragekeeper")
    public NfsStorageKeeper nfsStorageKeeper() { return new NfsStorageKeeper(); }

    @Bean
    @Profile("test-with-sftpstoragekeeper")
    public SftpStorageKeeper sftpStorageKeeper() { return new SftpStorageKeeper(); }
}
