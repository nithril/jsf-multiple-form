package com.victorbuckservices.vbackbone.shared.definition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Allow an {@link Action} to expose some of its parameters that can be configured in Vgate.
 * When a Vbackbone service starts, it sends all its supported {@link Action}s and {@link ConfigurableActionParameter}s to Vgate.
 * In Vgate, when a data set type or a job type is defined, the parameters can be configured, for example the archive format of a file to unpack.
 *
 * @author Marc Plouhinec
 * Created on 11/17/2014.
 */
public class ConfigurableActionParameter {

    private String name;
    private ConfigurableActionParameterType parameterType;
    private List<String> allowedValues;

    /**
     * Create a new {@link ConfigurableActionParameter}.
     */
    public ConfigurableActionParameter() {
    }

    /**
     * Create a new {@link ConfigurableActionParameter}.
     *
     * @param name Name of the parameter.
     * @param parameterType Type of parameter.
     * @param allowedValues If applicable, list of values the parameter can take. Can be null if there is no restriction.
     */
    public ConfigurableActionParameter(String name, ConfigurableActionParameterType parameterType, Object... allowedValues) {
        this.name = name;
        this.parameterType = parameterType;
        this.allowedValues = allowedValues == null ? Collections.emptyList() : new ArrayList<>(allowedValues.length);
        if (allowedValues != null) {
            for (Object allowedValue : allowedValues) {
                this.allowedValues.add(String.valueOf(allowedValue));
            }
        }
    }

    /**
     * Getter for property 'name'.
     *
     * @return Value for property 'name'.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for property 'name'.
     *
     * @param name Value to set for property 'name'.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property 'parameterType'.
     *
     * @return Value for property 'parameterType'.
     */
    public ConfigurableActionParameterType getParameterType() {
        return parameterType;
    }

    /**
     * Setter for property 'parameterType'.
     *
     * @param parameterType Value to set for property 'parameterType'.
     */
    public void setParameterType(ConfigurableActionParameterType parameterType) {
        this.parameterType = parameterType;
    }

    /**
     * Getter for property 'allowedValues'.
     *
     * @return Value for property 'allowedValues'.
     */
    public List<String> getAllowedValues() {
        return allowedValues;
    }

    /**
     * Setter for property 'allowedValues'.
     *
     * @param allowedValues Value to set for property 'allowedValues'.
     */
    public void setAllowedValues(List<String> allowedValues) {
        this.allowedValues = allowedValues;
    }

    @Override public String toString() {
        return "ConfigurableActionParameter{" +
                "name='" + name + '\'' +
                ", parameterType=" + parameterType +
                ", allowedValues=" + allowedValues +
                '}';
    }

    /**
     * Type of {@link ConfigurableActionParameter} an action can support.
     */
    public enum ConfigurableActionParameterType {
        ENUM, STRING, INTEGER, DOUBLE
    }
}
