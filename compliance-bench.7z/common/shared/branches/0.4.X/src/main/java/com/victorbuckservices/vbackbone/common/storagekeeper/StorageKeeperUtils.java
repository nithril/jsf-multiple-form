package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.apache.commons.io.input.ProxyInputStream;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created on 06/12/2015
 *
 * @author labrot
 */
public final class StorageKeeperUtils {

    /**
     * Create an {@link InputStream} from a {@link FileObject}. <br>
     * <p/>
     * This method wraps the {@link InputStream} in order to close automaticly the underlying {@link FileContent} needs to open the stream.
     *
     * @param fileObject
     * @return
     * @throws FileSystemException
     */
    public static InputStream newInputStream(FileObject fileObject) throws FileSystemException {
        FileContent fileContent = fileObject.getContent();

        return new ProxyInputStream(fileContent.getInputStream()) {
            @Override
            public void close() throws IOException {
                super.close();
                fileContent.close();
                fileObject.getFileSystem().getFileSystemManager().closeFileSystem(fileObject.getFileSystem());
            }
        };
    }

    /**
     * Create an {@link BufferedInputStream} from a {@link FileObject}. <br>
     * See {@link #newInputStream(FileObject)}
     * @param fileObject
     * @return
     * @throws FileSystemException
     */
    public static BufferedInputStream newBufferedInputStream(FileObject fileObject) throws FileSystemException {
        return new BufferedInputStream(newInputStream(fileObject));
    }

}
