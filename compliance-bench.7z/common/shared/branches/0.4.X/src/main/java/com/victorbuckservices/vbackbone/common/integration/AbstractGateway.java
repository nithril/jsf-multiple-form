package com.victorbuckservices.vbackbone.common.integration;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import java.io.IOException;

/**
 * Abstract Gateway with the most common methods implemented
 *
 * @author Marc Plouhinec
 *         Created on 11/19/2014.
 */
public abstract class AbstractGateway implements Gateway {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractGateway.class);

    public static final String ROUTING_KEY = "routingKey";
    public static final String ROUTING_KEY_EXPRESSION = "headers.routingKey";

    @Autowired
    private CommonConversionService commonConversionService;

    @Override
    public boolean sendMessage(String routingKey, MessageEnvelopeHeader header, Object body) throws IOException {
        Message message = commonConversionService.buildMessage(header, body);
        return getMessageChannel().send(MessageBuilder.fromMessage(message).setHeader(ROUTING_KEY , routingKey).build());
    }

    @Override
    public boolean sendMessage(MessageEnvelopeHeader header, Object body) throws IOException {
        return getMessageChannel().send(commonConversionService.buildMessage(header, body));
    }

    @Override
    public boolean sendMessageQuietly(MessageEnvelopeHeader header, Object body) {
        try {
            return sendMessage(header, body);
        } catch (IOException e) {
            LOG.error("Unable to send a message (header = [{}], body = [{}]).", header , body , e);
            return false;
        }
    }
}
