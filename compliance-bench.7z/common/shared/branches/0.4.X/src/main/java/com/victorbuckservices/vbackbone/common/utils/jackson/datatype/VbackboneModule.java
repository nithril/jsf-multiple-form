package com.victorbuckservices.vbackbone.common.utils.jackson.datatype;

import com.fasterxml.jackson.core.util.VersionUtil;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.ActionDeserializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.ServiceDeserializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.StatusDeserializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.deser.VbbMimeTypeDeserializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser.ActionSerializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser.ServiceSerializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser.StatusSerializer;
import com.victorbuckservices.vbackbone.common.utils.jackson.datatype.ser.VbbMimeTypeSerializer;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Jackson module used to serialize and de-serialize Vbackbone enums defined by their URN.<br>
 * <br>
 * This class can be registered to Jackson core in the following way:<br>
 * <code>
 *     ObjectMapper mapper = new ObjectMapper();
 *     mapper.registerModule(new VbackboneModule(messageDirectoryService));
 * </code>
 *
 * @author Marc Plouhinec
 *         Created on 17/10/2014.
 */
public class VbackboneModule extends SimpleModule {

    /**
     * Create a new {@link VbackboneModule}.
     */
    public VbackboneModule(ServiceDefinitionDirectoryService serviceDefinitionDirectoryService) {
        super(VersionUtil.parseVersion("1.0.0", "com.victorbuckservices.vbackbone.common.utils.jackson.datatype", "vbackbone-shared"));

        addDeserializer(Service.class, new ServiceDeserializer(serviceDefinitionDirectoryService));
        addDeserializer(Action.class, new ActionDeserializer(serviceDefinitionDirectoryService));
        addDeserializer(Status.class, new StatusDeserializer(serviceDefinitionDirectoryService));
        addDeserializer(VbbMimeType.class, new VbbMimeTypeDeserializer(serviceDefinitionDirectoryService));

        addSerializer(Service.class, ServiceSerializer.INSTANCE);
        addSerializer(Action.class, ActionSerializer.INSTANCE);
        addSerializer(Status.class, StatusSerializer.INSTANCE);
        addSerializer(VbbMimeType.class, VbbMimeTypeSerializer.INSTANCE);
    }

}
