package com.victorbuckservices.vbackbone.common.uuid.random;

import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Type 4 {@link UuidGeneratorService}.
 * <p/>
 * Created by lardinois on 26/11/2014.
 */
public class RandomUuidGeneratorService implements UuidGeneratorService {
    @Override
    public String generateUuid() {
        return UUID.randomUUID().toString();
    }
}
