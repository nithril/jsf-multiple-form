package com.victorbuckservices.vbackbone.common.actionhandler.listener;

import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;

/**
 * Created by nlabrot on 03/03/15.
 */
@FunctionalInterface
public interface PreInvocationListener<T> {

    void apply(GenericMessageEnvelope<T> requestMessageEnvelope);
}
