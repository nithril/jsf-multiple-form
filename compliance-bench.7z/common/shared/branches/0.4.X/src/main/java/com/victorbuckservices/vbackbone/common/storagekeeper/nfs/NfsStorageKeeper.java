package com.victorbuckservices.vbackbone.common.storagekeeper.nfs;

import com.victorbuckservices.vbackbone.common.storagekeeper.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.StorageFolderCreationException;
import com.victorbuckservices.vbackbone.common.utils.lambda.IoCloser;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import org.apache.commons.lang3.Validate;
import org.apache.commons.vfs2.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.zeroturnaround.zip.ZipUtil;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.UUID;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-02-23.
 */
public class NfsStorageKeeper implements StorageKeeper {

    private static final Logger LOG = LoggerFactory.getLogger(NfsStorageKeeper.class);

    //TODO: find a geeky pattern
    private static final byte[] FILECONTENT = new byte[]{0, 1, 2, 3, 4, 5, 6};

    @Autowired
    protected UuidGeneratorService uuidGeneratorService;

    @Value("${storagekeeper.workDirectory}")
    private String serviceLocalDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String serviceStorageDirectory;

    @Value("${storagekeeper.compressionLevel:-1}")
    private int compressionLevel;

    private FileSystemManager fileSystemManager;
    private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd").withZone(ZoneOffset.UTC);

    @Override
    @PostConstruct
    public void init() {
        LOG.info("StorageKeeper.init()");
        try {
            fileSystemManager = VFS.getManager();
        } catch (FileSystemException e) {
            LOG.error("Unable to get the file system manager!");
            throw new RuntimeException("Unable to get the file system manager!", e);
        }

        testIfDirectoryIsWritableAndReadable(serviceLocalDirectory, true, true);
        testIfDirectoryIsWritableAndReadable(serviceStorageDirectory, true, false);
    }

    @Override
    public String uuidToDate(String uuid) {
        return dateTimeFormatter.format(uuidGeneratorService.toInstant(uuid));
    }

    @Override
    public String uuidToService(String uuid) {
        return "0x" + Integer.toHexString(uuidGeneratorService.toService(uuid));
    }

    @Override
    public String getStorageUri(String uuid, String resourcePath) {
        try {
            String containerName = fileSystemManager.resolveFile(getStorageDirectory(uuid)).toString();
            return "zip:" + containerName + "!/" + resourcePath;
        } catch (FileSystemException e) {
            throw new RuntimeException("Unable to resolve file [] with system manager!", e);
        }
    }

    public String getStorageDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);
        return Paths.get(this.serviceStorageDirectory, date, service, uuid + ".zip").toAbsolutePath().toString();
    }

    public String getBaseLocalWorkingDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);
        return Paths.get(this.serviceLocalDirectory, date, service, uuid).toAbsolutePath().toString();
    }

    @Override
    public LocalWorkingDirectory newLocalWorkingDirectoryTree() {

        String uuid = uuidGeneratorService.generateUuid();
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        LOG.info("StorageKeeper.newLocalWorkingDirectoryTree()");
        LOG.info("UUID=[{}] date=[{}] service=[{}].", uuid, date, service);

        String baseLocalWorkingDirectory = getBaseLocalWorkingDirectory(uuid);
        String baseStorageContainer = getStorageDirectory(uuid);

        LOG.info("Local folder: [{}].", baseLocalWorkingDirectory);
        LOG.info("Storage container: [{}].", baseStorageContainer);

        LocalWorkingDirectory localWorkingDirectory = new LocalWorkingDirectory();
        localWorkingDirectory.setLocalBase(baseLocalWorkingDirectory);
        localWorkingDirectory.setProcessUuid(uuid);
        localWorkingDirectory.setStorageContainer(baseStorageContainer);
        localWorkingDirectory.makeLocalDirs();
        localWorkingDirectory.makeStorageDirs();

        return localWorkingDirectory;
    }

    @Override
    public LocalWorkingDirectory newSubDirectoryTree(LocalWorkingDirectory localWorkingDirectory, String subFolder) {
        LOG.info("StorageKeeper.newSubDirectoryTree() with subFolder [{}]", subFolder);

        LocalWorkingDirectory workingSubDirectory = new LocalWorkingDirectory();
        workingSubDirectory.setLocalBase(localWorkingDirectory, subFolder);
        workingSubDirectory.makeLocalDirs();

        return workingSubDirectory;
    }

    @Override
    public String commitLocalOutput(LocalWorkingDirectory localWorkingDirectory) {
        LOG.info("StorageKeeper.commitLocalOutput() with compression level [{}]", compressionLevel);

        File localSourceFolder = localWorkingDirectory.output();
        File storageDestinationContainer = localWorkingDirectory.getStorageContainer();

        ZipUtil.pack(localSourceFolder.toPath().toFile(), storageDestinationContainer, compressionLevel);

        return storageDestinationContainer.getAbsolutePath();
    }

    @Override
    public FileObject getFileObject(String uri) {
        FileObject fileObject;
        try {
            fileObject = fileSystemManager.resolveFile(uri);
        } catch (FileSystemException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", uri);
            throw new RuntimeException("Unable to resolve file [" + uri + "] with system manager!", e);
        }

        return fileObject;
    }

    @Override
    public FileContent getFileContent(String uri) {
        FileObject fileObject = getFileObject(uri);
        try {
            return fileObject.getContent();
        } catch (FileSystemException e) {
            LOG.error("Unable to get content of file [{}] with system manager!", uri);
            throw new RuntimeException("Unable to get content of file [" + uri + "] with system manager!", e);
        }
    }

    @Override
    public InputStream getInputStream(String uri) {
        try {
            return StorageKeeperUtils.newInputStream(getFileObject(uri));
        } catch (FileSystemException e) {
            LOG.error("Unable to get inputStream of file [{}] with system manager!", uri, e);
            throw new RuntimeException("Unable to get inputStream of file [" + uri + "] with system manager!", e);
        }
    }

    @Override
    public CloseableResource getResource(String uri) {
        return new FileObjectResource(fileSystemManager, getFileObject(uri));
    }

    @Override
    public String getServiceLocalDirectory() {
        return serviceLocalDirectory;
    }

    public void setServiceLocalDirectory(String serviceLocalDirectory) {
        this.serviceLocalDirectory = serviceLocalDirectory;
    }

    @Override
    public String getServiceStorageDirectory() {
        return serviceStorageDirectory;
    }

    public void setServiceStorageDirectory(String serviceStorageDirectory) {
        this.serviceStorageDirectory = serviceStorageDirectory;
    }

    @Override
    public String provideLocalWith(LocalWorkingDirectory lwd, String uri) {

        /**
         * Get the storage-id:
         * input:
         * * LWD: /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/{input,output,temp}
         * * URI: zip:file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip!/bundles-email-composition.xml
         * container:
         * * URI: file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
         * copy to:
         * * URI file:///var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
         * translate:
         * * URI zip:file:///var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip!/bundles-email-composition.xml
         */

        // file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
        String containerUri = getContainerUri(uri);

        // 014d581f-e724-a040-0014-dd5765264b4c.zip
        String containerName = getFileObject(containerUri).getName().getBaseName();

        // FileObject of /mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
        FileObject containerSourceFileObject;
        try {
            containerSourceFileObject = fileSystemManager.resolveFile(containerUri);
            if (!containerSourceFileObject.exists()) {
                LOG.error("Unable to find file [{}] with system manager!", containerUri);
                throw new RuntimeException("Unable to find file [" + containerUri + "] with system manager!");
            }
        } catch (FileSystemException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", containerUri, e);
            throw new RuntimeException("Unable to resolve file [" + containerUri + "] with system manager!", e);
        }

        // /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
        //String destinationUri = Paths.get(new File(lwd.input(), containerName).getAbsolutePath()).toUri().toString();
        String destinationUri = null;
        File destinationFile = new File(lwd.input(), containerName);
        try {
            destinationUri = fileSystemManager.toFileObject(destinationFile).toString();
        } catch (FileSystemException e) {
            LOG.error("Unable to get FileObject [{}] with system manager!", destinationFile.toString(), e);
            throw new RuntimeException("Unable to get FileObject [" + destinationFile.toString() + "] with system manager!", e);
        }

        // FileObject of /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
        FileObject containerDestinationFileObject;
        try {
            containerDestinationFileObject = fileSystemManager.resolveFile(destinationUri);
        } catch (FileSystemException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", destinationUri);
            throw new RuntimeException("Unable to resolve file [" + destinationUri + "] with system manager!", e);
        }

        try {
            if (containerDestinationFileObject.exists()) {
                // TODO: check if the container are the same
                LOG.info("Container already provided [{}]", destinationUri);

            } else {
                try {
                    containerDestinationFileObject.copyFrom(containerSourceFileObject, Selectors.SELECT_ALL);
                } catch (FileSystemException e) {
                    LOG.error("Unable to copy file [{}] to [{}] with system manager!", containerUri, destinationUri);
                    throw new RuntimeException("Unable to copy file [" + containerUri + "] to [" + destinationUri + "] with system manager!", e);
                }
                // TODO: verify if the copy has been done successfully
            }
        } catch (FileSystemException e) {
            LOG.error("Unable to check file existence [{}] with system manager!", destinationUri);
            throw new RuntimeException("Unable to check file existence [" + destinationUri + "] with system manager!", e);
        } finally {
            IoCloser.ioCloser().close(containerSourceFileObject, containerDestinationFileObject);
            IoCloser.ioCloser().close(containerSourceFileObject.getFileSystem(), containerDestinationFileObject.getFileSystem());
        }

        return uri.replaceFirst(containerUri, destinationUri);
    }

    private String getContainerUri(String fileOrContainerStorageUri) {

        try {
            FileSystem fileSystem = getFileObject(fileOrContainerStorageUri).getFileSystem();

            if (fileSystem.getParentLayer() != null) {
                return fileSystem.getParentLayer().getURL().toString();
            } else {
                return fileOrContainerStorageUri;
            }
        } catch (Exception e) {
            LOG.error("Unable to parse uri [{}]!", fileOrContainerStorageUri);
            throw new RuntimeException("Unable to parse uri [" + fileOrContainerStorageUri + "]!", e);
        }
    }

    @Override
    public String removeInnerPart(String fileUriOrPath) {
        return fileUriOrPath.substring(0, fileUriOrPath.lastIndexOf('!'));
    }

    @Override
    public String localPathToStoragePath(LocalWorkingDirectory workdir, String localPath) {

        if (workdir.getStorageContainer() == null) {
            LOG.error("The local working directory doesn't have the storage base set!");
            throw new RuntimeException("The local working directory doesn't have the storage base set!");

        } else if (!workdir.getLocalBase().toPath().startsWith(Paths.get(serviceLocalDirectory).toAbsolutePath())) {
            LOG.error("The local working directory [{}] does not belong to this Storage Keeper configuration [{}]!", workdir.getLocalBase().getAbsolutePath(), serviceLocalDirectory);
            throw new RuntimeException("The local working directory [" + workdir.getLocalBase().getAbsolutePath() + "] does not belong to this Storage Keeper configuration [" + serviceLocalDirectory + "]!");
        }

        Path relativePart = Paths.get(new File(serviceLocalDirectory).getAbsolutePath()).toAbsolutePath().relativize(Paths.get(localPath));
        Path translatedPath = new File(serviceStorageDirectory, relativePart.toString()).toPath();

        return translatedPath.toFile().getAbsolutePath();
    }

    @Override
    public String localFileToStorageUri(LocalWorkingDirectory workdir, File localFile) {

        if (!localFile.getAbsolutePath().startsWith(workdir.output().getAbsolutePath())) {
            LOG.error("file path [{}] does not belong to the output folder of local working directory [{}]", localFile.getAbsolutePath(), workdir.getLocalBase().getAbsolutePath());
            throw new RuntimeException("file path [" + localFile.getAbsolutePath() + "] does not belong to the output folder of local working directory [" + workdir.getLocalBase().getAbsolutePath() + "]");
        }

        String filename = workdir.output().toPath().relativize(localFile.toPath()).toString();

        try {
            String containerName = fileSystemManager.resolveFile(workdir.getStorageContainer().getAbsolutePath()).toString();
            return "zip:" + containerName + "!/" + filename;
        } catch (FileSystemException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", workdir.getStorageContainer().getAbsolutePath());
            throw new RuntimeException("Unable to resolve file [" + workdir.getStorageContainer().getAbsolutePath() + "] with system manager!", e);
        }
    }

    public void close(FileObject fileObject) {
        fileSystemManager.closeFileSystem(fileObject.getFileSystem());
    }

    @Override
    public void close(String uri) {
        fileSystemManager.closeFileSystem(getFileObject(uri).getFileSystem());
    }

    public UuidGeneratorService getUuidGeneratorService() {
        return uuidGeneratorService;
    }

    public void setUuidGeneratorService(UuidGeneratorService uuidGeneratorService) {
        this.uuidGeneratorService = uuidGeneratorService;
    }

    public DateTimeFormatter getDateTimeFormatter() {
        return dateTimeFormatter;
    }

    public void setDateTimeFormatter(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
    }

    private void testIfDirectoryIsWritableAndReadable(String directoryAsString, boolean requireRead, boolean requireWrite) {

        Path dir = Paths.get(directoryAsString);

        Validate.isTrue(Files.isDirectory(dir), "The folder [%s] must be a directory", directoryAsString);

        if (requireRead) {
            Validate.isTrue(Files.isReadable(dir), "The folder [%s] must exist and be readable", directoryAsString);
        }
        if (requireWrite) {
            Validate.isTrue(Files.isWritable(dir), "The folder [%s] must exist and be writable", directoryAsString);
        }

    }

    private void testIfDirectoryAllowWrite(Path directory) throws IOException {
        //Use UUID to no impact all test which use the frozen generator
        //Contention is unlikely to happen
        String touchFilename = "writable_test_" + UUID.randomUUID().toString();
        Path touchFile = directory.resolve(touchFilename);
        Files.write(touchFile, FILECONTENT);
        byte[] actual = Files.readAllBytes(touchFile);
        if (!Arrays.equals(FILECONTENT, actual)) {
            LOG.error("File contents are not equals expect [{}], get [{}]", FILECONTENT, actual);
            throw new StorageFolderCreationException("File contents are not equals");
        }
        Files.delete(touchFile);
    }
}
