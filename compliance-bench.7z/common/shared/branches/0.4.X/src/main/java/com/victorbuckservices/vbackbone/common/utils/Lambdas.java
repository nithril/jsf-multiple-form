package com.victorbuckservices.vbackbone.common.utils;

import org.apache.commons.lang3.tuple.Pair;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Created on 02/19/2015
 *
 * @author labrot
 */
public class Lambdas {

    public static <T, R> Function<T, R> quietFunction(Function<T, R> function, R fallback) {
        return (T m) -> {
            try {
                return function.apply(m);
            } catch (Exception e) {
                return fallback;
            }
        };
    }

    public static Pair<Object,Throwable> get(Future future){
        Object result = null;
        Throwable exception = null;
        try {
            result = future.get();
        } catch (InterruptedException e) {
            exception = e;
        } catch (ExecutionException e) {
            exception = e.getCause();
        }
        return Pair.of(result , exception);
    }

    public static <T,R> R withReturn(T t, Function<T,R> f){
        return f.apply(t);
    }

    public static <T> void with(T t, Consumer<T> f){
        f.accept(t);
    }


}
