package com.victorbuckservices.vbackbone.common.integration.message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.ZonedDateTime;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Factory methods for {@link MessageEnvelopeHeader}
 *
 * @author Nicolas Labrot
 *         Created on 11/12/2014.
 */
public final class MessageEnvelopeHeaders {

    private static final Logger LOG = LoggerFactory.getLogger(MessageEnvelopeHeaders.class);
    private static final String CURRENT_INSTANCE_HOSTNAME = getCurrentInstanceHostName();
    private static final int CURRENT_INSTANCE_ID = ThreadLocalRandom.current().nextInt();

    private MessageEnvelopeHeaders() {
    }


    /**
     * Factory method used to create a {@link MessageEnvelopeHeader.Builder} with pre-filled technical properties.
     */
    public static MessageEnvelopeHeader.Builder newMessageEnvelopeHeaderBuilder() {
        return MessageEnvelopeHeader.newBuilder()
                .instant(ZonedDateTime.now().toInstant())
                .sourceHostname(CURRENT_INSTANCE_HOSTNAME)
                .sourceServiceInstanceId(CURRENT_INSTANCE_ID);
    }


    /**
     * Factory method used to create a {@link MessageEnvelopeHeader.Builder} with pre-filled technical properties and
     * with a copy of the given header context properties.
     */
    public static MessageEnvelopeHeader.Builder newMessageEnvelopeHeaderBuilder(MessageEnvelopeHeader headerWithContextPropertiesToCopy) {
        return newMessageEnvelopeHeaderBuilder()
                .contextProperties(headerWithContextPropertiesToCopy.getContextProperties());
    }

    /**
     * Factory method used to create a {@link MessageEnvelopeHeader} with pre-filled technical properties.
     */
    public static MessageEnvelopeHeader newMessageEnvelopeHeader() {
        return newMessageEnvelopeHeaderBuilder().build();
    }

    /**
     * Factory method used to create a {@link MessageEnvelopeHeader} with pre-filled technical properties and
     * with a copy of the given header context properties.
     */
    public static MessageEnvelopeHeader newMessageEnvelopeHeader(MessageEnvelopeHeader headerWithContextPropertiesToCopy) {
        return newMessageEnvelopeHeaderBuilder(headerWithContextPropertiesToCopy).build();
    }


    /**
     * @return Hostname of the current machine.
     */
    public static String getCurrentInstanceHostName() {
        try {
            return InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            LOG.error("Unable to get the current service instance hostname.", e);
        }
        return "unknown";
    }

}
