package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.common.integration.message.RawMessageEnvelope;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Contain the common {@link VbbMimeType}s.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public enum CommonVbbMimeType implements VbbMimeType {

    //TODO: correct the sonar
    ENVELOPE("application/vnd.vbs.vbackbone.envelope-1.0+json;charset=UTF-8;v=1.0", "1.0", RawMessageEnvelope.class),

    EMPTY("application/vnd.vbs.common.empty-1.0;v=1.0", "1.0", Void.class),
    UNKNOWN("application/vnd.vbs.common.unknown-1.0;v=1.0", "1.0", Void.class);

    private final String name;
    private final String version;
    private final Class<?> contentClass;

    private CommonVbbMimeType(String name, String version, Class<?> contentClass) {
        this.name = name;
        this.version = version;
        this.contentClass = contentClass;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public Class<?> getContentClass() {
        return contentClass;
    }
}
