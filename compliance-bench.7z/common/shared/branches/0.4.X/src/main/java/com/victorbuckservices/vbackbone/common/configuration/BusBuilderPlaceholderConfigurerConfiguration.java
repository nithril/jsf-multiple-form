package com.victorbuckservices.vbackbone.common.configuration;

import org.springframework.beans.factory.config.YamlProcessor;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.util.Properties;

/**
 *
 * This configuration creates a Spring placeholder from all the bus builder YAML files available on the classpath.
 * The resource resolver scans classpath for YAML configuation with the following expressions {@link #RESOURCES_LOCATION}.
 *
 * Thereby, queue and exchange names become available through placeholder resolution.
 *
 * Created on 02/23/2015
 *
 * @author labrot
 */
@Configuration
public class BusBuilderPlaceholderConfigurerConfiguration implements ResourceLoaderAware {

    public static final String BEAN_BUS_CONFIGURATION = "busConfiguration";
    public static final String RESOURCES_LOCATION = "classpath*:/bus/configuration/**/*-latest.yaml";

    private ResourceLoader resourceLoader;


    @Bean(name = BEAN_BUS_CONFIGURATION)
    public Properties busConfiguration() throws IOException {
        PathMatchingResourcePatternResolver resourcesResolver = new PathMatchingResourcePatternResolver(resourceLoader);
        YamlPropertiesFactoryBean factoryBean = new YamlPropertiesFactoryBean();
        factoryBean.setResources(resourcesResolver.getResources(RESOURCES_LOCATION));
        factoryBean.setResolutionMethod(YamlProcessor.ResolutionMethod.OVERRIDE);
        return factoryBean.getObject();
    }

    @Bean
    public PropertySourcesPlaceholderConfigurer busConfigurationPropertySourcesPlaceholderConfigurer() throws IOException {
        PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
        configurer.setProperties(busConfiguration());
        return configurer;
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }
}
