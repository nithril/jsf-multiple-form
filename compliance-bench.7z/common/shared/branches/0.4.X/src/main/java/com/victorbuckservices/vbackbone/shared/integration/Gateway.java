package com.victorbuckservices.vbackbone.shared.integration;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import org.springframework.messaging.MessageChannel;

import java.io.IOException;
import java.util.List;

/**
 * All Vbackbone services must define a {@link Gateway} in order to standardize the way to send messages in RabbitMQ.
 * For example the "Data Manager" service must create a DataManagerInputGateway. Vgate will thus use the
 * DataManagerInputGateway to send a message to the input queue of the "Data Manager".
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public interface Gateway {
    /**
     * @return Spring Integration {@link MessageChannel} used to send message in a specific channel.
     */
    MessageChannel getMessageChannel();

    /**
     * @return {@link Service}s the {@link Gateway} belongs to.
     */
    List<Service> getOwnerServices();

    /**
     * Send a message with a specific routing key
     * Used for replyTo response
     *
     * @param routingKey
     * @param header
     * @param body
     * @return
     * @throws IOException
     */
    boolean sendMessage(String routingKey, MessageEnvelopeHeader header, Object body) throws IOException;

    /**
     * Convert and send a message.
     *
     * @return true if the message was successfully sent, false if not.
     */
    boolean sendMessage(MessageEnvelopeHeader header, Object body) throws IOException;

    /**
     * Same as {@link #sendMessage(MessageEnvelopeHeader, Object)} but doesn't throw any exception.
     */
    boolean sendMessageQuietly(MessageEnvelopeHeader header, Object body);

}
