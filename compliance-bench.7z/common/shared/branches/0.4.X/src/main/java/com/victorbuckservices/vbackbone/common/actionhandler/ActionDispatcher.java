package com.victorbuckservices.vbackbone.common.actionhandler;

import static com.nurkiewicz.typeof.TypeOf.whenTypeOf;
import static java.util.Collections.synchronizedList;
import static java.util.concurrent.TimeUnit.MINUTES;

import com.rabbitmq.client.Channel;
import com.victorbuckservices.vbackbone.common.actionhandler.exception.InvocationException;
import com.victorbuckservices.vbackbone.common.actionhandler.handler.Handler;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PostInvocationListener;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PreInvocationListener;
import com.victorbuckservices.vbackbone.common.integration.CommonHeaderContextPropertyName;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.common.logging.LoggingHelper;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import com.victorbuckservices.vbackbone.common.utils.Lambdas;
import com.victorbuckservices.vbackbone.process.logger.ProcessLogger;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

/**
 * Created by nlabrot on 30/11/14.
 */
@Service
public class ActionDispatcher {

    private static final Logger LOG = LoggerFactory.getLogger(ActionDispatcher.class);

    @Autowired
    private CommonConversionService commonConversionService;

    @Autowired
    private ActionHandlerDirectories actionHandlerDirectories;

    @Autowired
    private LoggingHelper loggingHelper;


    private final List<PreInvocationListener<? super Object>> preInvocationListeners = synchronizedList(new ArrayList<>());

    private final List<PostInvocationListener<? super Object>> postInvocationListeners = synchronizedList(new ArrayList<>());


    private long threshold = MINUTES.toMillis(10);

    private boolean requeueMessageIfNoActionFound = false;


    public void dispatch(Message<?> message) {
        String messageInstanceId = UUID.randomUUID().toString();
        Channel channel = message.getHeaders().get(AmqpHeaders.CHANNEL, Channel.class);
        Long deliveryTag = message.getHeaders().get(AmqpHeaders.DELIVERY_TAG, Long.class);
        String messageId = message.getHeaders().get(AmqpHeaders.MESSAGE_ID, String.class);
        Boolean redelivered = message.getHeaders().get(AmqpHeaders.REDELIVERED, Boolean.class);

        boolean manualAck = channel != null;

        RabbitAction rabbitAction = RabbitAction.NACK_AND_REQUEUE;


        AtomicReference<GenericMessageEnvelope<?>> genericMessageEnvelopeReference = new AtomicReference<>();

        try {
            try {
                genericMessageEnvelopeReference.set(commonConversionService.parseMessageEnvelopeHeaderAndBody(message.getHeaders(), (byte[]) message.getPayload()));

                // Fill the MDC
                fillMdc(genericMessageEnvelopeReference.get());
                // Start Event
                ProcessLogger.startProcess(genericMessageEnvelopeReference.get().getHeader().getAction());


                LOG.debug("Dispatch request [{}]", loggingHelper.lazyToString(genericMessageEnvelopeReference.get().getHeader(), genericMessageEnvelopeReference.get().getBody(), null));

                // Search for handler
                Optional<Handler> handler = actionHandlerDirectories.findFirst(genericMessageEnvelopeReference.get());

                if (handler.isPresent()) {
                    // Invoke the handler
                    CompletableFuture<?> futureResult = invokeHandler(genericMessageEnvelopeReference.get(), handler.get());

                    if (futureResult.isDone() || !manualAck) {
                        // If the result is already available it can be returned synchronously
                        // Must retrieve the result if the ack mode is not MANUAL
                        Pair<Object, Throwable> pair = Lambdas.get(futureResult);
                        rabbitAction = handleResult(genericMessageEnvelopeReference.get(), pair.getLeft(), pair.getRight());
                    } else {
                        // The result is not yet available
                        // Add a result processing completion stage
                        futureResult.whenCompleteAsync((result, e) -> {
                            RabbitAction asyncRabbitAction = handleResult(genericMessageEnvelopeReference.get(), result, e);
                            handleReturn(channel, deliveryTag, manualAck, asyncRabbitAction);
                        });
                        rabbitAction = RabbitAction.FUTURE;
                    }


                } else {
                    LOG.error("No action mapping found for the message [{}], message requeued [{}]", loggingHelper.lazyToString(genericMessageEnvelopeReference.get().getHeader(), genericMessageEnvelopeReference.get().getBody(), null), requeueMessageIfNoActionFound);
                    if (requeueMessageIfNoActionFound) {
                        rabbitAction = RabbitAction.NACK_AND_REQUEUE;
                    } else {
                        rabbitAction = RabbitAction.NACK_AND_DEQUEUE;
                    }

                    ProcessLogger.endProcessWithError(genericMessageEnvelopeReference.get().getHeader().getAction());
                }
            } catch (IOException e) {
                LOG.error("An error occures when processing the message [{}], message requeued", loggingHelper.lazyToString(message.getHeaders(), e), e);
                rabbitAction = RabbitAction.NACK_AND_REQUEUE;
            }

            // Handle the return
            handleReturn(channel, deliveryTag, manualAck, rabbitAction);

        } finally {
            clearMdc();
        }

    }

    private void handleReturn(Channel channel, Long deliveryTag, boolean manualAck, RabbitAction rabbitAction) {
        switch (rabbitAction) {
            case FUTURE:
                break;
            case ACK:
                if (manualAck) {
                    ack(channel, deliveryTag);
                }
                break;
            case NACK_AND_DEQUEUE:
                if (manualAck) {
                    nackAndDequeue(channel, deliveryTag);
                } else {
                    throw new AmqpRejectAndDontRequeueException("Nack and dequeue");
                }
                break;
            case NACK_AND_REQUEUE:
            default:
                if (manualAck) {
                    //nackAndRequeue(channel, deliveryTag);
                    nackAndDequeue(channel, deliveryTag);
                } else {
                    throw new RuntimeException("Nack and requeue");
                }
                break;
        }
    }

    private RabbitAction handleResult(GenericMessageEnvelope<?> messageEnvelope, Object result, Throwable exception) {
        RabbitAction rabbitAction;
        if (exception == null) {
            rabbitAction = RabbitAction.ACK;
            doPostInvocations(messageEnvelope, result);

            ProcessLogger.endProcess(messageEnvelope.getHeader().getAction());
        } else {
            rabbitAction = whenTypeOf(exception).is(InvocationException.class).thenReturn(e -> {
                if (e.isNack()) {
                    if (e.isRequeue()) {
                        return RabbitAction.NACK_AND_REQUEUE;
                    } else {
                        return RabbitAction.NACK_AND_DEQUEUE;
                    }
                } else {
                    return RabbitAction.ACK;
                }
            }).orElse(RabbitAction.NACK_AND_DEQUEUE);
            LOG.error("An error occures when processing the message [{}], message requeued [{}]", loggingHelper.lazyToString(messageEnvelope.getHeader(), messageEnvelope.getBody(), null), rabbitAction);

            ProcessLogger.endProcessWithError(messageEnvelope.getHeader().getAction());
        }

        return rabbitAction;
    }

    private CompletableFuture invokeHandler(GenericMessageEnvelope<?> messageEnvelope, Handler handler) {
        CompletableFuture completableFuture = null;
        try {
            doPreInvocations(messageEnvelope);
            Object result = handler.invoke(messageEnvelope);
            if (result instanceof CompletableFuture) {
                // We finally got a future and an asynchronous service!
                completableFuture = (CompletableFuture) result;
            } else {
                // No future, Bootstrap it
                completableFuture = CompletableFuture.completedFuture(result);
            }
        } catch (Throwable e) {
            // Create a future and completes it exceptionally
            completableFuture = new CompletableFuture();
            completableFuture.completeExceptionally(e);
        }
        return completableFuture;
    }

    private void doPreInvocations(GenericMessageEnvelope<?> messageEnvelope) {
        for (PreInvocationListener preInvocationListener : preInvocationListeners) {
            boolean invoke = !(preInvocationListener instanceof Predicate) || ((Predicate) preInvocationListener).test(messageEnvelope);
            if (invoke) {
                preInvocationListener.apply(messageEnvelope);
            }
        }
    }

    private void doPostInvocations(GenericMessageEnvelope genericMessageEnvelope, Object result) {
        for (PostInvocationListener<? super Object> postInvocationListener : postInvocationListeners) {
            try {
                boolean invoke = !(postInvocationListener instanceof Predicate) || ((Predicate) postInvocationListener).test(result);
                if (invoke) {
                    postInvocationListener.apply(genericMessageEnvelope, result);
                }
            } catch (Exception e) {
                LOG.error("Error invoking post invocation listener [{}]", postInvocationListener, e);
            }
        }
    }

    public ActionDispatcher addPreInvocationListener(PreInvocationListener listener) {
        preInvocationListeners.add(listener);
        return this;
    }

    public ActionDispatcher addPostInvocationListener(PostInvocationListener listener) {
        postInvocationListeners.add(listener);
        return this;
    }


    private void ack(Channel channel, Long deliveryTag) {
        try {
            channel.basicAck(deliveryTag, false);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void nackAndRequeue(Channel channel, Long deliveryTag) {
        nack(channel, deliveryTag, true);
    }

    private void nackAndDequeue(Channel channel, Long deliveryTag) {
        nack(channel, deliveryTag, false);
    }

    private void nack(Channel channel, Long deliveryTag, boolean requeue) {
        try {
            channel.basicNack(deliveryTag, false, requeue);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    public long getThreshold() {
        return threshold;
    }

    public void setThreshold(long threshold) {
        this.threshold = threshold;
    }

    public ActionHandlerDirectories getActionHandlerDirectories() {
        return actionHandlerDirectories;
    }

    public void setActionHandlerDirectories(ActionHandlerDirectories actionHandlerDirectories) {
        this.actionHandlerDirectories = actionHandlerDirectories;
    }

    private void fillMdc(GenericMessageEnvelope<?> genericMessageEnvelope) {
        Map<String, Object> contextProperties = genericMessageEnvelope.getHeader().getContextProperties();
        Object companyCode = contextProperties.get(CommonHeaderContextPropertyName.COMPANY_CODE);
        if (companyCode != null){
            MDC.put(CommonHeaderContextPropertyName.COMPANY_CODE, String.valueOf(companyCode));
        }
        Object processUrn = contextProperties.get(CommonHeaderContextPropertyName.PROCESS_URN);
        if (processUrn != null){
            MDC.put(CommonHeaderContextPropertyName.PROCESS_URN , String.valueOf(processUrn));
        }
    }

    private void clearMdc() {
        MDC.remove(CommonHeaderContextPropertyName.COMPANY_CODE);
        MDC.remove(CommonHeaderContextPropertyName.PROCESS_URN);
    }

    private enum RabbitAction {
        ACK,
        NACK_AND_DEQUEUE,
        NACK_AND_REQUEUE,
        FUTURE
    }

}
