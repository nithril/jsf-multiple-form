package com.victorbuckservices.vbackbone.common.actionhandler.listener.replyto;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;

/**
 * Created on 02/23/2015
 *
 * @author labrot
 */
public class ReplyToResponse<T> {

    public static final ReplyToResponse<Void> NONE = new ReplyToResponse<>(null, null);

    private final MessageEnvelopeHeader messageEnvelopeHeader;
    private final T body;

    public ReplyToResponse(MessageEnvelopeHeader messageEnvelopeHeader, T body) {
        this.messageEnvelopeHeader = messageEnvelopeHeader;
        this.body = body;
    }

    public MessageEnvelopeHeader getMessageEnvelopeHeader() {
        return messageEnvelopeHeader;
    }

    public T getBody() {
        return body;
    }
}
