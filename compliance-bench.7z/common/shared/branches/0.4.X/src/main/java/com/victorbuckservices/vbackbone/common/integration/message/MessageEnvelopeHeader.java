package com.victorbuckservices.vbackbone.common.integration.message;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.common.definition.CommonVbbMimeType;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

import java.time.Instant;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Contain all the standard Vbackbone header properties.
 *
 * @author Marc Plouhinec
 *         Created on 11/12/2014.
 */
public class MessageEnvelopeHeader {

    private String messageId;

    private String replyTo;

    private Instant instant;
    private String sourceHostname;
    private int sourceServiceInstanceId;

    // Business header properties
    private Service sourceService;
    private Action action;
    private VbbMimeType contentType;
    private Status status;
    private ReportLevel statusLevel;

    // Optional context header properties
    private Map<String, Object> contextProperties = Collections.emptyMap();

    public MessageEnvelopeHeader() {
    }

    private MessageEnvelopeHeader(Builder builder) {
        setMessageId(builder.messageId);
        setReplyTo(builder.replyTo);
        setInstant(builder.instant);
        setSourceHostname(builder.sourceHostname);
        setSourceServiceInstanceId(builder.sourceServiceInstanceId);
        if (builder.sourceService != null) {
            setSourceService(builder.sourceService);
        }
        if (builder.action != null) {
            setAction(builder.action);
        }
        if (builder.contentType != null) {
            setContentType(builder.contentType);
        }
        setStatus(builder.status);
        setStatusLevel(builder.statusLevel);
        if (builder.contextProperties != null) {
            setContextProperties(builder.contextProperties);
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static Builder newBuilder(MessageEnvelopeHeader copy) {
        Builder builder = new Builder();
        builder.messageId = copy.messageId;
        builder.replyTo = copy.replyTo;
        builder.instant = copy.instant;
        builder.sourceHostname = copy.sourceHostname;
        builder.sourceServiceInstanceId = copy.sourceServiceInstanceId;
        builder.sourceService = copy.sourceService;
        builder.action = copy.action;
        builder.contentType = copy.contentType;
        builder.status = copy.status;
        builder.statusLevel = copy.statusLevel;
        builder.contextProperties = copy.contextProperties;
        return builder;
    }


    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    /**
     * Getter for property 'instant'.
     *
     * @return Value for property 'instant'.
     */
    public Instant getInstant() {
        return instant;
    }

    /**
     * Setter for property 'instant'.
     *
     * @param instant Value to set for property 'instant'.
     */
    public void setInstant(Instant instant) {
        this.instant = instant;
    }

    /**
     * Getter for property 'sourceHostname'.
     *
     * @return Value for property 'sourceHostname'.
     */
    public String getSourceHostname() {
        return sourceHostname;
    }

    /**
     * Setter for property 'sourceHostname'.
     *
     * @param sourceHostname Value to set for property 'sourceHostname'.
     */
    public void setSourceHostname(String sourceHostname) {
        this.sourceHostname = sourceHostname;
    }

    /**
     * Getter for property 'sourceServiceInstanceId'.
     *
     * @return Value for property 'sourceServiceInstanceId'.
     */
    public int getSourceServiceInstanceId() {
        return sourceServiceInstanceId;
    }

    /**
     * Setter for property 'sourceServiceInstanceId'.
     *
     * @param sourceServiceInstanceId Value to set for property 'sourceServiceInstanceId'.
     */
    public void setSourceServiceInstanceId(int sourceServiceInstanceId) {
        this.sourceServiceInstanceId = sourceServiceInstanceId;
    }

    /**
     * Getter for property 'sourceService'.
     *
     * @return Value for property 'sourceService'.
     */
    public Service getSourceService() {
        return sourceService;
    }

    /**
     * Setter for property 'sourceService'.
     *
     * @param sourceService Value to set for property 'sourceService'.
     */
    public void setSourceService(Service sourceService) {
        this.sourceService = sourceService;
    }

    /**
     * Getter for property 'action'.
     *
     * @return Value for property 'action'.
     */
    public Action getAction() {
        return action;
    }

    /**
     * Setter for property 'action'.
     *
     * @param action Value to set for property 'action'.
     */
    public void setAction(Action action) {
        this.action = action;
        if (this.sourceService == null) {
            this.sourceService = action.getService();
        }
        if (this.contentType == null) {
            List<VbbMimeType> contentTypes = action.getContentTypes();
            this.contentType = contentTypes == null || contentTypes.isEmpty() ? CommonVbbMimeType.EMPTY : contentTypes.get(0);
        }
    }

    /**
     * Getter for property 'contentType'.
     *
     * @return Value for property 'contentType'.
     */
    public VbbMimeType getContentType() {
        return contentType;
    }

    /**
     * Setter for property 'contentType'.
     *
     * @param contentType Value to set for property 'contentType'.
     */
    public void setContentType(VbbMimeType contentType) {
        this.contentType = contentType;
    }

    /**
     * Getter for property 'status'.
     *
     * @return Value for property 'status'.
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Setter for property 'status'.
     *
     * @param status Value to set for property 'status'.
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Getter for property 'statusLevel'.
     *
     * @return Value for property 'statusLevel'.
     */
    public ReportLevel getStatusLevel() {
        return statusLevel;
    }

    /**
     * Setter for property 'statusLevel'.
     *
     * @param statusLevel Value to set for property 'statusLevel'.
     */
    public void setStatusLevel(ReportLevel statusLevel) {
        this.statusLevel = statusLevel;
    }

    /**
     * Return a mutable context properties map
     *
     * @return
     */
    public Map<String, Object> getContextProperties() {
        return contextProperties;
    }

    /**
     * Create a new context properties map and copy the content of the provided one
     *
     * @return
     */
    public void setContextProperties(Map<String, Object> contextProperties) {
        this.contextProperties = new HashMap<>(contextProperties);
    }

    public String getReplyTo() {
        return replyTo;
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = replyTo;
    }

    @Override
    public String toString() {
        return "MessageEnvelopeHeader{" +
                "instant=" + instant +
                ", sourceHostname='" + sourceHostname + '\'' +
                ", sourceServiceInstanceId=" + sourceServiceInstanceId +
                ", sourceService=" + sourceService +
                ", action=" + action +
                ", contentType=" + contentType +
                ", status=" + status +
                ", statusLevel=" + statusLevel +
                '}';
    }


    public static final class Builder {
        private String messageId;
        private String replyTo;
        private Instant instant;
        private String sourceHostname;
        private int sourceServiceInstanceId;
        private Service sourceService;
        private Action action;
        private VbbMimeType contentType;
        private Status status;
        private ReportLevel statusLevel;
        private Map<String, Object> contextProperties;

        private Builder() {
        }

        public Builder messageId(String messageId) {
            this.messageId = messageId;
            return this;
        }

        public Builder replyTo(String replyTo) {
            this.replyTo = replyTo;
            return this;
        }

        public Builder instant(Instant instant) {
            this.instant = instant;
            return this;
        }

        public Builder sourceHostname(String sourceHostname) {
            this.sourceHostname = sourceHostname;
            return this;
        }

        public Builder sourceServiceInstanceId(int sourceServiceInstanceId) {
            this.sourceServiceInstanceId = sourceServiceInstanceId;
            return this;
        }

        public Builder sourceService(Service sourceService) {
            this.sourceService = sourceService;
            return this;
        }

        public Builder action(Action action) {
            this.action = action;
            return this;
        }

        public Builder contentType(VbbMimeType contentType) {
            this.contentType = contentType;
            return this;
        }

        public Builder status(Status status) {
            this.status = status;
            return this;
        }

        public Builder statusLevel(ReportLevel statusLevel) {
            this.statusLevel = statusLevel;
            return this;
        }

        public Builder contextProperties(Map<String, Object> contextProperties) {
            this.contextProperties = contextProperties;
            return this;
        }

        public MessageEnvelopeHeader build() {
            return new MessageEnvelopeHeader(this);
        }
    }
}
