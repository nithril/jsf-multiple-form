package com.victorbuckservices.vbackbone.common.actionhandler.listener.replyto;

import com.victorbuckservices.vbackbone.common.actionhandler.exception.UnexpectedException;
import com.victorbuckservices.vbackbone.common.actionhandler.listener.PostInvocationListener;
import com.victorbuckservices.vbackbone.common.configuration.RabbitReplyToConfiguration;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.IOException;
import java.util.function.Predicate;

/**
 * Created on 02/24/2015
 *
 * @author labrot
 */
public class ReplyToListener implements PostInvocationListener<ReplyToResponse>, Predicate<Object>, BeanNameAware {

    private static final Logger LOG = LoggerFactory.getLogger(ReplyToListener.class);

    @Autowired
    @Qualifier(RabbitReplyToConfiguration.BEAN_REPLYTO_OUTBOUND_ADAPTER)
    private Gateway amqpReplyToOutboundAdapter;

    private String beanName;


    @Override
    public void apply(GenericMessageEnvelope requestMessageEnvelope, ReplyToResponse replyToResponse) {

        try {
            if (replyToResponse != ReplyToResponse.NONE){
                amqpReplyToOutboundAdapter.sendMessage(requestMessageEnvelope.getHeader().getReplyTo(), replyToResponse.getMessageEnvelopeHeader(), replyToResponse.getBody());
            }
        } catch (IOException e) {
            LOG.error(e.getMessage() , e);
            throw new UnexpectedException(e.getMessage() , e);
        }
    }

    @Override
    public boolean test(Object o) {
        return o instanceof ReplyToResponse;
    }

    @Override
    public void setBeanName(String name) {
        this.beanName = name;
    }

    @Override
    public String toString() {
        return "ReplyToListener{" +
                "beanName='" + beanName + '\'' +
                '}';
    }
}
