package com.victorbuckservices.vbackbone.common.uuid.locality;

import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import net.logstash.logback.encoder.org.apache.commons.lang.Validate;
import org.apache.commons.exec.OS;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import javax.annotation.PostConstruct;

/**
 * Locality aware {@link UuidGeneratorService}.
 * <p/>
 */
public class LocalityUuidGeneratorService implements UuidGeneratorService {

    private static final Logger LOG = LoggerFactory.getLogger(LocalityUuidGeneratorService.class);

    public static final int PID = processId();
    public static final byte UUID_VERSION = 0xa;

    private static final char[] HEX =
            {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    private static final int MAX_PID = 65536;
    private static final AtomicLong COUNTER = new AtomicLong(new SecureRandom().nextLong());

    @Autowired
    private Environment environment;

    @Value("${uuid.discriminant.value:-1}")
    private Integer uuidDiscriminant;

    @Value("${uuid.discriminant.path:}")
    private String uuidDiscriminantPath;

    @Value("${service.discriminant}")
    private Integer serviceDiscriminant;


    private byte[] versionAndDiscriminant = new byte[3];

    @PostConstruct
    public void initVersionAndDiscriminant() {
        try {

            Validate.notNull(serviceDiscriminant, "service.discriminant must be provided");

            if (serviceDiscriminant == 0 || serviceDiscriminant > 255){
                throw new IllegalStateException("Service discriminant is equals to 0 or gte 2^8");
            }

            if (StringUtils.isNotBlank(uuidDiscriminantPath)) {
                uuidDiscriminant = Integer.valueOf(FileUtils.readFileToString(new File(uuidDiscriminantPath)).trim());
            } else if (uuidDiscriminant == null || uuidDiscriminant == -1) {
                throw new IllegalStateException("Uuid discriminant value or path is not set");
            }

            if ((uuidDiscriminant >> 20) != 0) {
                throw new IllegalStateException("Discriminant value is gte 2^20");
            }

            boolean localUuid = (uuidDiscriminant >> 14) == 0;

            if (localUuid) {
                for (int i = 0; i < 20; i++) {
                    LOG.error("You are using an UUID associated to a local environment. If you are on your desktop or on jenkins this error can be ignored");
                }
            }

            if (!OS.isFamilyWindows() && localUuid && environment.acceptsProfiles("production")) {
                throw new IllegalStateException("You are using an UUID associated to a local environment with a production profile on a non windows OS, this configuration is erroneous");
            }
            if (!OS.isFamilyWindows() && localUuid && (environment.getActiveProfiles() == null || Arrays.stream(environment.getActiveProfiles()).filter(s -> s.contains("test")).count() == 0)) {
                throw new IllegalStateException("You are using an UUID associated to a local environment with a production profile on a non windows OS, this configuration is erroneous");
            }


            versionAndDiscriminant[0] = (byte) ((UUID_VERSION << 4) | (uuidDiscriminant >> 16));
            versionAndDiscriminant[1] = (byte) (uuidDiscriminant >> 8);
            versionAndDiscriminant[2] = uuidDiscriminant.byteValue();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new IllegalStateException("Unable to initialize the uuid discriminant", e);
        }
    }


    @Override
    public String generateUuid() {
        byte[] uuid = generateUuid(System.currentTimeMillis(), COUNTER.incrementAndGet());
        return toString(uuid);
    }


    public Integer getUuidDiscriminant() {
        return uuidDiscriminant;
    }

    public void setUuidDiscriminant(Integer uuidDiscriminant) {
        this.uuidDiscriminant = uuidDiscriminant;
    }

    public String getUuidDiscriminantPath() {
        return uuidDiscriminantPath;
    }

    public void setUuidDiscriminantPath(String uuidDiscriminantPath) {
        this.uuidDiscriminantPath = uuidDiscriminantPath;
    }

    public Integer getServiceDiscriminant() {
        return serviceDiscriminant;
    }

    public void setServiceDiscriminant(Integer serviceDiscriminant) {
        this.serviceDiscriminant = serviceDiscriminant;
    }

    /**
     * NLA: Retrieve from https://github.com/groupon/locality-uuid.java
     * <p/>
     * Get the process id of this JVM. I haven't tested this extensively so its possible that this performs differently
     * on esoteric JVMs. I copied this from:
     * http://stackoverflow.com/questions/35842/how-can-a-java-program-get-its-own-process-id
     *
     * @return Id of the current JVM process.
     */
    private static int processId() {
        // Note: may fail in some JVM implementations
        // something like '<pid>@<hostname>', at least in SUN / Oracle JVMs
        final String jvmName = ManagementFactory.getRuntimeMXBean().getName();
        final int index = jvmName.indexOf('@');

        if (index < 1) {
            throw new RuntimeException("Could not get PID");
        }

        try {
            return Integer.parseInt(jvmName.substring(0, index)) % MAX_PID;
        } catch (NumberFormatException e) {
            throw new RuntimeException("Could not get PID");
        }
    }


    //tttttttt-tttt-bddd-ddss-ppppcccccccc
    byte[] generateUuid(long timestamp, long count) {
        byte[] uuid = new byte[32];

        //copy timestamp into content
        uuid[0] = (byte) (timestamp >> 40);
        uuid[1] = (byte) (timestamp >> 32);
        uuid[2] = (byte) (timestamp >> 24);
        uuid[3] = (byte) (timestamp >> 16);
        uuid[4] = (byte) (timestamp >> 8);
        uuid[5] = (byte) (timestamp);

        //copy version and discriminant
        uuid[6] = versionAndDiscriminant[0];
        uuid[7] = versionAndDiscriminant[1];
        uuid[8] = versionAndDiscriminant[2];

        //service discriminant
        uuid[9] = serviceDiscriminant.byteValue();

        //copy PID
        uuid[10] = (byte) (PID >> 8);
        uuid[11] = (byte) (PID);

        //get the count in order and place into content
        uuid[12] = (byte) (count >> 24);
        uuid[13] = (byte) (count >> 16);
        uuid[14] = (byte) (count >> 8);
        uuid[15] = (byte) (count);
        return uuid;
    }


    public static String toString(byte[] content) {
        char[] id = new char[36];
        // split each byte into 4 bit numbers and map to hex characters
        id[0] = HEX[(content[0] & 0xF0) >> 4];
        id[1] = HEX[(content[0] & 0x0F)];
        id[2] = HEX[(content[1] & 0xF0) >> 4];
        id[3] = HEX[(content[1] & 0x0F)];
        id[4] = HEX[(content[2] & 0xF0) >> 4];
        id[5] = HEX[(content[2] & 0x0F)];
        id[6] = HEX[(content[3] & 0xF0) >> 4];
        id[7] = HEX[(content[3] & 0x0F)];
        id[8] = '-';
        id[9] = HEX[(content[4] & 0xF0) >> 4];
        id[10] = HEX[(content[4] & 0x0F)];
        id[11] = HEX[(content[5] & 0xF0) >> 4];
        id[12] = HEX[(content[5] & 0x0F)];
        id[13] = '-';
        id[14] = HEX[(content[6] & 0xF0) >> 4];
        id[15] = HEX[(content[6] & 0x0F)];
        id[16] = HEX[(content[7] & 0xF0) >> 4];
        id[17] = HEX[(content[7] & 0x0F)];
        id[18] = '-';
        id[19] = HEX[(content[8] & 0xF0) >> 4];
        id[20] = HEX[(content[8] & 0x0F)];
        id[21] = HEX[(content[9] & 0xF0) >> 4];
        id[22] = HEX[(content[9] & 0x0F)];
        id[23] = '-';
        id[24] = HEX[(content[10] & 0xF0) >> 4];
        id[25] = HEX[(content[10] & 0x0F)];
        id[26] = HEX[(content[11] & 0xF0) >> 4];
        id[27] = HEX[(content[11] & 0x0F)];
        id[28] = HEX[(content[12] & 0xF0) >> 4];
        id[29] = HEX[(content[12] & 0x0F)];
        id[30] = HEX[(content[13] & 0xF0) >> 4];
        id[31] = HEX[(content[13] & 0x0F)];
        id[32] = HEX[(content[14] & 0xF0) >> 4];
        id[33] = HEX[(content[14] & 0x0F)];
        id[34] = HEX[(content[15] & 0xF0) >> 4];
        id[35] = HEX[(content[15] & 0x0F)];
        return new String(id);
    }

    @Override
    public Instant toInstant(String uuid) {
        // First we remove the dashes
        String uuidWithoutDashes = uuid.replace("-", "");

        String hexDate = uuidWithoutDashes.substring(0, 12);

        long millis = Long.parseLong(hexDate, 16);

        return Instant.ofEpochMilli(millis);
    }

    @Override
    public int toService(String uuid) {
        // First we remove the dashes
        String uuidWithoutDashes = uuid.replace("-", "");
        String hexService = uuidWithoutDashes.substring(18, 20);
        return Integer.parseInt(hexService, 16);
    }
}
