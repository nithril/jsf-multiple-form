package com.victorbuckservices.vbackbone.common.utils.lambda.with;


import com.victorbuckservices.vbackbone.common.utils.lambda.with.exception.UncheckedExecutionException;

import java.io.InputStream;

/**
 * Created by nlabrot on 10/03/15.
 */
public class WithResource {

    private final InputStream with;

    protected WithResource(InputStream with) {
        this.with = with;
    }

    public <R> R uncheckedApply(CheckedFunction<InputStream, R> f) throws UncheckedExecutionException {
        try (InputStream is = with) {
            return f.apply(is);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }


    public static WithResource withResource(InputStream with) {
        return new WithResource(with);
    }

    public static <R> R withResource(InputStream with, CheckedFunction<InputStream, R> f) {
        return f.apply(with);
    }
}
