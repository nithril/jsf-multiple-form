package com.victorbuckservices.vbackbone.common.service;

import static com.google.common.base.Preconditions.checkNotNull;

import com.victorbuckservices.common.utils.report.ReportLevel;
import com.victorbuckservices.vbackbone.common.definition.CommonVbbMimeType;
import com.victorbuckservices.vbackbone.common.integration.message.GenericMessageEnvelope;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.integration.message.MessageHeader;
import com.victorbuckservices.vbackbone.common.integration.message.RawMessageEnvelope;
import com.victorbuckservices.vbackbone.shared.definition.dto.Problem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Convert message contents into POJOs and vice-versa.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
@Service
public class CommonConversionService {

    private static final Logger LOG = LoggerFactory.getLogger(CommonConversionService.class);
    private static final String HEADER_CONTENT_TYPE = "contentType";
    private static final String HEADER_TIMESTAMP = "timestamp";
    private static final String HEADER_ACTION_URN = "vbb-action-urn";
    private static final String HEADER_STATUS_LEVEL = "vbb-status-level";

    @Autowired
    private ServiceDefinitionDirectoryService serviceDefinitionDirectoryService;

    @Autowired
    private ObjectMapperService mapperService;


    /**
     * Parse the given {@link MessageHeader}.
     * Note: this method is very safe, a completely invalid {@link Map} will result in a valid {@link MessageHeader}.
     */
    public MessageHeader parseMessageHeader(Map<String, Object> headerAsMap) {
        MessageHeader messageHeader = new MessageHeader();
        if (headerAsMap == null) {
            return messageHeader;
        }

        messageHeader.setMessageId(parseMessageHeaderField(headerAsMap, AmqpHeaders.MESSAGE_ID, String::valueOf));
        messageHeader.setContentType(parseMessageHeaderField(headerAsMap, HEADER_CONTENT_TYPE, value -> MimeType.valueOf(String.valueOf(value))));
        messageHeader.setTimestamp(parseMessageHeaderField(headerAsMap, HEADER_TIMESTAMP, value -> {
            if (value instanceof Number) {
                return ((Number) value).longValue();
            }
            return Long.valueOf(String.valueOf(value));
        }));
        messageHeader.setAction(parseMessageHeaderField(headerAsMap, HEADER_ACTION_URN, value -> serviceDefinitionDirectoryService.findActionByUrn(String.valueOf(value))));
        messageHeader.setStatusLevel(parseMessageHeaderField(headerAsMap, HEADER_STATUS_LEVEL, value -> {
            if (value instanceof ReportLevel) {
                return (ReportLevel) value;
            }
            return ReportLevel.valueOf(String.valueOf(value));
        }));
        messageHeader.setReplyTo(parseMessageHeaderField(headerAsMap, AmqpHeaders.REPLY_TO, String::valueOf));

        return messageHeader;
    }

    private <R> R parseMessageHeaderField(Map<String, Object> headerAsMap, String fieldName, Function<Object, R> fieldParser) {
        Object value = headerAsMap.get(fieldName);
        if (value != null) {
            try {
                return fieldParser.apply(value);
            } catch (Exception e) {
                LOG.warn("Invalid header [{}]:[{}].", fieldName, value, e);
            }
        }
        return null;
    }


    /**
     * Serialize the given {@link MessageHeader}.
     * Note: this method is very safe, a completely invalid {@link MessageHeader} will result in a valid {@link Map}.
     */
    public Map<String, Object> serializeMessageHeader(MessageHeader messageHeader) {
        Map<String, Object> headerAsMap = new LinkedHashMap<>();
        if (messageHeader == null) {
            return headerAsMap;
        }
        if (messageHeader.getMessageId() != null) {
            headerAsMap.put(AmqpHeaders.MESSAGE_ID, messageHeader.getMessageId());
        }
        if (messageHeader.getContentType() != null) {
            headerAsMap.put(HEADER_CONTENT_TYPE, messageHeader.getContentType().toString());
        }
        if (messageHeader.getTimestamp() != null) {
            headerAsMap.put(HEADER_TIMESTAMP, messageHeader.getTimestamp());
        }
        if (messageHeader.getAction() != null) {
            headerAsMap.put(HEADER_ACTION_URN, messageHeader.getAction().getUrn());
        }
        if (messageHeader.getStatusLevel() != null) {
            headerAsMap.put(HEADER_STATUS_LEVEL, messageHeader.getStatusLevel().name());
        }
        if (messageHeader.getReplyTo() != null) {
            headerAsMap.put(AmqpHeaders.REPLY_TO, messageHeader.getReplyTo());
        }
        return headerAsMap;
    }

    /**
     * Build a Spring Integration message from a {@link MessageEnvelopeHeader} and a body
     *
     * @param header
     * @param body
     * @return
     * @throws IOException
     */
    public Message buildMessage(MessageEnvelopeHeader header, Object body) throws IOException {
        // Build the message header
        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageId(header.getMessageId());
        messageHeader.setContentType(CommonVbbMimeType.ENVELOPE.toMimeType());
        messageHeader.setTimestamp(header.getInstant().getEpochSecond());
        messageHeader.setAction(header.getAction());
        messageHeader.setStatusLevel(header.getStatusLevel());
        messageHeader.setReplyTo(header.getReplyTo());
        Map<String, Object> headerAsMap = serializeMessageHeader(messageHeader);

        // Create the message payload
        byte[] serializedBody = serializeMessageEnvelopeBody(body);
        RawMessageEnvelope messageEnvelope = new RawMessageEnvelope(header, serializedBody);
        byte[] payload = serializeMessageEnvelope(messageEnvelope);

        // Send the message
        return MessageBuilder.withPayload(payload).copyHeaders(headerAsMap).build();
    }


    /**
     * Parse a MessageEnvelope given message header and message payload
     * @param header
     * @param payload
     * @return
     * @throws IOException
     */
    public GenericMessageEnvelope<?> parseMessageEnvelopeHeaderAndBody(Map<String, Object> header, byte[] payload) throws IOException {
        // Parse the message envelope
        MessageHeader messageHeader = parseMessageHeader(header);

        checkNotNull(messageHeader.getAction(), "Missing header action: [%s].", messageHeader);

        RawMessageEnvelope messageEnvelope = parseMessageEnvelope(payload);
        MessageEnvelopeHeader messageEnvelopeHeader = messageEnvelope.getHeader();

        // Parse the body
        Class<?> contentClass = messageEnvelopeHeader.getContentType().getContentClass();
        Object body = null;
        if (!Void.class.equals(contentClass)) {
            body = parseMessageEnvelopeBody(messageEnvelope.getBody(), contentClass);
        }

        return new GenericMessageEnvelope(messageEnvelopeHeader, body);
    }




    /**
     * Parse the given message envelope body.
     */
    public <T> T parseMessageEnvelopeBody(byte[] content, Class<T> bodyClass) throws IOException {
        return mapperService.jsonMapper().readValue(content, bodyClass);
    }

    /**
     * Serialize the given message envelope body.
     */
    public byte[] serializeMessageEnvelopeBody(Object body) throws IOException {
        return mapperService.jsonMapper().writeValueAsBytes(body);
    }


    /**
     * Parse the given {@link com.victorbuckservices.vbackbone.common.integration.message.RawMessageEnvelope}.
     */
    public RawMessageEnvelope parseMessageEnvelope(byte[] content) throws IOException {
        return mapperService.jsonMapper().readValue(content, RawMessageEnvelope.class);
    }

    /**
     * Serialize the given message envelope .
     */
    public byte[] serializeMessageEnvelope(RawMessageEnvelope messageEnvelope) throws IOException {
        return mapperService.jsonMapper().writeValueAsBytes(messageEnvelope);
    }

}
