package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.ConfigurableActionParameter;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Class used to parse an {@link com.victorbuckservices.vbackbone.shared.definition.Action} that is not registered in the {@link com.victorbuckservices.vbackbone.common.service.ServiceDefinitionDirectoryService}.
 * Note: this class should normally never be used.
 *
 * @author Marc Plouhinec
 *         Created on 21/10/2014.
 */
public class UnknownAction implements Action
{
    private final String urn;

    /**
     * Create a new {@link UnknownAction}.
     */
    public UnknownAction(String urn)
    {
        this.urn = urn;
    }

    @Override public String getUrn()
    {
        return urn;
    }

    @Override public String getName()
    {
        return urn;
    }

    @Override public String getVersion()
    {
        return "0";
    }

    @Override public Service getService()
    {
        return CommonService.UNKNOWN_SERVICE;
    }

    @Override public List<VbbMimeType> getContentTypes()
    {
        return Arrays.asList(CommonVbbMimeType.UNKNOWN);
    }

    @Override public List<ConfigurableActionParameter> getConfigurableActionParameters()
    {
        return Collections.emptyList();
    }
}
