package com.victorbuckservices.vbackbone.common.storagekeeper.sftp;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.victorbuckservices.vbackbone.common.storagekeeper.*;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystem;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.VFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import javax.annotation.PostConstruct;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-02-23.
 */
public class SftpStorageKeeper implements StorageKeeper {
    private static final Logger LOG = LoggerFactory.getLogger(SftpStorageKeeper.class);

    @Autowired
    protected UuidGeneratorService uuidGeneratorService;

    private FileSystemManager fileSystemManager;

    private DateTimeFormatter dateTimeFormatter;

    @Value("${storagekeeper.workDirectory}")
    private String serviceLocalDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String serviceStorageDirectory;

    @Value("${storagekeeper.sshUser}")
    private String sshUser;

    @Value("${storagekeeper.sshHost}")
    private String sshHost;

    @Value("${storagekeeper.sshPassword}")
    private String sshPassword;

    @Override
    @PostConstruct
    public void init() {
        LOG.info("StorageKeeper.init()");
        try {
            fileSystemManager = VFS.getManager();
        } catch (FileSystemException e) {
            LOG.error("Unable to get the file system manager!");
            throw new RuntimeException("Unable to get the file system manager!", e);
        }
        dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd").withZone(ZoneOffset.UTC);
    }

    @Override
    public String uuidToDate(String uuid) {
        return dateTimeFormatter.format(uuidGeneratorService.toInstant(uuid));
    }

    @Override
    public String uuidToService(String uuid) {
        return Integer.toHexString(uuidGeneratorService.toService(uuid));
    }

    @Override
    public LocalWorkingDirectory newLocalWorkingDirectoryTree() {
        throw new UnsupportedOperationException("SftpStorageKeeper.newLocalWorkingDirectoryTree()");
    }

    @Override
    public LocalWorkingDirectory newSubDirectoryTree(LocalWorkingDirectory localWorkingDirectory, String subFolder) {
        throw new UnsupportedOperationException("SftpStorageKeeper.newSubDirectoryTree()");
    }

    @Override
    public String commitLocalOutput(LocalWorkingDirectory localWorkingDirectory) {
        throw new UnsupportedOperationException("SftpStorageKeeper.commitLocalOutput()");
    }

    private String getTrunkUri() throws FileSystemException {
        return VFS.getManager().toFileObject(new File(".")).toString() + "/";
    }

    @Override
    public FileObject getFileObject(String uri) {
        // uri:                 zip:file:///mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip!/file.xml
        // storageContainerUri:     file:///mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip
        // localContainerUri:       file:///local/storage/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip
        // localUri             zip:file:///local/storage/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip!/file.xml
        // sourcePath                      /mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip

        String storageContainerUri;
        String localContainerUri;
        String localUri = null;
        String sourcePath;
        try {
            storageContainerUri = removeInnerPart(uri).replaceFirst("zip:", "");
            localContainerUri = storageContainerUri.replaceFirst("file:///mnt/vbackbone", getTrunkUri() + serviceStorageDirectory);
            localUri = uri.replaceFirst("file:///mnt/vbackbone", getTrunkUri() + serviceStorageDirectory);
            sourcePath = storageContainerUri.replaceFirst("file://", "");

            FileObject localContainerFileObject = fileSystemManager.resolveFile(localContainerUri);

            if (!localContainerFileObject.exists()) {
                JSch jsch = new JSch();
                Session session = null;
                ChannelSftp sftpChannel = null;
                InputStream inputStream = null;
                OutputStream outputStream = null;
                try {
                    session = jsch.getSession(sshUser, sshHost);
                    session.setPassword(sshPassword);
                    session.setConfig("StrictHostKeyChecking", "no");
                    session.connect();
                    sftpChannel = (ChannelSftp) session.openChannel("sftp");
                    sftpChannel.connect();

                    inputStream = new BufferedInputStream(sftpChannel.get(sourcePath));

                    localContainerFileObject.createFile();

                    FileContent localContainerFileObjectContent = localContainerFileObject.getContent();

                    outputStream = new BufferedOutputStream(localContainerFileObjectContent.getOutputStream());

                    IOUtils.copy(inputStream, outputStream);

                    localContainerFileObjectContent.close();

                } catch (JSchException | SftpException e) {
                    LOG.error("Unable to get a SSH session to [{}] @ [{}] in order to get an InputStream to [{}]!", sshUser, sshHost, sourcePath, e);
                    throw new IOException("Unable to get a SSH session to '" + sshUser + "@" + sshHost + "' in order to get an InputStream to '" + sourcePath + "'.", e);
                } finally {
                    IOUtils.closeQuietly(inputStream);
                    IOUtils.closeQuietly(outputStream);
                    if (sftpChannel != null)
                        sftpChannel.disconnect();
                    if (session != null)
                        session.disconnect();
                }
            }
            FileObject fileObject = fileSystemManager.resolveFile(localUri);
            return fileObject;
        } catch (IOException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", localUri, e);
            throw new RuntimeException("Unable to resolve file [" + localUri + "] with system manager!", e);
        }
    }

    @Override
    public FileContent getFileContent(String uri) {
        FileObject fileObject = getFileObject(uri);
        FileContent fileContent = null;
        try {
            fileContent = fileObject.getContent();
        } catch (FileSystemException e) {
            LOG.error("Unable to get content of file [{}] with system manager!", uri);
            throw new RuntimeException("Unable to get content of file [" + uri + "] with system manager!", e);
        }
        return fileContent;
    }

    @Override
    public InputStream getInputStream(String uri) {
        try {
            return StorageKeeperUtils.newInputStream(getFileObject(uri));
        } catch (FileSystemException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public CloseableResource getResource(String uri) {
        return new FileObjectResource(fileSystemManager, getFileObject(uri));
    }

    @Override
    public String getStorageUri(String uuid, String resourcePath) {
        throw new UnsupportedOperationException("SftpStorageKeeper.provideLocalWith()");
    }


    @Override
    public String getServiceLocalDirectory() {
        return serviceLocalDirectory;
    }

    @Override
    public String getServiceStorageDirectory() {
        return serviceStorageDirectory;
    }

    @Override
    public String provideLocalWith(LocalWorkingDirectory lwd, String uri) {
        throw new UnsupportedOperationException("SftpStorageKeeper.provideLocalWith()");
    }

    private String getContainerUri(String fileOrContainerStorageUri) {

        try {
            FileSystem fileSystem = getFileObject(fileOrContainerStorageUri).getFileSystem();

            if (fileSystem.getParentLayer() != null) {
                return fileSystem.getParentLayer().getURL().toString();
            } else {
                return fileOrContainerStorageUri;
            }
        } catch (Exception e) {
            LOG.error("Unable to parse uri [{}]!", fileOrContainerStorageUri);
            throw new RuntimeException("Unable to parse uri [" + fileOrContainerStorageUri + "]!", e);
        }
    }

    @Override
    public String removeInnerPart(String fileUriOrPath) {
        return fileUriOrPath.substring(0, fileUriOrPath.lastIndexOf('!'));
    }

    @Override
    public String localPathToStoragePath(LocalWorkingDirectory workdir, String localPath) {

        if (workdir.getStorageContainer() == null) {
            LOG.error("The local working directory doesn't have the storage base set!");
            throw new RuntimeException("The local working directory doesn't have the storage base set!");

        } else if (!workdir.getLocalBase().toPath().startsWith(Paths.get(serviceLocalDirectory).toAbsolutePath())) {
            LOG.error("The local working directory [{}] does not belong to this Storage Keeper configuration [{}]!", workdir.getLocalBase().getAbsolutePath(), serviceLocalDirectory);
            throw new RuntimeException("The local working directory [" + workdir.getLocalBase().getAbsolutePath() + "] does not belong to this Storage Keeper configuration [" + serviceLocalDirectory + "]!");
        }

        Path relativePart = Paths.get(new File(serviceLocalDirectory).getAbsolutePath()).toAbsolutePath().relativize(Paths.get(localPath));
        Path translatedPath = new File(serviceStorageDirectory, relativePart.toString()).toPath();

        return translatedPath.toFile().getAbsolutePath();
    }

    @Override
    public String localFileToStorageUri(LocalWorkingDirectory workdir, File localFile) {
        if (fileSystemManager == null) {
            try {
                fileSystemManager = VFS.getManager();
            } catch (FileSystemException e) {
                LOG.error("Unable to get the file system manager!");
                throw new RuntimeException("Unable to get the file system manager!", e);
            }
        }

        if (!localFile.getAbsolutePath().startsWith(workdir.output().getAbsolutePath())) {
            LOG.error("file path [{}] does not belong to the output folder of local working directory [{}]", localFile.getAbsolutePath(), workdir.getLocalBase().getAbsolutePath());
            throw new RuntimeException("file path [" + localFile.getAbsolutePath() + "] does not belong to the output folder of local working directory [" + workdir.getLocalBase().getAbsolutePath() + "]");
        }
        String filename = workdir.output().toPath().relativize(localFile.toPath()).toString();
        String containerName;
        try {
            containerName = fileSystemManager.resolveFile(workdir.getStorageContainer().getAbsolutePath()).toString();
        } catch (FileSystemException e) {
            LOG.error("Unable to resolve file [{}] with system manager!", workdir.getStorageContainer().getAbsolutePath());
            throw new RuntimeException("Unable to resolve file [" + workdir.getStorageContainer().getAbsolutePath() + "] with system manager!", e);
        }

        return "zip:" + containerName + "!/" + filename;
    }


    public void close(FileObject fileObject) {
        fileSystemManager.closeFileSystem(fileObject.getFileSystem());
    }

    @Override
    public void close(String uri) {
        fileSystemManager.closeFileSystem(getFileObject(uri).getFileSystem());
    }


    public void setSshUser(String sshUser) {
        this.sshUser = sshUser;
    }

    public void setSshHost(String sshHost) {
        this.sshHost = sshHost;
    }

    public void setSshPassword(String sshPassword) {
        this.sshPassword = sshPassword;
    }
}
