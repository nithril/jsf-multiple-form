package com.victorbuckservices.vbackbone.common.definition;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.ConfigurableActionParameter;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

/**
 * Common {@link Action}s.
 *
 * @author Marc Plouhinec
 *         Created on 11/13/2014.
 */
public enum CommonAction implements Action {
    UNKNOWN_ACTION(
            "urn:vbs:action:vbackbone:common:unknown:1.0",
            "Unknown action",
            "When a message header contains an unknown action, the JSON deserializer instantiate an UnknownAction with an unknown action. " +
                    "The goal is to allow a service like Vgate or the Dashboard to be able to process a message even if it doesn't know a " +
                    "particular action.",
            "1.0",
            CommonService.UNKNOWN_SERVICE,
            Arrays.<VbbMimeType>asList(CommonVbbMimeType.UNKNOWN),
            Collections.<ConfigurableActionParameter>emptyList(),
            Collections.<Status>emptyList()
    );

    private final String urn;
    private final String name;
    private final String description;
    private final String version;
    private final Service service;
    private final List<VbbMimeType> contentTypes;
    private final List<ConfigurableActionParameter> configurableActionParameters;
    private final List<Status> statuses;

    CommonAction(String urn, String name, String description, String version, Service service, List<VbbMimeType> contentTypes,
                         List<ConfigurableActionParameter> configurableActionParameters, List<Status> statuses) {
        this.urn = urn;
        this.name = name;
        this.description = description;
        this.version = version;
        this.service = service;
        this.contentTypes = contentTypes;
        this.configurableActionParameters = configurableActionParameters;
        this.statuses = statuses;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public Service getService() {
        return service;
    }

    @Override
    public List<VbbMimeType> getContentTypes() {
        return contentTypes;
    }

    @Override
    public List<ConfigurableActionParameter> getConfigurableActionParameters() {
        return configurableActionParameters;
    }

    @Override
    public List<Status> getStatuses() {
        return statuses;
    }
}
