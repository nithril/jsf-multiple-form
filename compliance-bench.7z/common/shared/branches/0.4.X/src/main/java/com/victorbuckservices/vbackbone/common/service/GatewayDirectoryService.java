package com.victorbuckservices.vbackbone.common.service;

import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;

import java.util.Collection;
import java.util.List;

/**
 * Directory for {@link Gateway}s.
 *
 * @author Marc Plouhinec
 * Created on 11/21/2014.
 */
public interface GatewayDirectoryService
{
    /**
     * @return {@link Gateway} related to the {@link Service}.
     */
    Collection<Gateway> findAllGatewaysByService(Service service);

    /**
     * @return All registered {@link Gateway}s.
     */
    List<Gateway> findAllGateways();
}
