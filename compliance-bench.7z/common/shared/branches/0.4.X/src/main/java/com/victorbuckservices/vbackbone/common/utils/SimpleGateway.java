package com.victorbuckservices.vbackbone.common.utils;

import java.util.List;

import com.victorbuckservices.vbackbone.common.integration.AbstractGateway;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import org.springframework.messaging.MessageChannel;

/**
 * Generic gateway for sending messages in a configurable channel.
 *
 * @author chaffangeon
 * Created on 12/12/2014
 */
public class SimpleGateway extends AbstractGateway
{
    private MessageChannel messageChannel;
    private List<Service> ownerServices;

    @Override
    public MessageChannel getMessageChannel()
    {
        return messageChannel;
    }

    @Override
    public List<Service> getOwnerServices()
    {
        return ownerServices;
    }

    /**
     * Setter for property 'messageChannel'.
     *
     * @param messageChannel Value to set for property 'messageChannel'.
     */
    public void setMessageChannel(final MessageChannel messageChannel)
    {
        this.messageChannel = messageChannel;
    }

    /**
     * Setter for property 'ownerServices'.
     *
     * @param ownerServices Value to set for property 'ownerServices'.
     */
    public void setOwnerServices(final List<Service> ownerServices)
    {
        this.ownerServices = ownerServices;
    }
}
