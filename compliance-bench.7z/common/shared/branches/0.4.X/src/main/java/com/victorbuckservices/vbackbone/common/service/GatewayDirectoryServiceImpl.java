package com.victorbuckservices.vbackbone.common.service;

import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.integration.Gateway;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;

/**
 * Deprecated, a gateway directory could not be created as a RPC server service will only maintain the input
 * Output will be known per request and set in the replyTo header
 *
 * Default implementation of {@link GatewayDirectoryService}.
 *
 * @author Marc Plouhinec
 *         Created on 11/21/2014.
 */
@org.springframework.stereotype.Service
@Deprecated
public class GatewayDirectoryServiceImpl implements GatewayDirectoryService {

    @Autowired(required = false)
    private List<Gateway> gateways = Collections.emptyList();

    private Map<Service, Collection<Gateway>> gatewayByTypeByService = Collections.emptyMap();

    /**
     * Create an index of {@link Gateway}.
     */
    @PostConstruct
    public void indexGateways() {
        // Group the gateways by service
        gatewayByTypeByService = new ConcurrentHashMap<>(
                gateways.stream()
                .flatMap(gateway -> gateway.getOwnerServices().stream()
                        .map(service -> new AbstractMap.SimpleImmutableEntry<>(service, gateway)))
                        .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.mapping(Map.Entry::getValue, Collectors.toCollection(ConcurrentLinkedQueue::new)))));

    }

    @Override
    public Collection<Gateway> findAllGatewaysByService(Service service) {
        return Collections.unmodifiableCollection(gatewayByTypeByService.getOrDefault(service, Collections.emptyList()));
    }

    @Override
    public List<Gateway> findAllGateways() {
        return Collections.unmodifiableList(gateways);
    }
}
