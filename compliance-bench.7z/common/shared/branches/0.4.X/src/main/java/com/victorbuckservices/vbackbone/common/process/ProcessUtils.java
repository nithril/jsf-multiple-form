package com.victorbuckservices.vbackbone.common.process;

import static java.util.Objects.requireNonNull;

import org.apache.commons.lang.Validate;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * Created on 06/22/2015
 *
 * @author labrot
 */
public class ProcessUtils {

    public static String buildProcessChain(Object... ids) {
        Validate.notEmpty(ids);
        return Arrays.stream(ids)
                .map(id -> requireNonNull(id).toString())
                .collect(Collectors.joining(":"));
    }

}
