package com.victorbuckservices.vbackbone.common.definition;

import com.victorbuckservices.vbackbone.shared.definition.Service;

/**
 * Common {@link Service}s.
 *
 * @author Marc Plouhinec
 *         Created on 28/10/2014.
 */
public enum CommonService implements Service {
    UNKNOWN_SERVICE("urn:vbs:service:vbackbone:unknown:1.0", "Unknown", "1.0");

    private final String urn;
    private final String name;
    private final String version;

    CommonService(String urn, String name, String version) {
        this.urn = urn;
        this.name = name;
        this.version = version;
    }

    @Override
    public String getUrn() {
        return this.urn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getVersion() {
        return version;
    }
}
