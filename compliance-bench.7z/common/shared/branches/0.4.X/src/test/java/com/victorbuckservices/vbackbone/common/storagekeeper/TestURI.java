package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.google.common.net.UrlEscapers;
import com.victorbuckservices.vbackbone.common.AbstractTest;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-26.
 */
public class TestURI extends AbstractTest {
    private static final Logger LOG = LoggerFactory.getLogger(TestURI.class);

    private String inputUri = "file:///usr/local/jenkins/workspace/Vbackbone - Common - Shared - Tests/target/test-classes/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip";
    private String expectedUri = "file:///usr/local/jenkins/workspace/Vbackbone%20-%20Common%20-%20Shared%20-%20Tests/target/test-classes/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip";

    @Test
    public void testReplaceAll() {

        String uriToParse = inputUri.replaceAll(" ", "%20");

        URI haveUri = null;
        try {
            haveUri = new URI(uriToParse);
        } catch (URISyntaxException e) {
            LOG.error("Unable to parse uri [{}]!", uriToParse);
            throw new RuntimeException("Unable to parse uri [" + uriToParse + "]!", e);
        }

        Assert.assertEquals("Expected output", expectedUri, haveUri.toString());
    }

    @Test
    public void testGuavaUrlEscapers(){
        String haveUri = UrlEscapers.urlFragmentEscaper().escape(inputUri);
        Assert.assertEquals("Expected output", expectedUri, haveUri.toString());
    }

}
