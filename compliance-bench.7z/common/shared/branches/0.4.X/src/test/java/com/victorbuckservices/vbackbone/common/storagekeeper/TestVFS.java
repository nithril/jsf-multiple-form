package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.VFS;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-12.
 */
public class TestVFS extends AbstractTest {

    @Value("${storagekeeper.workDirectory}")
    private String storageKeeperWorkDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String storageKeeperStorageDirectory;

    @Value("storagekeeper/simplefolder")
    private Resource simpleFolder;

    @Test
    public void testVFSCreateFromSimpleFolder() throws IOException {
        System.out.println("---------------------------------------------------------------------------------");
        File folderToVirtualize = simpleFolder.getFile();
        File containerFile = new File(storageKeeperWorkDirectory, "testVFSCreateFromSimpleFolder/test.zip");

        // returns the default Commons VFS implementation
        FileSystemManager fileSystemManager = VFS.getManager();


        FileObject container = fileSystemManager.resolveFile(containerFile.getAbsolutePath());
        container.createFile();

        ZipOutputStream zos = new ZipOutputStream(container.getContent().getOutputStream());

        Files.list(folderToVirtualize.toPath()).forEach(
                file -> {
                    String filename = file.toFile().getName();
                    System.out.println(filename);
                    ZipEntry zipEntry = new ZipEntry(filename);

                    FileObject entryFile = null;
                    try {
                        entryFile = fileSystemManager.resolveFile(file.toFile().getAbsolutePath());
                    } catch (FileSystemException e) {
                        e.printStackTrace();
                    }
                    InputStream is = null;
                    try {
                        is = entryFile.getContent().getInputStream();
                    } catch (FileSystemException e) {
                        e.printStackTrace();
                    }
                    try {
                        zos.putNextEntry(zipEntry);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    byte[] buf = new byte[1024];
                    try {
                        for (int readNum; (readNum = is.read(buf)) != -1; ) {
                            try {
                                zos.write(buf, 0, readNum);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        zos.close();

        System.out.println("---------------------------------------------------------------------------------");

        // Check if zip contains all the files that are in simpleFolder


        // Check

        Files.list(folderToVirtualize.toPath()).forEach(
                file -> {
                    File expectedFile = file.toFile();
                    String filename = file.toFile().getName();
                    String fileToResolve = "zip:file://" + containerFile.getAbsolutePath() + "!" + filename;
                    FileObject zipFile = null;
                    try {
                        zipFile = fileSystemManager.resolveFile(fileToResolve);
                    } catch (FileSystemException e) {
                        e.printStackTrace();
                    }
                    try {
                        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(new FileInputStream(expectedFile), zipFile.getContent().getInputStream()));
                    } catch (FileSystemException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
    }
}
