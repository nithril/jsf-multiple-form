package com.victorbuckservices.vbackbone.common.uuid.locality;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.context.ActiveProfiles;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created on 03/24/2015
 *
 * @author labrot
 */
@ActiveProfiles("test")
public class UuidLocalityTest {

    @Test
    public void testUuid() throws Exception {


        ThreadLocalRandom random = ThreadLocalRandom.current();

        for (long i = 0; i < 1000000; i++) {

            int env = random.nextInt(1, 1 << 6);
            int vm = random.nextInt(0, 1 << 14);
            int service = random.nextInt(1, 1 << 8);
            long counter = random.nextLong(1, 1l << 32);
            long timestamp = random.nextLong(1, 1l << 48);

            LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();
            localityUuidGeneratorService.setUuidDiscriminant((env << 14) + vm);
            localityUuidGeneratorService.setServiceDiscriminant(service);
            localityUuidGeneratorService.initVersionAndDiscriminant();

            byte[] uuid = localityUuidGeneratorService.generateUuid(timestamp, counter);

            LocalityUuid localityUuid = new LocalityUuid(uuid);

            Assert.assertEquals(env, localityUuid.getEnvDiscriminant());
            Assert.assertEquals(vm, localityUuid.getVmDiscriminant());
            Assert.assertEquals(service, localityUuid.getServiceDiscriminant());

            Assert.assertEquals(timestamp, localityUuid.getTimestamp());
            Assert.assertEquals(counter, localityUuid.getCounter());
        }
    }

    @Test
    public void generateTest() {
        LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();
        localityUuidGeneratorService.setUuidDiscriminant(0b110101_10110011000100);
        localityUuidGeneratorService.setServiceDiscriminant(200);
        localityUuidGeneratorService.initVersionAndDiscriminant();

        long currentTime = System.currentTimeMillis();
        //AtomicLong counter = new AtomicLong(Math.abs(ThreadLocalRandom.current().nextLong(1l << 40)));
        //AtomicLong counter = new AtomicLong(1l<<39);

        System.out.println("PID: " + LocalityUuidGeneratorService.PID);
        System.out.println("Env discriminant: " + 0b110101);
        System.out.println("VM discrmininant: " + 0b10110011000100);
        System.out.println("Service discrmininant: " + 200);

        long counter = ThreadLocalRandom.current().nextLong(1l << 20);

        String previousUuid = "";

        for (int i = 0; i < 100; i++) {

            byte[] uuid = localityUuidGeneratorService.generateUuid(currentTime, counter);

            LocalityUuid localityUuid = new LocalityUuid(uuid);

            Assert.assertEquals(currentTime, localityUuid.getTimestamp());
            Assert.assertEquals(counter, localityUuid.getCounter());
            Assert.assertEquals(0b110101, localityUuid.getEnvDiscriminant());
            Assert.assertEquals(0b10110011000100, localityUuid.getVmDiscriminant());
            Assert.assertEquals(200, localityUuid.getServiceDiscriminant());
            Assert.assertEquals(LocalityUuidGeneratorService.UUID_VERSION, localityUuid.getVersion());
            Assert.assertEquals(LocalityUuidGeneratorService.PID, localityUuid.getPid());
            Assert.assertTrue(previousUuid.compareTo(localityUuidGeneratorService.toString(uuid)) < 0);

            System.out.println("CurrentTime:[" + currentTime + "] Counter:[" + counter + "] UUID:[" + localityUuidGeneratorService.toString(uuid) + "]");

            //counter.incrementAndGet();

            currentTime += 123456789l;
            counter += 12345678l;
        }
    }

    @Test
    public void testSetAndGetDateFromUUID() {
        long currentTime = System.currentTimeMillis();
        long counter = ThreadLocalRandom.current().nextLong(1l << 39);
        LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();
        localityUuidGeneratorService.setUuidDiscriminant(0b110101_10110011000100);
        localityUuidGeneratorService.setServiceDiscriminant(200);
        localityUuidGeneratorService.initVersionAndDiscriminant();
        byte[] uuid = localityUuidGeneratorService.generateUuid(currentTime, counter);
        LocalityUuid localityUuid = new LocalityUuid(uuid);
        Assert.assertEquals(currentTime, localityUuid.getTimestamp());
        Assert.assertEquals(200, localityUuid.getServiceDiscriminant());
    }

    @Test
    public void testGetDateFromUUID() {
        String inputUUID = "014cbc90-573d-a040-006f-5f35ac64007b";
        String expectedDate = "2015/04/15";
        LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();
        Instant uuidInstant = localityUuidGeneratorService.toInstant(inputUUID);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd").withZone(ZoneOffset.UTC);
        String haveDate = formatter.format(uuidInstant);

        Assert.assertEquals("Date comparison", expectedDate, haveDate);
    }

    @Test
    public void testGetServiceFromUUID() {
        String inputUUID = "014cbc90-573d-a040-006f-5f35ac64007b";
        int expectedService = 0x6f;
        LocalityUuidGeneratorService localityUuidGeneratorService = new LocalityUuidGeneratorService();
        int haveService = localityUuidGeneratorService.toService(inputUUID);

        Assert.assertEquals("Service comparison", expectedService, haveService);
    }
}
