package com.victorbuckservices.vbackbone.common.context;

import com.victorbuckservices.vbackbone.common.CommonSharedConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by labrot on 10/14/2014.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {CommonSharedConfiguration.class}, locations = {"classpath:/spring/spring.xml"})
@EnableConfigurationProperties
@ActiveProfiles()
public class LoadSpringContextTest {

    @Test
    public void test() {
    }
}
