package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.CommonSharedConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.StorageKeeperConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.UuidGeneratorConfiguration;
import com.victorbuckservices.vbackbone.common.storagekeeper.sftp.SftpStorageKeeper;
import com.victorbuckservices.vbackbone.common.testcontext.TestContextConfiguration;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.io.InputStream;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-04.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                UuidGeneratorConfiguration.class,
                CommonSharedConfiguration.class,
                TestContextConfiguration.class,
                StorageKeeperConfiguration.class
        },
        locations = {"classpath:/spring/spring.xml"}
)
@EnableConfigurationProperties
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator",
        "test-with-sftpstoragekeeper"
})
public class TestSftpStorageKeeper {
    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    private SftpStorageKeeper storageKeeper;

    @Value("storagekeeper/simplefolder/inputBundles.xml")
    private Resource xmlExpected;

    @Test
    @Ignore
    public void test() throws IOException {
        String fileUri = "zip:file:///mnt/vbackbone/vbackbone-composition/test/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";

        InputStream inputStream = storageKeeper.getInputStream(fileUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
    }

}
