package com.victorbuckservices.vbackbone.common.testcontext;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

/**
 * Created on 02/06/2015
 *
 * @author labrot
 */
@Configuration
@ComponentScan({
        "com.victorbuckservices.vbackbone.common.testcontext",
        "com.victorbuckservices.vbackbone.common.storagekeeper"
})
@ContextConfiguration(locations = {"classpath:/spring/spring.xml"})
public class TestContextConfiguration {

}
