package com.victorbuckservices.vbackbone.common;

import com.victorbuckservices.vbackbone.common.configuration.StorageKeeperConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.UuidGeneratorConfiguration;
import com.victorbuckservices.vbackbone.common.testcontext.TestContextConfiguration;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                UuidGeneratorConfiguration.class,
                CommonSharedConfiguration.class,
                TestContextConfiguration.class,
                StorageKeeperConfiguration.class
        },
        locations = {"classpath:/spring/spring.xml"}
)
@EnableConfigurationProperties
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator"
})
public abstract class AbstractTest {

    @BeforeClass
    public static void createDirectory() throws Exception {
        Files.createDirectories(Paths.get("target/storagekeeper/work"));
        Files.createDirectories(Paths.get("target/storagekeeper/storage"));
    }
}
