package com.victorbuckservices.vbackbone.common.testcontext.definition;

import com.victorbuckservices.vbackbone.common.definition.CommonService;
import com.victorbuckservices.vbackbone.common.definition.CommonVbbMimeType;
import com.victorbuckservices.vbackbone.shared.definition.Action;
import com.victorbuckservices.vbackbone.shared.definition.ConfigurableActionParameter;
import com.victorbuckservices.vbackbone.shared.definition.Service;
import com.victorbuckservices.vbackbone.shared.definition.Status;
import com.victorbuckservices.vbackbone.shared.definition.VbbMimeType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
public enum CommonActionForTest implements Action {
    FOO_ACTION(
            Constants.ACTION_MAPPING,
            "Unknown action",
            "When a message header contains an unknown action, the JSON deserializer instantiate an UnknownAction with an unknown action. " +
                    "The goal is to allow a service like Vgate or the Dashboard to be able to process a message even if it doesn't know a " +
                    "particular action.",
            "1.0",
            CommonService.UNKNOWN_SERVICE,
            Arrays.<VbbMimeType>asList(CommonVbbMimeType.UNKNOWN),
            Collections.<ConfigurableActionParameter>emptyList(),
            Collections.<Status>emptyList()
    ), OVERRIDED_ACTION_MAPPING(
            Constants.OVERRIDED_ACTION_MAPPING,
            "Unknown action",
            "When a message header contains an unknown action, the JSON deserializer instantiate an UnknownAction with an unknown action. " +
                    "The goal is to allow a service like Vgate or the Dashboard to be able to process a message even if it doesn't know a " +
                    "particular action.",
            "1.0",
            CommonService.UNKNOWN_SERVICE,
            Arrays.<VbbMimeType>asList(CommonVbbMimeType.UNKNOWN),
            Collections.<ConfigurableActionParameter>emptyList(),
            Collections.<Status>emptyList()
    );


    /**
     * Holds the urn as constants
     */
    public static class Constants {
        public static final String ACTION_MAPPING = "urn:vbs:action:vbackbone:common:test:actionmapping:1.0";
        public static final String OVERRIDED_ACTION_MAPPING = "urn:vbs:action:vbackbone:common:test:overridedactionmapping:1.0";
    }


    private final String urn;
    private final String name;
    private final String description;
    private final String version;
    private final Service service;
    private final List<VbbMimeType> contentTypes;
    private final List<ConfigurableActionParameter> configurableActionParameters;
    private final List<Status> statuses;

    private CommonActionForTest(String urn, String name, String description, String version, Service service, List<VbbMimeType> contentTypes,
                                List<ConfigurableActionParameter> configurableActionParameters, List<Status> statuses) {
        this.urn = urn;
        this.name = name;
        this.description = description;
        this.version = version;
        this.service = service;
        this.contentTypes = contentTypes;
        this.configurableActionParameters = configurableActionParameters;
        this.statuses = statuses;
    }

    @Override
    public String getUrn() {
        return urn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public Service getService() {
        return service;
    }

    @Override
    public List<VbbMimeType> getContentTypes() {
        return contentTypes;
    }

    @Override
    public List<ConfigurableActionParameter> getConfigurableActionParameters() {
        return configurableActionParameters;
    }

    @Override
    public List<Status> getStatuses() {
        return statuses;
    }
}
