package com.victorbuckservices.vbackbone.common.actionhandler;

import static com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest.Constants.ACTION_MAPPING;
import static com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest.Constants.OVERRIDED_ACTION_MAPPING;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.common.actionhandler.actionmapping.handler.ActionMappingHandler;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeaders;
import com.victorbuckservices.vbackbone.common.service.CommonConversionService;
import com.victorbuckservices.vbackbone.common.testcontext.ActionWithUrnFooService;
import com.victorbuckservices.vbackbone.common.testcontext.definition.CommonActionForTest;
import com.victorbuckservices.vbackbone.common.testcontext.definition.CommonVbbMimeTypeForTest;
import com.victorbuckservices.vbackbone.common.testcontext.dto.GenericFoo;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
public class ActionDispatcherTest extends AbstractTest {

    @Autowired
    private ActionHandlerDirectories actionInterceptorDirectories;

    @Autowired
    private ActionDispatcher actionDispatcher;

    @Autowired
    private CommonConversionService commonConversionService;


    @Autowired
    private ActionWithUrnFooService actionWithUrnFooService;

    @Test
    public void testMappingDirectory() {
        List<ActionMappingHandler> actionMappingInterceptorList = actionInterceptorDirectories.getHandlers().stream()
                .filter(ActionMappingHandler.class::isInstance)
                .map(ActionMappingHandler.class::cast)
                .collect(Collectors.toList());

        Assert.assertEquals(2, actionMappingInterceptorList.size());
        Assert.assertEquals(ACTION_MAPPING, actionMappingInterceptorList.get(0).getActionDefinition().getActionUrn());
        Assert.assertEquals(actionWithUrnFooService, actionMappingInterceptorList.get(0).getActionDefinition().getBean());
        Assert.assertEquals("actionWithUrnFoo", actionMappingInterceptorList.get(0).getActionDefinition().getMethod().getName());


        Assert.assertEquals(OVERRIDED_ACTION_MAPPING, actionMappingInterceptorList.get(1).getActionDefinition().getActionUrn());
        Assert.assertEquals(actionWithUrnFooService, actionMappingInterceptorList.get(1).getActionDefinition().getBean());
        Assert.assertEquals("overridedActionWithUrnFoo", actionMappingInterceptorList.get(1).getActionDefinition().getMethod().getName());

    }

    @Test
    public void testActionDispatcher() throws IOException {
        MessageEnvelopeHeader messageEnvelopeHeader = MessageEnvelopeHeaders.newMessageEnvelopeHeader();
        messageEnvelopeHeader.setAction(CommonActionForTest.FOO_ACTION);
        messageEnvelopeHeader.setContentType(CommonVbbMimeTypeForTest.FOO);

        Message message = commonConversionService.buildMessage(messageEnvelopeHeader , new GenericFoo(1));

        actionWithUrnFooService.reset();
        actionDispatcher.dispatch(message);
        Assert.assertEquals(1 , actionWithUrnFooService.getActionWithUrnFooCounter());
    }


    @Test
    public void testOverridedActionDispatcher() throws IOException {
        MessageEnvelopeHeader messageEnvelopeHeader = MessageEnvelopeHeaders.newMessageEnvelopeHeader();
        messageEnvelopeHeader.setAction(CommonActionForTest.OVERRIDED_ACTION_MAPPING);
        messageEnvelopeHeader.setContentType(CommonVbbMimeTypeForTest.FOO);

        Message message = commonConversionService.buildMessage(messageEnvelopeHeader , new GenericFoo(1));

        actionWithUrnFooService.reset();
        actionDispatcher.dispatch(message);
        Assert.assertEquals(1 , actionWithUrnFooService.getOverridedActionWithUrnFooCounter());
    }


}
