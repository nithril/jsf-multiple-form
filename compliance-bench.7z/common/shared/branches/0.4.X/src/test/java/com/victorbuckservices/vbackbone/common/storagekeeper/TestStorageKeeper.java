package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.common.storagekeeper.nfs.NfsStorageKeeper;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.VFS;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-03-18.
 */
public class TestStorageKeeper extends AbstractTest {

    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    private NfsStorageKeeper storageKeeper;

    @Value("${storagekeeper.workDirectory}")
    private String storageKeeperWorkDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String storageKeeperStorageDirectory;

    @Value("storagekeeper/simplefolder/inputBundles.xml")
    private Resource xmlExpected;

    @Value("storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip")
    private Resource containerInput;

    private void cleanTestFolders(String uuid) {
        String date = storageKeeper.uuidToDate(uuid);
        String service = storageKeeper.uuidToService(uuid);

        File localDir = new File(new File(new File(storageKeeperWorkDirectory, date), service), uuid);
        if (localDir.exists()) {
            try {
                FileUtils.forceDelete(localDir);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete directroy [" + localDir + "]", e);
            }
        }

        File storageContainer = new File(new File(new File(storageKeeperStorageDirectory, date), service), uuid + ".zip");
        if (storageContainer.exists()) {
            try {
                FileUtils.forceDelete(storageContainer);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete container [" + storageContainer + "]", e);
            }
        }
    }

    private String getTrunkUri() throws FileSystemException {
        return VFS.getManager().toFileObject(new File(".")).toString() + "/";
    }

    @Test
    public void testLocalPathToStoragePath() {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "39ad8b1a-0b8b-4f80-a57c-06eb59d82281",
                "39ad8b1a-0b8b-4f80-a57c-06eb59d82281"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        // Note: 39ad8b1a-0b8b-4f80-a57c-06eb59d82281 gives the date 3979-08-16
        String expectedOutputPath = new File(storageKeeperStorageDirectory, "3979/08/16/0x7c/39ad8b1a-0b8b-4f80-a57c-06eb59d82281/output/toto.txt").getAbsolutePath();

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        String someFilePathInSomeLocalFolder = new File(workingDirectory.output(), "toto.txt").getAbsolutePath();

        String someFileTranslated = storageKeeper.localPathToStoragePath(workingDirectory, someFilePathInSomeLocalFolder);

        System.out.println("Input:    " + someFilePathInSomeLocalFolder);
        System.out.println("Have:     " + someFileTranslated);
        System.out.println("Expected: " + expectedOutputPath);

        Assert.assertArrayEquals("Expected output", expectedOutputPath.getBytes(), someFileTranslated.getBytes());
    }

    @Test
    public void testProvide() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9d",
                "d07fd44b-9c4b-4824-a969-8f2612629a9d"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9d/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml";
        // ex: zip:file:///D:/Project/composition-service/service/src/test/resources/8099/10/01/0x69/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml
        String startingUri = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("expectedResult.xml").toString();

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        String uri = storageKeeper.provideLocalWith(workingDirectory, startingUri);

        Assert.assertEquals(expectedUri, uri);
    }

    @Test
    public void testDoubleProvide() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9e",
                "d07fd44b-9c4b-4824-a969-8f2612629a9e"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9e/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml";
        String expectedUri2 = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9e/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";


        String startingUri = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("expectedResult.xml").toString();
        String startingUri2 = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("inputBundles.xml").toString();

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        String uri = storageKeeper.provideLocalWith(workingDirectory, startingUri);
        String uri2 = storageKeeper.provideLocalWith(workingDirectory, startingUri2);
        Assert.assertEquals(expectedUri, uri);
        Assert.assertEquals(expectedUri2, uri2);
    }

    @Test
    public void testCommit() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9f",
                "d07fd44b-9c4b-4824-a969-8f2612629a9f"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        File outputFolder = workingDirectory.output();

        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        String container = storageKeeper.commitLocalOutput(workingDirectory);

        File targetFile = new File(workingDirectory.output(), "inputBundles.xml");

        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);

        InputStream inputStream = storageKeeper.getInputStream(resultingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
    }

    @Test
    @Ignore
    public void testInputStream() throws IOException {

        String startingUri = VFS.getManager().resolveFile(new File("./src/test/resources/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip"), "!/inputBundles.xml").getURL().toString();


        //String startingUri = "zip:file:///D:/Project/composition-service/service/src/test/resources/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";

        InputStream inputStream = storageKeeper.getInputStream(startingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
    }

    @Test
    public void testLocalFileToStorageUriTranslation() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                "d07fd44b-9c4b-4824-a969-8f2612629a9f",
                "d07fd44b-9c4b-4824-a969-8f2612629a9f"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/storage/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9f.zip!/inputBundles.xml";

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        File sourceFile = xmlExpected.getFile();
        File targetFile = new File(workingDirectory.output(), sourceFile.getName());
        Files.copy(sourceFile.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);
        Assert.assertEquals(expectedUri, resultingUri);
    }
}

