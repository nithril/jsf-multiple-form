package com.victorbuckservices.vbackbone.common.busbuilder;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.rabbit.management.client.domain.queue.Queue;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created on 08/12/2015
 *
 * @author labrot
 */
public class BusBuilderConfigurationTest extends AbstractTest {


    @Value("${service1.queues.service.name}")
    private String service1QueueName;

    @Value("${service2.queues.service.name}")
    private String service2QueueName;


    @Autowired
    private BusBuilderService busBuilderService;

    @Test
    public void testInjectionOfValue() throws Exception {
        Assert.assertEquals("service1.queue.service" , service1QueueName);
        Assert.assertEquals("service2.queue.service" , service2QueueName);
    }

    @Test
    public void testGetQueuesFromBusBuilderService() throws Exception {
        Assert.assertEquals(2 , busBuilderService.getQueues().size());

        Set<String> queueNames = busBuilderService.getQueues().stream().map(Queue::getName).collect(Collectors.toSet());

        Assert.assertEquals(true , queueNames.contains("service1.queue.service"));
        Assert.assertEquals(true , queueNames.contains("service2.queue.service"));
    }
}
