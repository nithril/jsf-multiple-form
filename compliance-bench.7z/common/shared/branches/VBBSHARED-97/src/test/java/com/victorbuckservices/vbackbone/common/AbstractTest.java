package com.victorbuckservices.vbackbone.common;

import com.victorbuckservices.vbackbone.common.configuration.BusBuilderPlaceholderConfigurerConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.ControlBusConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.MonitoringConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.StorageKeeperConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.UuidGeneratorConfiguration;
import com.victorbuckservices.vbackbone.common.storagekeeper.StorageKeeper;
import com.victorbuckservices.vbackbone.common.testcontext.TestContextConfiguration;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.io.FileUtils;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                UuidGeneratorConfiguration.class
                , CommonSharedConfiguration.class
                , TestContextConfiguration.class
                , StorageKeeperConfiguration.class
                , ControlBusConfiguration.class
                , MonitoringConfiguration.class
                , BusBuilderPlaceholderConfigurerConfiguration.class

        }
)
@EnableConfigurationProperties
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator"
})
public abstract class AbstractTest {


    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    protected StorageKeeper storageKeeper;

    @Value("${storagekeeper.workDirectory}")
    protected String storageKeeperWorkDirectory;

    @Value("${storagekeeper.storageDirectory}")
    protected String storageKeeperStorageDirectory;

    @BeforeClass
    public static void createDirectory() throws Exception {
        Files.createDirectories(Paths.get("target/storagekeeper/work")); //FIXME shoudn't be storageKeeperWorkDirectory?
        Files.createDirectories(Paths.get("target/storagekeeper/storage")); //FIXME shoudn't be storageKeeperStorageDirectory?
    }

    protected void cleanTestFolders(String uuid) {
        String date = storageKeeper.uuidToDate(uuid);
        String service = storageKeeper.uuidToService(uuid);

        File localDir = new File(new File(new File(storageKeeperWorkDirectory, date), service), uuid);
        if (localDir.exists()) {
            try {
                FileUtils.forceDelete(localDir);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete directory [" + localDir + "]", e);
            }
        }

        File storageContainer = new File(new File(storageKeeperStorageDirectory, date), service);
        if (storageContainer.exists()) {
            try {
                FileUtils.forceDelete(storageContainer);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete container [" + storageContainer + "]", e);
            }
        }
    }
}
