package com.victorbuckservices.vbackbone.common.monitoring;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import org.junit.Test;

/**
 * Created on 08/06/2015
 *
 * @author labrot
 */
public class MonitoringTest extends AbstractTest{

    @Test
    public void testName() throws Exception {
        Thread.sleep(20000);

    }
}
