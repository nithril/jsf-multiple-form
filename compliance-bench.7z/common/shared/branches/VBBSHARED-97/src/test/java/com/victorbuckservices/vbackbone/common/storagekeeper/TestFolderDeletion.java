package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.AbstractTest;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.LocalFolderDeletionException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.VFS;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-08-25.
 */
public class TestFolderDeletion extends AbstractTest {

    @Value("storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip")
    private Resource testArchive;


    @Test(expected = LocalFolderDeletionException.class)

    public void testDeleteFolderWithFileObject() throws IOException {


        List<String> uuids = Arrays.asList(
                "014cc6ce-92af-a040-0043-c5ab74a4c94a",
                "014cc6ce-92af-a040-0043-c5ab74a4c94b",
                "014cc5ce-92af-a040-0043-c6ab74a4c94c",
                "014cc5ce-92af-a040-0043-c6ab74a4c94d"
        );

        uuidGeneratorService.setUuids(uuids);

        uuids.forEach(this::cleanTestFolders);

        LocalWorkingDirectory localWorkingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        FileObject containerFileObject = VFS.getManager().toFileObject(testArchive.getFile());

        String fileUri = VFS.getManager().createFileSystem(containerFileObject).resolveFile("inputBundles.xml").toString();

        String localUri = storageKeeper.provideLocalWith(localWorkingDirectory, fileUri);

        String innerPart = localUri.substring(localUri.lastIndexOf('!') + 1, localUri.length());
        File tempFile = new File(localWorkingDirectory.temp(), innerPart);

        // At this point the input folder is deletable

        FileObject source = VFS.getManager().resolveFile(localUri);
        FileObject destination = VFS.getManager().resolveFile(tempFile.getAbsolutePath());

        destination.copyFrom(source, Selectors.SELECT_ALL);
        destination.close();
        source.close();

        // Fails when following line is omitted
        //VFS.getManager().closeFileSystem(source.getFileSystem());
        try {
            FileUtils.forceDelete(localWorkingDirectory.input());
        } catch (IOException e) {
            throw new LocalFolderDeletionException(localWorkingDirectory.input().getAbsolutePath(), e);
        }

    }

}
