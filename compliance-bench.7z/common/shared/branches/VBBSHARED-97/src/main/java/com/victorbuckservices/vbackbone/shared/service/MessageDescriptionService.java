package com.victorbuckservices.vbackbone.shared.service;

import com.victorbuckservices.vbackbone.common.integration.message.MessageEnvelopeHeader;
import com.victorbuckservices.vbackbone.shared.definition.Service;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * Service that must be implemented by each Vbackbone service.
 *
 * @author Marc Plouhinec
 *         Created on 14/10/2014
 */
public interface MessageDescriptionService {

    /**
     * Provide a description for the given message.
     *
     * @return Description
     */
    default String buildDescription(MessageEnvelopeHeader header, Object body) throws IOException{
        return header.getAction() + " " + Objects.toString(body);

    }

    /**
     * @return Supported {@link Service}s by this class.
     */
    List<Service> getSupportedServices();
}
