package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.CommonSharedConfiguration;
import com.victorbuckservices.vbackbone.common.configuration.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.configuration.StorageKeeperConfiguration;
import com.victorbuckservices.vbackbone.common.storagekeeper.testcontext.TestContextConfiguration;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.VFS;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created on 02/03/2015
 *
 * @author labrot
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(
        classes = {
                CommonSharedConfiguration.class
                , TestContextConfiguration.class
                , StorageKeeperConfiguration.class
                , ControlBusConfiguration.class
                , MonitoringConfiguration.class
                , BusBuilderPlaceholderConfigurerConfiguration.class
                , RabbitConnectionConfiguration.class

        }
)
@EnableConfigurationProperties
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator"
})
public abstract class AbstractTest {

    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    protected StorageKeeper storageKeeper;

    protected String getTrunkUri() throws FileSystemException {
        return VFS.getManager().toFileObject(new File(".")).toString() + "/";
    }

    @BeforeClass
    public static void createDirectory() throws Exception {
        Files.createDirectories(Paths.get("target/storagekeeper/work"));
        Files.createDirectories(Paths.get("target/storagekeeper/storage"));
    }

    @Before
    @After
    public void clean(){
        storageKeeper.closeCommunicationLinkIfNeeded();
    }
}
