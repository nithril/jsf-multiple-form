package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.apache.commons.vfs2.VFS;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.IOException;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-10.
 */
public class TestFileObjectResource extends AbstractTest {

    @Autowired
    private StorageKeeper storageKeeper;

    @Value("/storagekeeper/simplefolder/expectedResult.xml")
    Resource testResource;

    @Test
    public void test() throws IOException {
        Resource resource = storageKeeper.getResource(VFS.getManager().toFileObject(testResource.getFile()).toString());

        Assert.assertEquals(
                testResource.getFilename(),
                resource.getFilename()
        );
    }

}
