package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.jcraft.jsch.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.sftp.SftpStorageKeeper;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.VFS;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ActiveProfiles;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-04.
 */
@ActiveProfiles({
        "test",
        "test-with-frozen-uuidgenerator",
        "test-with-sftpstoragekeeper"
})
public class TestSftpStorageKeeper extends AbstractTest {

    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    private SftpStorageKeeper storageKeeper;

    @Value("${storagekeeper.workDirectory}")
    private String storageKeeperWorkDirectory;

    //    @Value("${storagekeeper.storageDirectory}")
    //TODO warn about the importance of using /test/ instead of /storage/ to avoid deleting folder with "real" data
    private String storageKeeperStorageDirectory = "/mnt/vbackbone/storagekeeper/test/";

    @Value("${storagekeeper.sshUser}")
    private String sshUser;

    @Value("${storagekeeper.sshHost}")
    private String sshHost;

    @Value("${storagekeeper.sshPassword}")
    private String sshPassword;

    @Value("storagekeeper/simplefolder/inputBundles.xml")
    private Resource xmlExpected;

    @Value("storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip")
    private Resource containerInput;

    private void cleanTestFolders(String uuid) {
        String date = storageKeeper.uuidToDate(uuid);
        String service = storageKeeper.uuidToService(uuid);

        File localDir = new File(new File(new File(storageKeeperWorkDirectory, date), service), uuid);
        if (localDir.exists()) {
            try {
                FileUtils.forceDelete(localDir);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete local folder [" + localDir + "]", e);
            }
        }

        String storageDir = storageKeeperStorageDirectory + date + "/" + service;
        deleteFtpFolder(storageDir);
    }

    private void deleteFtpFolder(String ftpFolder) {
        JSch jsch = new JSch(); // TODO manage the connection better
        Session session = null;
        ChannelSftp sftpChannel = null;
        try {
            // 1 connect to the sftp storage
            session = jsch.getSession(sshUser, sshHost);
            session.setPassword(sshPassword);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();

            sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();

            if (sftpFileExists(sftpChannel, ftpFolder)) {
                sftpChannel.cd(ftpFolder);
                sftpChannel.rm("*.zip");
                sftpChannel.cd("..");
                sftpChannel.rmdir(ftpFolder);
            }
        } catch (SftpException | JSchException e) {
            e.printStackTrace(); //TODO
        } finally {
            if (sftpChannel != null)
                sftpChannel.disconnect();
            if (session != null)
                session.disconnect();
        }

    }
    private static boolean sftpFileExists(ChannelSftp sftpChannel, String fileToCheck) {
        try {
            SftpATTRS attrs = sftpChannel.lstat(fileToCheck);
            return true;
        } catch (SftpException e) {
            return false;
        }
    }


    @Test
    @Ignore
    public void test() throws IOException {
        String fileUri = "zip:file:///mnt/vbackbone/vbackbone-composition/test/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";

        InputStream inputStream = storageKeeper.getInputStream(fileUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
    }

    @Test
    @Ignore("Fails on Jenkins. Succeeds on local Windows")
    public void testNewLocalWorkingDirectory() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d366e3a3-853f-4962-9bb3-ca38d58e0edf", "d366e3a3-853f-4962-9bb3-ca38d58e0edf",
                "baf6f123-fa60-4319-826b-fe565febd365",
                "230e529f-e1ce-412f-8edc-9e0d6d8014c3",
                "c64cef6c-937a-4f8d-b7cb-df75d3373dbe",
                "913bd87e-eeb7-48e7-9f3f-61a7838b153a"
        ));
        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        File outputFolder = workingDirectory.output();
        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        storageKeeper.archiveLocalData(workingDirectory, VbbFileDataType.OUTPUT);
        storageKeeper.cleanUpLocalData(workingDirectory, VbbFileDataType.OUTPUT);

        File targetFile = new File(workingDirectory.output(), "inputBundles.xml");
        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);

        System.out.println(targetFile);
        System.out.println(resultingUri);

        InputStream inputStream = storageKeeper.getInputStream(resultingUri);
        InputStream expectedIS = xmlExpected.getInputStream();

        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
        inputStream.close();
        expectedIS.close();
    }

}
