package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.storagekeeper.exception.DataTypeNotFoundException;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.InvalidStorageKeeperOperationException;
import com.victorbuckservices.vbackbone.common.storagekeeper.nfs.NfsLocalWorkingDirectory;
import com.victorbuckservices.vbackbone.common.storagekeeper.nfs.NfsStorageKeeper;
import com.victorbuckservices.vbackbone.common.storagekeeper.test.TestHelper;
import com.victorbuckservices.vbackbone.common.uuid.frozen.FrozenUuidGeneratorService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.VFS;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.fail;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-03-18.
 */
public class TestStorageKeeper extends AbstractTest {

    @Autowired
    protected FrozenUuidGeneratorService uuidGeneratorService;

    @Autowired
    private NfsStorageKeeper storageKeeper;

    @Value("${storagekeeper.workDirectory}")
    private String storageKeeperWorkDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String storageKeeperStorageDirectory;

    @Value("storagekeeper/simplefolder/inputBundles.xml")
    private Resource xmlExpected;

    @Value("storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip")
    private Resource containerInput;


    private void cleanTestFolders(String uuid) {
        try {
            TestHelper.cleanTestFolders(storageKeeper, uuid , storageKeeperWorkDirectory, storageKeeperStorageDirectory);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testProvide() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9d",
                "d07fd44b-9c4b-4824-a969-8f2612629a9d"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9d/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml";
        // ex: zip:file:///D:/Project/composition-service/service/src/test/resources/8099/10/01/0x69/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml
        String startingUri = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("expectedResult.xml").toString();

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        String uri = storageKeeper.provideLocalWith(workingDirectory, startingUri);

        Assert.assertEquals(expectedUri, uri);
    }

    @Test
    public void testDoubleProvide() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9e",
                "d07fd44b-9c4b-4824-a969-8f2612629a9e"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9e/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/expectedResult.xml";
        String expectedUri2 = "zip:" + getTrunkUri() + "target/storagekeeper/work/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9e/input/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";


        String startingUri = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("expectedResult.xml").toString();
        String startingUri2 = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("inputBundles.xml").toString();

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        String uri = storageKeeper.provideLocalWith(workingDirectory, startingUri);
        String uri2 = storageKeeper.provideLocalWith(workingDirectory, startingUri2);
        Assert.assertEquals(expectedUri, uri);
        Assert.assertEquals(expectedUri2, uri2);
    }

    @Test
    public void testCommit() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "d07fd44b-9c4b-4824-a969-8f2612629a9f",
                "d07fd44b-9c4b-4824-a969-8f2612629a9f"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        File outputFolder = workingDirectory.output();

        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        String container = storageKeeper.commitLocalOutput(workingDirectory);

        File targetFile = new File(workingDirectory.output(), "inputBundles.xml");

        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);

        InputStream inputStream = storageKeeper.getInputStream(resultingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
        inputStream.close();
        expectedIS.close();
    }

    @Test
    public void testNewArchiveCleanUp() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "014ec078-b714-a040-0104-708c736a2770",
                "014ec078-b714-a040-0104-708c736a2770"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        Assert.assertTrue(workingDirectory.input().exists());
        Assert.assertTrue(workingDirectory.output().exists());
        Assert.assertTrue(workingDirectory.delivery().exists());
        Assert.assertTrue(workingDirectory.log().exists());
        Assert.assertTrue(workingDirectory.temp().exists());

        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.INPUT));
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.DELIVERY));
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.LOGGING));
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.TEMPORARY));

        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.INPUT));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.DELIVERY));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.LOGGING));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.TEMPORARY));

        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.INPUT));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.DELIVERY));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.LOGGING));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.TEMPORARY));


        File outputFolder = workingDirectory.output();
        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        Assert.assertFalse(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.OUTPUT));

        storageKeeper.archiveAllLocalData(workingDirectory);
        File container = ((NfsLocalWorkingDirectory) workingDirectory).getStorageContainer(VbbFileDataType.OUTPUT); //TODO avoid the casting?

        Assert.assertTrue(container.exists());
        Assert.assertFalse(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertTrue(workingDirectory.isArchived(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isCleanedUp(VbbFileDataType.OUTPUT));

        Map<VbbFileDataType, StorageKeeperArchive> uris = storageKeeper.getAllArchiveUris(workingDirectory);

        Map<VbbFileDataType, StorageKeeperArchive> expectedUris = new HashMap<>();
        expectedUris.put(VbbFileDataType.OUTPUT, new StorageKeeperArchive(VbbFileDataType.OUTPUT,getTrunkUri() + "target/storagekeeper/storage/2015/07/24/0x4/014ec078-b714-a040-0104-708c736a2770.output.zip" , 2465));

        Assert.assertEquals(expectedUris, uris);

        storageKeeper.cleanUpAllLocalData(workingDirectory);
        Assert.assertTrue(container.exists());
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertTrue(workingDirectory.isArchived(VbbFileDataType.OUTPUT));
        Assert.assertTrue(workingDirectory.isCleanedUp(VbbFileDataType.OUTPUT));

        File targetFile = new File(workingDirectory.output(), "inputBundles.xml");
        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);

        InputStream inputStream = storageKeeper.getInputStream(resultingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
        inputStream.close();
        expectedIS.close();
    }

    @Test
    public void testNewArchiveEmpty() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "014ec078-b714-a040-0104-708c736a2771",
                "014ec078-b714-a040-0104-708c736a2771"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        Assert.assertTrue(workingDirectory.output().exists());
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        storageKeeper.archiveLocalData(workingDirectory, VbbFileDataType.OUTPUT);
        File container = ((NfsLocalWorkingDirectory) workingDirectory).getStorageContainer(VbbFileDataType.OUTPUT);
        Assert.assertFalse(container.exists());
    }

    @Test(expected = InvalidStorageKeeperOperationException.class)
    public void testNewArchiveContainerAlreadyExisting() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "014ec078-b714-a040-0104-708c736a2772",
                "014ec078-b714-a040-0104-708c736a2772"
        ));

        String baseUuid = uuidGeneratorService.generateUuid();
        cleanTestFolders(baseUuid);

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        File container = ((NfsLocalWorkingDirectory) workingDirectory).getStorageContainer(VbbFileDataType.OUTPUT);
        File outputFolder = workingDirectory.output();
        Assert.assertTrue(workingDirectory.output().exists());
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));

        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        Assert.assertFalse(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertFalse(container.exists());
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));

        storageKeeper.archiveLocalData(workingDirectory, VbbFileDataType.OUTPUT);
        Assert.assertTrue(container.exists());
        Assert.assertTrue(workingDirectory.isArchived(VbbFileDataType.OUTPUT));


        LocalWorkingDirectory sameWorkingDirectory = storageKeeper.getLocalWorkingDirectoryTree(baseUuid);
        Assert.assertTrue(sameWorkingDirectory.output().exists());
        Assert.assertFalse(sameWorkingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertTrue(sameWorkingDirectory.isArchived(VbbFileDataType.OUTPUT));

        // Archiving an already archived folder fails
        storageKeeper.archiveLocalData(sameWorkingDirectory, VbbFileDataType.OUTPUT);
        fail("Exception not thrown");
    }

    @Test
    public void testNewArchiveContainerMadlyCreated() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                // Don't forget to duplicate the first UUID
                // * The first one will be consumed by the cleanTestFolders() method
                // * The second one will be consumed by the StorageKeeper.newLocalWorkingDirectoryTree() factory
                "014ec078-b714-a040-0104-708c736a2773",
                "014ec078-b714-a040-0104-708c736a2773"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();
        File container = ((NfsLocalWorkingDirectory) workingDirectory).getStorageContainer(VbbFileDataType.OUTPUT);
        File outputFolder = workingDirectory.output();
        Assert.assertTrue(workingDirectory.output().exists());
        Assert.assertTrue(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));

        FileUtils.copyDirectory(xmlExpected.getFile().getParentFile(), outputFolder);

        Assert.assertFalse(workingDirectory.isEmpty(VbbFileDataType.OUTPUT));
        Assert.assertFalse(container.exists());

        // Here we create a container that was not there when the LocalWorkingDirectory was instantiated
        Assert.assertTrue(container.createNewFile());
        Assert.assertTrue(container.exists());
        Assert.assertFalse(workingDirectory.isArchived(VbbFileDataType.OUTPUT));

        // This will not fail as the folder was marked as not archived at the LWD instantiation
        // Note: the container will be overwritten
        storageKeeper.archiveLocalData(workingDirectory, VbbFileDataType.OUTPUT);
        Assert.assertTrue(container.exists());

        File targetFile = new File(workingDirectory.output(), "inputBundles.xml");
        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);

        InputStream inputStream = storageKeeper.getInputStream(resultingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
        inputStream.close();
        expectedIS.close();
    }

    @Test
    @Ignore
    public void testInputStream() throws IOException {

        String startingUri = VFS.getManager().resolveFile(new File("./src/test/resources/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip"), "!/inputBundles.xml").getURL().toString();


        //String startingUri = "zip:file:///D:/Project/composition-service/service/src/test/resources/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip!/inputBundles.xml";

        InputStream inputStream = storageKeeper.getInputStream(startingUri);
        InputStream expectedIS = xmlExpected.getInputStream();
        Assert.assertTrue("Checking binary equality", IOUtils.contentEquals(expectedIS, inputStream));
        inputStream.close();
        expectedIS.close();
    }

    @Test
    public void testLocalFileToStorageUriTranslation() throws IOException {
        uuidGeneratorService.setUuids(Arrays.asList(
                "d07fd44b-9c4b-4824-a969-8f2612629a9f",
                "d07fd44b-9c4b-4824-a969-8f2612629a9f"
        ));

        cleanTestFolders(uuidGeneratorService.generateUuid());

        String expectedUri = "zip:" + getTrunkUri() + "target/storagekeeper/storage/9234/07/24/0x69/d07fd44b-9c4b-4824-a969-8f2612629a9f.output.zip!/inputBundles.xml";

        LocalWorkingDirectory workingDirectory = storageKeeper.newLocalWorkingDirectoryTree();

        File sourceFile = xmlExpected.getFile();
        File targetFile = new File(workingDirectory.output(), sourceFile.getName());
        Files.copy(sourceFile.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

        String resultingUri = storageKeeper.localFileToStorageUri(workingDirectory, targetFile);
        Assert.assertEquals(expectedUri, resultingUri);
    }


    @Test
    public void testGetDataTypeFromPath() {

        String pathGood = "/mnt/vbackbone/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.output.zip";
        String pathGood2 = "/var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/delivery/document.pdf";
        String pathOld = "/mnt/vbackbone/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.zip";

        Assert.assertEquals(VbbFileDataType.OUTPUT, StorageKeeperUtils.getDataTypeFromPath(pathGood));
        Assert.assertEquals(VbbFileDataType.DELIVERY, StorageKeeperUtils.getDataTypeFromPath(pathGood2));
        Assert.assertEquals(VbbFileDataType.DELIVERY, StorageKeeperUtils.getDataTypeFromPath(pathOld));
    }

    @Test(expected = DataTypeNotFoundException.class)
    public void testGetDataTypeFromPathWrong() {

        String pathBad = "/mnt/vbackbone/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694.toto.zip";

        StorageKeeperUtils.getDataTypeFromPath(pathBad);
        fail("Exception not thrown");
    }

    @Test(expected = DataTypeNotFoundException.class)
    public void testGetDataTypeFromPathWrong2() {

        String pathBad = "/mnt/vbackbone/storagekeeper/8099/10/01/afede304-905f-44d4-8c9f-1701ec0e6694/archive.zip";

        StorageKeeperUtils.getDataTypeFromPath(pathBad);
        fail("Exception not thrown");
    }













    @Test
    public void testDoubleProvide2() throws IOException {


        String expectedUri = "zip:" + getTrunkUri() + "src/test/resources/foo.zip!/expectedResult.xml";
        String expectedUri2 = "zip:" + getTrunkUri() + "src/test/resources/foo.zip!/inputBundles.xml";


        FileObject fileObject = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("expectedResult.xml");
        FileObject fileObject1 = VFS.getManager().createFileSystem(VFS.getManager().toFileObject(containerInput.getFile())).resolveFile("inputBundles.xml");


        fileObject1.getContent().getSize();





        fileObject.close();
        fileObject1.close();

        VFS.getManager().closeFileSystem(fileObject.getFileSystem());

    }


}


