package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.SystemUtils;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Test;
import org.springframework.boot.ApplicationPid;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

/**
 * Created on 26/11/2015
 *
 * @author labrot
 */
public class TestFileDescriptor extends AbstractTest {

    @Test
    public void testFileDescriptor() throws Exception {
        Assume.assumeTrue(SystemUtils.IS_OS_LINUX);

        ApplicationPid applicationPid = new ApplicationPid();
        String processId = applicationPid.toString();

        long beforeFdCount = list(processId);

        Assert.assertEquals(0, beforeFdCount);

        for (int i = 0; i < 10; i++) {
            String uri = "zip:" + getTrunkUri() + "target/test-classes/storagekeeper/filedescriptor/" + i + ".zip!/a.txt";
            CloseableResource resource = storageKeeper.getResource(uri);
            try (InputStream stream = resource.getInputStream()) {
                Assert.assertEquals("a", IOUtils.toString(stream));
            }
        }

        long afterFdCount = list(processId);

        Assert.assertEquals(10, afterFdCount);

        storageKeeper.closeCommunicationLinkIfNeeded();

        long afterCloseCount = list(processId);


        Assert.assertEquals(0, afterCloseCount);
    }


    private long list(String processId) throws IOException {
        return Files.list(Paths.get("/proc/" + processId + "/fd"))
                .map(f -> {
                    if (Files.isSymbolicLink(f)) {
                        try {
                            f = Files.readSymbolicLink(f);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    return f;
                })
                .filter(f -> f.toString().contains("storagekeeper/filedescriptor"))
                .map(f -> {
                    System.out.println(f);
                    return f;
                })
                .count();
    }
}
