/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.vfs2.provider;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;

import org.apache.commons.vfs2.FileName;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileType;

/**
 * A file in a Zip file system.
 */
public class InternalZipFileEntry {
	/**
	 * The ZipEntry.
	 */
	protected final FileName name;
	protected final ZipEntry entry;
	protected final Set<String> children;
	protected final FileType type;

	protected InternalZipFileEntry(FileName name, ZipEntry entry) throws FileSystemException {
		this.name = name;
		this.entry = entry;
		this.type = entry == null || entry.isDirectory() ? FileType.FOLDER : FileType.FILE;
		this.children = entry != null && !entry.isDirectory() ? Collections.emptySet() : new HashSet<>();
	}


	/**
	 * Attaches a child.
	 * <p/>
	 * TODO: Shouldn't this method have package-only visibility?
	 * Cannot change this without breaking binary compatibility.
	 *
	 * @param childName The name of the child.
	 */
	public void attachChild(final FileName childName) {
		children.add(childName.getBaseName());
	}

	/**
	 * Determines if this file can be written to.
	 *
	 * @return {@code true} if this file is writeable, {@code false} if not.
	 * @throws FileSystemException if an error occurs.
	 */
	public boolean isWriteable() throws FileSystemException {
		return false;
	}

	/**
	 * Returns the file's type.
	 */
	protected FileType doGetType() {
		return type;
	}

	/**
	 * Lists the children of the file.
	 */
	protected String[] doListChildren() {
		if (!getType().hasChildren()) {
			return null;
		}
		return children.toArray(new String[children.size()]);
	}

	/**
	 * Returns the size of the file content (in bytes).  Is only called if
	 * {@link #doGetType} returns {@link FileType#FILE}.
	 */
	protected long doGetContentSize() {
		return entry.getSize();
	}

	/**
	 * Returns the last modified time of this file.
	 */
	protected long doGetLastModifiedTime() throws Exception {
		return entry.getTime();
	}


	public FileType getType() {
		return type;
	}

	public FileName getName() {
		return name;
	}

	public ZipEntry getEntry() {
		return entry;
	}

	public Set<String> getChildren() {
		return children;
	}
}
