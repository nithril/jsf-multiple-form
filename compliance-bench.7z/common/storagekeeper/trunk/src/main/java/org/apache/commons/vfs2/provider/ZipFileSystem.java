/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.vfs2.provider;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.vfs2.Capability;
import org.apache.commons.vfs2.FileName;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.VfsLog;

/**
 * A read-only file system for Zip/Jar files.
 */
public class ZipFileSystem extends AbstractFileSystem {
    private static final Log LOG = LogFactory.getLog(org.apache.commons.vfs2.provider.zip.ZipFileSystem.class);

    private final File file;
    private volatile ZipFile zipFile;

    private final Object monitor = new Object();

    private volatile long lastTimeAllStreamsClosed = 0;

    /**
     * Cache doesn't need to be synchronized since it is read-only.
     */
    private final Map<FileName, InternalZipFileEntry> cache = new HashMap<>();

    public ZipFileSystem(final AbstractFileName rootName,
                         final FileObject parentLayer,
                         final FileSystemOptions fileSystemOptions)
            throws FileSystemException {
        super(rootName, parentLayer, fileSystemOptions);

        // Make a local copy of the file
        file = parentLayer.getFileSystem().replicateFile(parentLayer, Selectors.SELECT_SELF);

        // Open the Zip file
        if (!file.exists()) {
            // Don't need to do anything
            zipFile = null;
            return;
        }

        lastTimeAllStreamsClosed = System.currentTimeMillis();
    }

    @Override
    public void init() throws FileSystemException {
        super.init();

        try {
            // Build the index
            final Enumeration<? extends ZipEntry> entries = getZipFile().entries();

            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                FileName name = getFileSystemManager().resolveName(getRootName(), UriParser.encode(entry.getName()));
                cache.put(name, new InternalZipFileEntry(name, entry));
            }

            FileName rootFileName = getFileSystemManager().resolveName(getRootName(), "/");
            cache.put(rootFileName, new InternalZipFileEntry(rootFileName, null));

            for (Map.Entry<FileName, InternalZipFileEntry> entry : cache.entrySet()) {
                FileName parent = entry.getKey().getParent();
                if (parent != null) {
                    cache.get(parent).attachChild(entry.getKey());
                }
            }

        } finally {
            closeCommunicationLink();
        }
    }

    protected ZipFile getZipFile() throws FileSystemException {
        synchronized (monitor) {
            if (zipFile == null && this.file.exists()) {
                try {
                    this.zipFile = new ZipFile(file);
                } catch (IOException e) {
                    throw new FileSystemException("vfs.provider.zip/open-zip-file.error", file, e);
                }
            }
            return zipFile;
        }
    }

    protected InputStream getInputStream(ZipEntry zipEntry) throws IOException {
        return getZipFile().getInputStream(zipEntry);
    }


    @Override
    protected void doCloseCommunicationLink() {
        synchronized (monitor) {
            try {
                if (zipFile != null) {
                    // Release the zip file
                    zipFile.close();
                    zipFile = null;
                }
            } catch (final IOException e) {
                // getLogger().warn("vfs.provider.zip/close-zip-file.error :" + file, e);
                VfsLog.warn(getLogger(), LOG, "vfs.provider.zip/close-zip-file.error :" + file, e);
            }
        }
    }

    /**
     * Returns the capabilities of this file system.
     */
    @Override
    protected void addCapabilities(final Collection<Capability> caps) {
        caps.addAll(ZipFileProvider.capabilities);
    }

    /**
     * Creates a file object.
     */
    @Override
    protected FileObject createFile(final AbstractFileName name) throws FileSystemException {
        if (cache.containsKey(name)) {
            return new ZipFileObject(monitor, name, cache.get(name), this, true);
        } else {
            return new ZipFileObject(monitor, name, null, this, false);
        }
    }

    /**
     * Adds a file object to the cache.
     */
    @Override
    protected void putFileToCache(final FileObject file) {
    }

    /**
     * Returns a cached file.
     */
    @Override
    protected FileObject getFileFromCache(final FileName name) {
        return null;
    }

    /**
     * remove a cached file.
     */
    @Override
    protected void removeFileFromCache(final FileName name) {
    }

    /**
     * will be called after all file-objects closed their streams.
     */
    protected void notifyAllStreamsClosed() {
        lastTimeAllStreamsClosed = System.currentTimeMillis();
    }

    public long getLastTimeAllStreamsClosed() {
        return lastTimeAllStreamsClosed;
    }


    public boolean closeCommunicationLinkIfNeeded(long thresholdInMilli) {
        synchronized (monitor) {
            if (!isOpen() && zipFile != null && System.currentTimeMillis() - lastTimeAllStreamsClosed > thresholdInMilli) {
                doCloseCommunicationLink();
                return true;
            }
        }
        return false;
    }

}
