package org.apache.commons.vfs2.provider;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileContentInfo;
import org.apache.commons.vfs2.FileContentInfoFactory;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.RandomAccessContent;
import org.apache.commons.vfs2.util.MonitorInputStream;
import org.apache.commons.vfs2.util.RandomAccessMode;

/**
 * Created by nlabrot on 21/11/15.
 */
public class ZipFileContent implements FileContent {


	/**
	 * The default buffer size for {@link #write(OutputStream)}
	 */
	private static final int WRITE_BUFFER_SIZE = 4096;

	private final ZipFileObject fileObject;
	private Map<String, Object> attrs;
	private Map<String, Object> roAttrs;
	private FileContentInfo fileContentInfo;
	private final FileContentInfoFactory fileContentInfoFactory;

	private boolean resetAttributes;

	private final Object monitor;

	private final Deque<FileContentInputStream> openedStreams = new ConcurrentLinkedDeque<>();


	public ZipFileContent(Object monitor, ZipFileObject file, FileContentInfoFactory fileContentInfoFactory) {
		this.monitor = monitor;
		this.fileObject = file;
		this.fileContentInfoFactory = fileContentInfoFactory;
	}



	@Override
	public FileObject getFile() {
		return fileObject;
	}


	@Override
	public long getSize() throws FileSystemException {
		// Do some checking
		if (!fileObject.getType().hasContent()) {
			throw new FileSystemException("vfs.provider/get-size-not-file.error", fileObject);
		}

		try {
			// Get the size
			return fileObject.doGetContentSize();
		} catch (final Exception exc) {
			throw new FileSystemException("vfs.provider/get-size.error", exc, fileObject);
		}
	}

	@Override
	public long getLastModifiedTime() throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/get-last-modified-no-exist.error", fileObject);
		}
		try {
			return fileObject.doGetLastModifiedTime();
		} catch (final Exception e) {
			throw new FileSystemException("vfs.provider/get-last-modified.error", fileObject, e);
		}
	}


	@Override
	public void setLastModifiedTime(final long modTime) throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/set-last-modified-no-exist.error", fileObject);
		}
		try {
			if (!fileObject.doSetLastModifiedTime(modTime)) {
				throw new FileSystemException("vfs.provider/set-last-modified.error", fileObject);
			}
		} catch (final Exception e) {
			throw new FileSystemException("vfs.provider/set-last-modified.error", fileObject, e);
		}
	}


	@Override
	public boolean hasAttribute(final String attrName) throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/exists-attributes-no-exist.error", fileObject);
		}
		getAttributes();
		return attrs.containsKey(attrName);
	}


	@Override
	public Map<String, Object> getAttributes() throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/get-attributes-no-exist.error", fileObject);
		}
		if (resetAttributes || roAttrs == null) {
			try {
				synchronized (this) {
					attrs = fileObject.doGetAttributes();
					roAttrs = Collections.unmodifiableMap(attrs);
					resetAttributes = false;
				}
			} catch (final Exception e) {
				throw new FileSystemException("vfs.provider/get-attributes.error", fileObject, e);
			}
		}
		return roAttrs;
	}


	public void resetAttributes() {
		resetAttributes = true;
	}

	@Override
	public String[] getAttributeNames() throws FileSystemException {
		getAttributes();
		final Set<String> names = attrs.keySet();
		return names.toArray(new String[names.size()]);
	}

	@Override
	public Object getAttribute(final String attrName)
			throws FileSystemException {
		getAttributes();
		return attrs.get(attrName);
	}


	@Override
	public void setAttribute(final String attrName, final Object value)
			throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/set-attribute-no-exist.error", attrName, fileObject);
		}
		try {
			fileObject.doSetAttribute(attrName, value);
		} catch (final Exception e) {
			throw new FileSystemException("vfs.provider/set-attribute.error", e, attrName, fileObject);
		}

		if (attrs != null) {
			attrs.put(attrName, value);
		}
	}


	@Override
	public void removeAttribute(final String attrName) throws FileSystemException {
		if (!fileObject.getType().hasAttributes()) {
			throw new FileSystemException("vfs.provider/remove-attribute-no-exist.error", fileObject);
		}

		try {
			fileObject.doRemoveAttribute(attrName);
		} catch (final Exception e) {
			throw new FileSystemException("vfs.provider/remove-attribute.error", e, attrName, fileObject);
		}

		if (attrs != null) {
			attrs.remove(attrName);
		}
	}

	@Override
	public Certificate[] getCertificates() throws FileSystemException {
		if (!fileObject.exists()) {
			throw new FileSystemException("vfs.provider/get-certificates-no-exist.error", fileObject);
		}

		try {
			final Certificate[] certs = fileObject.doGetCertificates();
			if (certs != null) {
				return certs;
			} else {
				return new Certificate[0];
			}
		} catch (final Exception e) {
			throw new FileSystemException("vfs.provider/get-certificates.error", fileObject, e);
		}
	}



	/**
	 * Handles the end of input stream.
	 */
	private void endInputStream(final FileContentInputStream instr) {
		openedStreams.remove(instr);
		if (openedStreams.isEmpty()){
			fileObject.notifyAllStreamsClosed();
		}
		((AbstractFileSystem) fileObject.getFileSystem()).streamClosed();
	}




	@Override
	public InputStream getInputStream() throws FileSystemException {
		synchronized (monitor) {
			// Get the raw input stream
			FileContentInputStream wrappedInstr = new FileContentInputStream(fileObject, fileObject.getInputStream());
			openedStreams.add(wrappedInstr);
			((AbstractFileSystem) fileObject.getFileSystem()).streamOpened();
			return wrappedInstr;
		}
	}


	@Override
	public RandomAccessContent getRandomAccessContent(final RandomAccessMode mode) throws FileSystemException {
		throw new FileSystemException("vfs.provider/random-access-read-not-supported.error");
	}


	@Override
	public OutputStream getOutputStream() throws FileSystemException {
		return getOutputStream(false);
	}


	@Override
	public OutputStream getOutputStream(final boolean bAppend) throws FileSystemException {
		throw new FileSystemException("vfs.provider/write-append-not-supported.error", fileObject.getName());
	}

	@Override
	public void close() throws FileSystemException {

		FileSystemException exc = null;

		for (FileContentInputStream stream : new ArrayList<>(openedStreams)) {
			try {
				stream.close();
				openedStreams.remove(stream);
			} catch (FileSystemException e) {
				exc = e;
			}
		}

		if (exc != null){
			throw  exc;
		}
	}



	/**
	 * Check if a input and/or output stream is open.
	 * <p/>
	 * This checks only the scope of the current thread.
	 *
	 * @return true if this is the case
	 */
	@Override
	public boolean isOpen() {
		return !openedStreams.isEmpty();
	}


	/**
	 * An input stream for reading content.  Provides buffering, and
	 * end-of-stream monitoring.
	 */
	private final class FileContentInputStream extends MonitorInputStream {
		// avoid gc
		private final FileObject file;

		FileContentInputStream(final FileObject file, final InputStream instr) {
			super(instr);
			this.file = file;
		}

		/**
		 * Closes this input stream.
		 */
		@Override
		public void close() throws FileSystemException {
			try {
				super.close();
			} catch (final IOException e) {
				throw new FileSystemException("vfs.provider/close-instr.error", file, e);
			}
		}

		/**
		 * Called after the stream has been closed.
		 */
		@Override
		protected void onClose() throws IOException {
			try {
				super.onClose();
			} finally {
				endInputStream(this);
			}
		}
	}


	/**
	 * get the content info. e.g. content-type, content-encoding
	 *
	 * @return The FileContentInfo.
	 * @throws FileSystemException if an error occurs.
	 */
	@Override
	public FileContentInfo getContentInfo() throws FileSystemException {
		if (fileContentInfo == null) {
			fileContentInfo = fileContentInfoFactory.create(this);
		}

		return fileContentInfo;
	}

	/**
	 * Writes this content to another FileContent.
	 *
	 * @param fileContent The target FileContent.
	 * @return the total number of bytes written
	 * @throws IOException if an error occurs writing the content.
	 * @since 2.1
	 */
	@Override
	public long write(final FileContent fileContent) throws IOException {
		final OutputStream output = fileContent.getOutputStream();
		try {
			return this.write(output);
		} finally {
			output.close();
		}
	}

	/**
	 * Writes this content to another FileObject.
	 *
	 * @param file The target FileObject.
	 * @return the total number of bytes written
	 * @throws IOException if an error occurs writing the content.
	 * @since 2.1
	 */
	@Override
	public long write(final FileObject file) throws IOException {
		return write(file.getContent());
	}

	/**
	 * Writes this content to an OutputStream.
	 *
	 * @param output The target OutputStream.
	 * @return the total number of bytes written
	 * @throws IOException if an error occurs writing the content.
	 * @since 2.1
	 */
	@Override
	public long write(final OutputStream output) throws IOException {
		return write(output, WRITE_BUFFER_SIZE);
	}

	/**
	 * Writes this content to an OutputStream.
	 *
	 * @param output     The target OutputStream.
	 * @param bufferSize The buffer size to write data chunks.
	 * @return the total number of bytes written
	 * @throws IOException if an error occurs writing the file.
	 * @since 2.1
	 */
	@Override
	public long write(final OutputStream output, final int bufferSize) throws IOException {
		final InputStream input = this.getInputStream();
		long count = 0;
		try {
			// This read/write code from Apache Commons IO
			final byte[] buffer = new byte[bufferSize];
			int n = 0;
			while (-1 != (n = input.read(buffer))) {
				output.write(buffer, 0, n);
				count += n;
			}
		} finally {
			input.close();
		}
		return count;
	}

}
