package com.victorbuckservices.vbackbone.common.storagekeeper.sftp;

import com.google.common.io.Files;
import com.jcraft.jsch.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.*;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import org.apache.commons.exec.OS;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.provider.ZipFileProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.zeroturnaround.zip.ZipUtil;

import javax.annotation.PostConstruct;
import java.io.*;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-02-23.
 */
public class SftpStorageKeeper implements StorageKeeper {
    private static final Logger LOG = LoggerFactory.getLogger(SftpStorageKeeper.class);

    @Autowired
    private Environment environment;

    @Autowired
    protected UuidGeneratorService uuidGeneratorService;

    private FileSystemManager fileSystemManager;

    private DateTimeFormatter dateTimeFormatter;

    @Value("${storagekeeper.workDirectory}")
    private String serviceLocalDirectory;

    //    @Value("${storagekeeper.storageDirectory}")
    //TODO warn about the importance of using /test/ instead of /storage/ to avoid deleting folder with "real" data
    private String serviceStorageDirectory = "/mnt/vbackbone/storagekeeper/test/";

    @Value("${storagekeeper.compressionLevel:-1}")
    private int compressionLevel;

    @Value("${storagekeeper.sshUser}")
    private String sshUser;

    @Value("${storagekeeper.sshHost}")
    private String sshHost;

    @Value("${storagekeeper.sshPassword}")
    private String sshPassword;

    private static boolean sftpFileExists(ChannelSftp sftpChannel, String fileToCheck) {
        try {
            SftpATTRS attrs = sftpChannel.lstat(fileToCheck);
            return true;
        } catch (SftpException e) {
            return false;
        }
    }

    public static String getParentFolder(String fileUriOrPath) {
        return fileUriOrPath.substring(0, fileUriOrPath.lastIndexOf('/'));
    }

    public static String getFilename(String fileUriOrPath) {
        return fileUriOrPath.substring(fileUriOrPath.lastIndexOf('/') + 1, fileUriOrPath.length());
    }

    @Override
    @PostConstruct
    public void init() {
        if (!OS.isFamilyWindows() && environment.acceptsProfiles("production")) {
            throw new IllegalStateException("You are using an SftpStorageKeeper associated to a local environment with a production profile on a non windows OS, this configuration is erroneous");
        }

        LOG.info("StorageKeeper.init()");
        try {
            fileSystemManager = VFS.getManager();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperFileSystemException.MESSAGE);
            throw new StorageKeeperFileSystemException(e);
        }
        dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd").withZone(ZoneOffset.UTC);
    }

    /**
     * Getters and Setters *
     ***********************/

    @Override
    public String getServiceLocalDirectory() {
        return serviceLocalDirectory;
    }

    @Override
    public String getServiceStorageDirectory() {
        return serviceStorageDirectory;
    }

    public void setSshUser(String sshUser) {
        this.sshUser = sshUser;
    }

    public void setSshHost(String sshHost) {
        this.sshHost = sshHost;
    }

    public void setSshPassword(String sshPassword) {
        this.sshPassword = sshPassword;
    }

    /**
     * Helpers *
     ***********/

    @Override
    public String uuidToDate(String uuid) {
        return dateTimeFormatter.format(uuidGeneratorService.toInstant(uuid));
    }

    @Override
    public String uuidToService(String uuid) {
        return "0x" + Integer.toHexString(uuidGeneratorService.toService(uuid));
    }

    private String getTrunkUri() throws FileSystemException {
        return VFS.getManager().toFileObject(new File(".")).toString() + "/";
    }

    @Override
    public String getStorageUri(String uuid, String resourcePath) {
        throw new UnsupportedOperationException("SftpStorageKeeper.provideLocalWith()"); //TODO
    }

    @Override
    public String removeInnerPart(String fileUriOrPath) {
        return fileUriOrPath.substring(0, fileUriOrPath.lastIndexOf('!'));
    }

    public String getBaseLocalDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);
        return Paths.get(this.serviceLocalDirectory, date, service, uuid).toAbsolutePath().toString();
    }

    public String getBaseStorageDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        if (!this.serviceStorageDirectory.endsWith("/")) this.serviceStorageDirectory += "/";

        return this.serviceStorageDirectory + date + "/" + service; //TODO better
    }

    /**
     * Factory *
     ***********/

    @Override
    public LocalWorkingDirectory newLocalWorkingDirectoryTree() {

        String uuid = uuidGeneratorService.generateUuid();
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        LOG.info("StorageKeeper.newLocalWorkingDirectoryTree()");
        LOG.info("UUID=[{}] date=[{}] service=[{}].", uuid, date, service);

        String baseLocalDirectory = getBaseLocalDirectory(uuid);
        String baseStorageDirectory = getBaseStorageDirectory(uuid);

        LOG.info("Local folder: [{}].", baseLocalDirectory);
        LOG.info("Storage folder: [{}].", "sftp://" + sshUser + "@" + sshHost + baseStorageDirectory);

        SftpLocalWorkingDirectory localWorkingDirectory = new SftpLocalWorkingDirectory(sshHost, sshUser, sshPassword);
        localWorkingDirectory.setLocalBase(baseLocalDirectory, true);
        localWorkingDirectory.setStorageBase(baseStorageDirectory, true);
        localWorkingDirectory.setProcessUuid(uuid);
        localWorkingDirectory.init();
        localWorkingDirectory.makeLocalDirs();
        localWorkingDirectory.makeStorageDirs();

        return localWorkingDirectory;
    }

    @Override
    public LocalWorkingDirectory getLocalWorkingDirectoryTree(String uuid) {

        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        LOG.info("StorageKeeper.getLocalWorkingDirectoryTree()");
        LOG.info("UUID=[{}] date=[{}] service=[{}].", uuid, date, service);

        String baseLocalDirectory = getBaseLocalDirectory(uuid);
        String baseStorageDirectory = getBaseStorageDirectory(uuid);

        LOG.info("Local folder: [{}].", baseLocalDirectory);
        LOG.info("Storage folder: [{}].", "sftp://" + sshUser + "@" + sshHost + baseStorageDirectory);

        SftpLocalWorkingDirectory localWorkingDirectory = new SftpLocalWorkingDirectory(sshHost, sshUser, sshPassword);
        localWorkingDirectory.setLocalBase(baseLocalDirectory, false);
        localWorkingDirectory.setStorageBase(baseStorageDirectory, false);
        localWorkingDirectory.setProcessUuid(uuid);
        localWorkingDirectory.init();

        return localWorkingDirectory;
    }

    /**
     * Resources accessors *
     ***********************/

    @Override
    public FileObject getFileObject(String uri) {
        // uri:                 zip:file:///mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip!/file.xml
        // storageContainerUri:     file:///mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip
        // localContainerUri:       file:///local/storage/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip
        // localUri             zip:file:///local/storage/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip!/file.xml
        // sourcePath                      /mnt/vbackbone/vbackbone-service/2015/06/03/123456-1234-1234-123456.zip

        String storageContainerUri;
        String localContainerUri;
        String localUri = null;
        String sourcePath;
        try {
            storageContainerUri = removeInnerPart(uri).replaceFirst("zip:", "");
            localContainerUri = storageContainerUri.replaceFirst("file:///mnt/vbackbone", getTrunkUri() + serviceStorageDirectory);
            localUri = uri.replaceFirst("file:///mnt/vbackbone", getTrunkUri() + serviceStorageDirectory);
            sourcePath = storageContainerUri.replaceFirst("file://", "");

            FileObject localContainerFileObject = fileSystemManager.resolveFile(localContainerUri);

            if (!localContainerFileObject.exists()) {
                JSch jsch = new JSch();
                Session session = null;
                ChannelSftp sftpChannel = null;
                InputStream inputStream = null;
                OutputStream outputStream = null;
                try {
                    session = jsch.getSession(sshUser, sshHost);
                    session.setPassword(sshPassword);
                    session.setConfig("StrictHostKeyChecking", "no");
                    session.connect();
                    sftpChannel = (ChannelSftp) session.openChannel("sftp");
                    sftpChannel.connect();

                    inputStream = new BufferedInputStream(sftpChannel.get(sourcePath));

                    localContainerFileObject.createFile();

                    FileContent localContainerFileObjectContent = localContainerFileObject.getContent();

                    outputStream = new BufferedOutputStream(localContainerFileObjectContent.getOutputStream());

                    IOUtils.copy(inputStream, outputStream);

                    outputStream.flush(); // FIXME: VBBSHARED-99 - Temporary workaround because the next operation (localContainerFileObjectContent.close();) is suspicious

                    localContainerFileObjectContent.close();

                } catch (JSchException | SftpException e) {
                    LOG.error("Unable to get a SSH session to [{}] @ [{}] in order to get an InputStream to [{}]!", sshUser, sshHost, sourcePath, e);
                    throw new IOException("Unable to get a SSH session to '" + sshUser + "@" + sshHost + "' in order to get an InputStream to '" + sourcePath + "'.", e);
                } finally {
                    IOUtils.closeQuietly(inputStream);
                    IOUtils.closeQuietly(outputStream);
                    if (sftpChannel != null)
                        sftpChannel.disconnect();
                    if (session != null)
                        session.disconnect();
                }
            }
            return fileSystemManager.resolveFile(localUri);
        } catch (IOException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, localUri);
            throw new StorageKeeperResolveFileException(localUri, e);
        }
    }

    @Override
    public FileContent getFileContent(String uri) {
        FileObject fileObject = getFileObject(uri);
        FileContent fileContent = null;
        try {
            fileContent = fileObject.getContent();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperGetContentException.MESSAGE, uri);
            throw new StorageKeeperGetContentException(uri, e);
        }
        return fileContent;
    }

    @Override
    public InputStream getInputStream(String uri) {
        try {
            return StorageKeeperUtils.newInputStream(getFileObject(uri));
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperNewInputStreamException.MESSAGE, uri, e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public CloseableResource getResource(String uri) {
        return new FileObjectResource(fileSystemManager, getFileObject(uri));
    }

    /**
     * Main methods *
     ****************/

    @Override
    public String provideLocalWith(LocalWorkingDirectory lwd, String uri) {
        throw new UnsupportedOperationException("SftpStorageKeeper.provideLocalWith()");
    }

    @Override
    public void archiveLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType) {

        LOG.info("StorageKeeper.archiveLocalData() files of type [{}] with compression level [{}]", dataType, compressionLevel);
        if (!SftpLocalWorkingDirectory.getHandledDataTypes().contains(dataType)) {
            LOG.error(UnsupportedVbbFileDataTypeException.MESSAGE, dataType);
            throw new UnsupportedVbbFileDataTypeException(dataType.getName());
        }

        File sourceFolder = localWorkingDirectory.getLocalDirectory(dataType);
        File tempFolder = Files.createTempDir();
        File tempZip = new File(tempFolder, dataType.getName() + ".zip");

        String targetContainer = ((SftpLocalWorkingDirectory) localWorkingDirectory).getStorageContainer(dataType);

        if (localWorkingDirectory.isArchived(dataType)) {
            LOG.error("Cannot archive the already archived folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already archived folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isCleanedUp(dataType)) {
            LOG.error("Cannot archive the already cleaned up folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already cleaned up folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isEmpty(dataType)) {
            LOG.info("Empty folder, will not be archived.");
        } else {
            ZipUtil.pack(sourceFolder.toPath().toFile(), tempZip, compressionLevel);
            copyContainerToSftpStorage(tempZip, targetContainer);
            localWorkingDirectory.setArchived(dataType, true);
        }
    }

    private void copyContainerToSftpStorage(File source, String destinationPath) {
        JSch jsch = new JSch();
        Session session = null;
        ChannelSftp sftpChannel = null;
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            session = jsch.getSession(sshUser, sshHost);
            session.setPassword(sshPassword);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();
            if (sftpFileExists(sftpChannel, destinationPath)) {
                throw new InvalidStorageKeeperOperationException("Cannot archive the already archived folder [" + destinationPath + "]");
            }
            sftpChannel.cd(getParentFolder(destinationPath));
            sftpChannel.put(source.getAbsolutePath(), getFilename(destinationPath));
            if (!sftpFileExists(sftpChannel, destinationPath)) {
                throw new RuntimeException("Error during copying of [" + destinationPath + "]");
            }
        } catch (SftpException | JSchException e) {
            e.printStackTrace(); //TODO
        } finally {
            if (sftpChannel != null)
                sftpChannel.disconnect();
            if (session != null)
                session.disconnect();
        }
    }

    @Override
    public void cleanUpLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType) {
        LOG.info("StorageKeeper.cleanUpLocalData() files of type [{}]", dataType);
        if (!SftpLocalWorkingDirectory.getHandledDataTypes().contains(dataType)) {
            LOG.error(UnsupportedVbbFileDataTypeException.MESSAGE, dataType);
            throw new UnsupportedVbbFileDataTypeException(dataType.getName());
        }
        File sourceFolder = localWorkingDirectory.getLocalDirectory(dataType);

        if (!localWorkingDirectory.isEmpty(dataType) && !localWorkingDirectory.isArchived(dataType)) {
            LOG.error("Cannot clean up the not archived folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot clean up the not archived folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isCleanedUp(dataType)) {
            LOG.error("Cannot clean up the already cleaned up folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already cleaned up folder [" + sourceFolder + "]");
        }

        try {
            FileUtils.forceDelete(sourceFolder);
            localWorkingDirectory.setCleanedUp(dataType, true);
        } catch (IOException e) {
            LOG.error("Cannot clean up the folder [{}] with FileUtils.forceDelete()", sourceFolder);
            throw new LocalFolderDeletionException(sourceFolder.getAbsolutePath(), e);
        }
    }

    @Override
    public void archiveAllLocalData(LocalWorkingDirectory localWorkingDirectory) {
        SftpLocalWorkingDirectory.getHandledDataTypes().stream()
                .filter(dataType -> !localWorkingDirectory.isArchived(dataType) && !localWorkingDirectory.isEmpty(dataType))
                .forEach(dataType -> {
                    archiveLocalData(localWorkingDirectory, dataType);
                });
    }

    @Override
    public void cleanUpAllLocalData(LocalWorkingDirectory localWorkingDirectory) {
        SftpLocalWorkingDirectory.getHandledDataTypes().stream()
                .filter(dataType -> !localWorkingDirectory.isCleanedUp(dataType))
                .forEach(dataType -> cleanUpLocalData(localWorkingDirectory, dataType));
        if (localWorkingDirectory.getLocalBase().list().length == 0) {
            try {
                FileUtils.forceDelete(localWorkingDirectory.getLocalBase());
            } catch (IOException e) {
                LOG.error("Cannot clean up the base folder [{}]", localWorkingDirectory.getLocalBase());
                throw new LocalFolderDeletionException(localWorkingDirectory.getLocalBase().getAbsolutePath(), e);
            }
        }
    }

    @Override
    public String commitLocalOutput(LocalWorkingDirectory localWorkingDirectory) {
        throw new UnsupportedOperationException("SftpStorageKeeper.commitLocalOutput()");
    }

    @Override
    public String localFileToStorageUri(LocalWorkingDirectory workdir, File localFile) {
        if (fileSystemManager == null) {
            try {
                fileSystemManager = VFS.getManager();
            } catch (FileSystemException e) {
                LOG.error(StorageKeeperFileSystemException.MESSAGE);
                throw new StorageKeeperFileSystemException(e);
            }
        }

        if (!localFile.getAbsolutePath().startsWith(workdir.output().getAbsolutePath())) {
            LOG.error("The local file [{}] does not belong to the specified local working directory [{}]", localFile.getAbsolutePath(), workdir.getLocalBase().getAbsolutePath());
            throw new InvalidStorageKeeperOperationException("The local file [" + localFile.getAbsolutePath() + "] does not belong to the specified local working directory [" + workdir.getLocalBase().getAbsolutePath() + "]");
        }
        VbbFileDataType dataType = StorageKeeperUtils.getDataTypeFromPath(localFile.getAbsolutePath());
        String filename = workdir.output().toPath().relativize(localFile.toPath()).toString();
        String containerName = "file://" + ((SftpLocalWorkingDirectory) workdir).getStorageContainer(dataType);

        return "zip:" + containerName + "!/" + filename;
    }

    @Override
    public Map<VbbFileDataType, StorageKeeperArchive> getAllArchiveUris(LocalWorkingDirectory localWorkingDirectory) {
        throw new UnsupportedOperationException("SftpStorageKeeper.getAllArchiveUris()");
    }

    @Override
    public void closeCommunicationLinkIfNeeded() {
    }

}
