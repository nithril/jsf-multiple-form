package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class LocalFolderAlreadyExistingException extends RuntimeException {

    public LocalFolderAlreadyExistingException() {
    }

    public LocalFolderAlreadyExistingException(String folder) {
        super("The local folder [" + folder + "] already exists!");
    }

    public LocalFolderAlreadyExistingException(String folder, Throwable cause) {
        super("The local folder [" + folder + "] already exists!", cause);
    }

    public LocalFolderAlreadyExistingException(Throwable cause) {
        super(cause);
    }
}