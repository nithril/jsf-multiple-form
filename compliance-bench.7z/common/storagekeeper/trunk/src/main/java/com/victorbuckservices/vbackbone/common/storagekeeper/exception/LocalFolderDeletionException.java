package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class LocalFolderDeletionException extends RuntimeException {

    public LocalFolderDeletionException() {
    }

    public LocalFolderDeletionException(String folder) {
        super("Cannot clean up the folder [" + folder + "]!");
    }

    public LocalFolderDeletionException(String folder, Throwable cause) {
        super("Cannot clean up the folder [" + folder + "]!", cause);
    }

    public LocalFolderDeletionException(Throwable cause) {
        super(cause);
    }
}