package com.victorbuckservices.vbackbone.common.storagekeeper.nfs;

import com.victorbuckservices.vbackbone.common.storagekeeper.LocalWorkingDirectory;
import com.victorbuckservices.vbackbone.common.storagekeeper.VbbFileDataType;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.*;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public class NfsLocalWorkingDirectory implements LocalWorkingDirectory {

    private static final List<VbbFileDataType> HANDLED_DATA_TYPES = Arrays.asList(
            VbbFileDataType.DELIVERY,
            VbbFileDataType.INPUT,
            VbbFileDataType.LOGGING,
            VbbFileDataType.OUTPUT,
            VbbFileDataType.TEMPORARY
    );

    /**
     * - localBase is the working directory on the local drive
     * - storageBase is the directory on the storage file server that will contain the containers after a commit
     */
    private File localBase;
    private File storageBase;
    private String processUuid;

    /**
     * These are the sub-folders of the localBase directory.
     * All information stored in these folders must respect the following rules in order to be handled correctly
     * by the Archiving Service:
     * - input:    input files (which are provided by the provideLocalWith method)
     * - output:   output file that will be consumed by another service
     * - delivery: document (PDF or HTML) that will be referenced by another service
     * - log:      logs
     * - temp:     all the other types of files
     */
    private Map<VbbFileDataType, File> folders;
    private Map<VbbFileDataType, File> containers;
    private Map<VbbFileDataType, Boolean> archiveStatus;
    private Map<VbbFileDataType, Boolean> cleanedUpStatus;

    public NfsLocalWorkingDirectory() {
    }

    public static List<VbbFileDataType> getHandledDataTypes() {
        return HANDLED_DATA_TYPES;
    }

    public void init() {
        folders = new HashMap<>();
        containers = new HashMap<>();
        archiveStatus = new HashMap<>();
        cleanedUpStatus = new HashMap<>();
        for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
            File localFolder = new File(localBase, dataType.getName());
            File container = new File(storageBase, processUuid + "." + dataType.getName() + ".zip");
            folders.put(dataType, localFolder);
            containers.put(dataType, container);

            if (localFolder.exists() && container.exists()) {
                archiveStatus.put(dataType, true);
                cleanedUpStatus.put(dataType, false);
            } else if (localFolder.exists() && !container.exists()) {
                archiveStatus.put(dataType, false);
                cleanedUpStatus.put(dataType, false);
            } else if (!localFolder.exists() && container.exists()) {
                archiveStatus.put(dataType, true);
                cleanedUpStatus.put(dataType, true);
            } else {
                archiveStatus.put(dataType, false);
                cleanedUpStatus.put(dataType, false);
            }
        }
    }

    @Override
    public File getLocalBase() {
        return localBase;
    }

    public void setLocalBase(String baseFolder, boolean isNew) {
        localBase = new File(baseFolder);

        if (isNew && localBase.exists()) {
            throw new LocalFolderAlreadyExistingException(localBase.getAbsolutePath());
        } else if (!isNew && !localBase.exists()) {
            throw new LocalFolderNotFoundException(localBase.getAbsolutePath());
        }
    }

    @Override
    public File getStorageBase() {
        return storageBase;
    }

    public void setStorageBase(String storageBase, boolean isNew) {
        this.storageBase = new File(storageBase);
        if (!isNew && !this.storageBase.exists()) {
            throw new StorageFolderNotFoundException(this.storageBase.getAbsolutePath());
        }
    }

    @Override
    public String getProcessUuid() {
        return processUuid;
    }

    public void setProcessUuid(String processUuid) {
        this.processUuid = processUuid;
    }

    public void makeLocalDirs() {
        if (!localBase.mkdirs()) {
            if (!localBase.exists()) {
                throw new LocalFolderCreationException(localBase.getAbsolutePath());
            }
        }

        for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
            if (!folders.get(dataType).mkdirs()) {
                if (!folders.get(dataType).exists()) {
                    throw new LocalFolderCreationException(folders.get(dataType).getAbsolutePath());
                }
            }
        }
    }

    public void makeStorageDirs() {
        // If storageBase already exists, the mkdirs() will return false
        if (!storageBase.exists()) {
            if (!storageBase.mkdirs()) {
                if (!storageBase.exists()) {
                    throw new StorageFolderCreationException(storageBase.getAbsolutePath());
                }
            }
        }
    }

    @Override
    public File getLocalDirectory(VbbFileDataType dataType) {
        return folders.get(dataType);
    }

    @Override
    public File getStorageContainer(VbbFileDataType dataType) {
        return containers.get(dataType);
    }

    @Override
    public boolean isArchived(VbbFileDataType dataType) {
        return archiveStatus.get(dataType);
    }

    @Override
    public boolean isCleanedUp(VbbFileDataType dataType) {
        return cleanedUpStatus.get(dataType);
    }

    @Override
    public boolean isEmpty(VbbFileDataType dataType) {
        if (!folders.get(dataType).exists()) return true;
        return folders.get(dataType).list().length == 0;
    }

    @Override
    public boolean setArchived(VbbFileDataType dataType, boolean value) {
        return archiveStatus.put(dataType, value);
    }

    @Override
    public boolean setCleanedUp(VbbFileDataType dataType, boolean value) {
        return cleanedUpStatus.put(dataType, value);
    }

    /**
     * The following getters are there for ease of access
     */
    @Override
    public File input() {
        return folders.get(VbbFileDataType.INPUT);
    }

    @Override
    public File output() {
        return folders.get(VbbFileDataType.OUTPUT);
    }

    @Override
    public File temp() {
        return folders.get(VbbFileDataType.TEMPORARY);
    }

    @Override
    public File log() {
        return folders.get(VbbFileDataType.LOGGING);
    }

    @Override
    public File temporary() {
        return folders.get(VbbFileDataType.TEMPORARY);
    }

    @Override
    public File logging() {
        return folders.get(VbbFileDataType.LOGGING);
    }

    @Override
    public File delivery() {
        return folders.get(VbbFileDataType.DELIVERY);
    }
}
