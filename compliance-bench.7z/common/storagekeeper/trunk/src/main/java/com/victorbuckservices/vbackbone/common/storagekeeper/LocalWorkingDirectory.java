package com.victorbuckservices.vbackbone.common.storagekeeper;

import java.io.File;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-08-19.
 */
public interface LocalWorkingDirectory {
    String getProcessUuid();

    File getLocalBase();

    Object getStorageBase();

    File getLocalDirectory(VbbFileDataType dataType);

    Object getStorageContainer(VbbFileDataType dataType);

    boolean isArchived(VbbFileDataType dataType);

    boolean isCleanedUp(VbbFileDataType dataType);

    boolean isEmpty(VbbFileDataType dataType);

    boolean setArchived(VbbFileDataType dataType, boolean value);

    boolean setCleanedUp(VbbFileDataType dataType, boolean value);

    File input();

    File output();

    File temp();

    File log();

    File temporary();

    File logging();

    File delivery();
}
