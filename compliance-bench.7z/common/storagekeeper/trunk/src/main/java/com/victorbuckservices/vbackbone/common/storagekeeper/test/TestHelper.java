package com.victorbuckservices.vbackbone.common.storagekeeper.test;

import com.victorbuckservices.vbackbone.common.storagekeeper.StorageKeeper;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

/**
 * Created on 08/24/2015
 *
 * @author labrot
 */
public class TestHelper {

    private TestHelper() {
    }

    public static final void cleanTestFolders(StorageKeeper storageKeeper , String uuid, String workDirectory, String storageDirectory) {
        String date = storageKeeper.uuidToDate(uuid);
        String service = storageKeeper.uuidToService(uuid);

        File localDir = new File(new File(new File(workDirectory, date), service), uuid);
        if (localDir.exists()) {
            try {
                FileUtils.forceDelete(localDir);
            } catch (IOException e) {
                throw new RuntimeException("Unable do delete local folder [" + localDir + "]", e);
            }
        }

        File storageDir = new File(new File(storageDirectory, date), service);
        if (storageDir.exists()) {
            try {
                FileUtils.forceDelete(storageDir);
            } catch (IOException e) {
                deleteFileInDirectory(storageDir);
                throw new RuntimeException("Unable do delete storage folder [" + storageDir + "]", e);
            }
        }
    }

    public static final void deleteFileInDirectory(File dir) {
        File[] files = dir.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                deleteFileInDirectory(file);
                if (file.delete())
                    System.out.println("directory:" + file.getAbsolutePath() + " sucessfully deleted!");
                else
                    System.out.println("directory:" + file.getAbsolutePath() + " NOT deleted!");
            } else {
                if (file.delete())
                    System.out.println("     file:" + file.getAbsolutePath() + " sucessfully deleted!");
                else
                    System.out.println("     file:" + file.getAbsolutePath() + " NOT deleted!");
            }
        }
    }

}
