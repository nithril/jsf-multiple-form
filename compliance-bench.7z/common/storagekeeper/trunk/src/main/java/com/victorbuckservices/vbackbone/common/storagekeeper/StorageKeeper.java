package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.springframework.core.io.Resource;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.InputStream;
import java.util.Map;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public interface StorageKeeper {
    @PostConstruct
    void init();

    String uuidToDate(String uuid);

    String uuidToService(String uuid);

    LocalWorkingDirectory newLocalWorkingDirectoryTree();

    LocalWorkingDirectory getLocalWorkingDirectoryTree(String uuid);

    String commitLocalOutput(LocalWorkingDirectory localWorkingDirectory);

    void archiveLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType);

    void cleanUpLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType);

    void archiveAllLocalData(LocalWorkingDirectory localWorkingDirectory);

    void cleanUpAllLocalData(LocalWorkingDirectory localWorkingDirectory);

    Map<VbbFileDataType, StorageKeeperArchive> getAllArchiveUris(LocalWorkingDirectory localWorkingDirectory);

    FileObject getFileObject(String uri);

    /**
     * Get the {@link FileContent} associated to the URI. <b>The {@link FileContent} must be closed after use</b>
     *
     * @param uri
     * @return
     */
    FileContent getFileContent(String uri);

    InputStream getInputStream(String uri);

    CloseableResource getResource(String uri);

    String getStorageUri(String uuid, String resourcePath);

    default Resource getStorageResourceFromUuid(String uuid, String resourcePath) {
        return getResource(getStorageUri(uuid, resourcePath));
    }

    String getServiceLocalDirectory();

    String getServiceStorageDirectory();

    String provideLocalWith(LocalWorkingDirectory lwd, String uri);

    String removeInnerPart(String fileUriOrPath);

    String localFileToStorageUri(LocalWorkingDirectory workdir, File localFile);

    void closeCommunicationLinkIfNeeded();
}
