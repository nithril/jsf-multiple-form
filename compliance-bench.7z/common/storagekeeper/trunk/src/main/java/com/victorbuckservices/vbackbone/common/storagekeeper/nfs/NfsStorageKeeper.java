package com.victorbuckservices.vbackbone.common.storagekeeper.nfs;

import com.victorbuckservices.vbackbone.common.storagekeeper.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.*;
import com.victorbuckservices.vbackbone.common.utils.lambda.IoCloser;
import com.victorbuckservices.vbackbone.common.uuid.UuidGeneratorService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.ZipFileProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.zeroturnaround.zip.ZipUtil;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.stream.Collectors;

import static net.logstash.logback.argument.StructuredArguments.kv;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-02-23.
 */
public class NfsStorageKeeper implements StorageKeeper {

    private static final Logger LOG = LoggerFactory.getLogger(NfsStorageKeeper.class);

    @Autowired
    protected UuidGeneratorService uuidGeneratorService;

    @Value("${storagekeeper.workDirectory}")
    private String serviceLocalDirectory;

    @Value("${storagekeeper.storageDirectory}")
    private String serviceStorageDirectory;

    @Value("${storagekeeper.compressionLevel:-1}")
    private int compressionLevel;

    @Value("${storagekeeper.closeIfNeededThreshold:60000}")
    private int closeIfNeededThreshold;

    @Value("${storagekeeper.closeIfNeededFrequency:10000}")
    private int closeIfNeededFrequency;

    private StandardFileSystemManager fileSystemManager;
    private DateTimeFormatter dateTimeFormatter;


    @Override
    @PostConstruct
    public void init() {
        LOG.info("StorageKeeper.init()");
        try {
            fileSystemManager = new StandardFileSystemManager();
            fileSystemManager.setConfiguration(getClass().getResource("/storagekeeper-providers.xml"));
            fileSystemManager.init();

        } catch (FileSystemException e) {
            LOG.error(StorageKeeperFileSystemException.MESSAGE);
            throw new StorageKeeperFileSystemException(e);
        }
        dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd").withZone(ZoneOffset.UTC);
        testIfDirectoryIsWritableAndReadable(serviceLocalDirectory, true, true);
        testIfDirectoryIsWritableAndReadable(serviceStorageDirectory, true, false);
    }


    /**
     * Getters and Setters *
     ***********************/

    @Override
    public String getServiceLocalDirectory() {
        return serviceLocalDirectory;
    }

    public void setServiceLocalDirectory(String serviceLocalDirectory) {
        this.serviceLocalDirectory = serviceLocalDirectory;
    }

    @Override
    public String getServiceStorageDirectory() {
        return serviceStorageDirectory;
    }

    public void setServiceStorageDirectory(String serviceStorageDirectory) {
        this.serviceStorageDirectory = serviceStorageDirectory;
    }

    public UuidGeneratorService getUuidGeneratorService() {
        return uuidGeneratorService;
    }

    public void setUuidGeneratorService(UuidGeneratorService uuidGeneratorService) {
        this.uuidGeneratorService = uuidGeneratorService;
    }

    public DateTimeFormatter getDateTimeFormatter() {
        return dateTimeFormatter;
    }

    public void setDateTimeFormatter(DateTimeFormatter dateTimeFormatter) {
        this.dateTimeFormatter = dateTimeFormatter;
    }

    /**
     * Helpers *
     ***********/

    @Override
    public String uuidToDate(String uuid) {
        return dateTimeFormatter.format(uuidGeneratorService.toInstant(uuid));
    }

    @Override
    public String uuidToService(String uuid) {
        return "0x" + Integer.toHexString(uuidGeneratorService.toService(uuid));
    }

    @Override
    public String removeInnerPart(String fileUriOrPath) {
        return fileUriOrPath.substring(0, fileUriOrPath.lastIndexOf('!'));
    }

    public String getBaseLocalDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);
        return Paths.get(this.serviceLocalDirectory, date, service, uuid).toAbsolutePath().toString();
    }

    public String getBaseStorageDirectory(String uuid) {
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);
        return Paths.get(this.serviceStorageDirectory, date, service).toAbsolutePath().toString();
    }

    @Override
    public String getStorageUri(String uuid, String fileWithinTheContainer) {
        try {
            String containerName = fileSystemManager.resolveFile(getBaseStorageDirectory(uuid)).toString();
            return "zip:" + containerName + "!/" + fileWithinTheContainer;
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, getBaseStorageDirectory(uuid));
            throw new StorageKeeperResolveFileException(getBaseStorageDirectory(uuid), e);
        }
    }

    private String getContainerUri(String fileOrContainerStorageUri) {

        try {
            FileSystem fileSystem = getFileObject(fileOrContainerStorageUri).getFileSystem();

            FileObject parentLayer = fileSystem.getParentLayer();

            if (parentLayer != null) {
                return parentLayer.getURL().toString();
            } else {
                return fileOrContainerStorageUri;
            }
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperParentLayerException.MESSAGE, fileOrContainerStorageUri);
            throw new StorageKeeperParentLayerException(fileOrContainerStorageUri, e);
        }
    }

    private String getContainerUri(LocalWorkingDirectory workdir, VbbFileDataType dataType) {

        try {
            return fileSystemManager.resolveFile(((NfsLocalWorkingDirectory) workdir).getStorageContainer(dataType).getAbsolutePath()).toString();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, ((NfsLocalWorkingDirectory) workdir).getStorageContainer(dataType).getAbsolutePath());
            throw new StorageKeeperResolveFileException(((NfsLocalWorkingDirectory) workdir).getStorageContainer(dataType).getAbsolutePath(), e);
        }
    }

    private void testIfDirectoryIsWritableAndReadable(String directoryAsString, boolean requireRead, boolean requireWrite) {

        Path dir = Paths.get(directoryAsString);

        Validate.isTrue(Files.isDirectory(dir), "The folder [%s] must be a directory", directoryAsString);

        if (requireRead) {
            Validate.isTrue(Files.isReadable(dir), "The folder [%s] must exist and be readable", directoryAsString);
        }
        if (requireWrite) {
            Validate.isTrue(Files.isWritable(dir), "The folder [%s] must exist and be writable", directoryAsString);
        }
    }

    /**
     * Factory *
     ***********/

    @Override
    public LocalWorkingDirectory newLocalWorkingDirectoryTree() {

        String uuid = uuidGeneratorService.generateUuid();
        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        LOG.info("StorageKeeper.newLocalWorkingDirectoryTree()");
        LOG.info("UUID=[{}] date=[{}] service=[{}].", uuid, date, service);

        String baseLocalDirectory = getBaseLocalDirectory(uuid);
        String baseStorageDirectory = getBaseStorageDirectory(uuid);

        LOG.info("Local folder: [{}].", baseLocalDirectory);
        LOG.info("Storage folder: [{}].", baseStorageDirectory);

        NfsLocalWorkingDirectory localWorkingDirectory = new NfsLocalWorkingDirectory();
        localWorkingDirectory.setLocalBase(baseLocalDirectory, true);
        localWorkingDirectory.setStorageBase(baseStorageDirectory, true);
        localWorkingDirectory.setProcessUuid(uuid);
        localWorkingDirectory.init();
        localWorkingDirectory.makeLocalDirs();
        localWorkingDirectory.makeStorageDirs();

        return localWorkingDirectory;
    }

    @Override
    public LocalWorkingDirectory getLocalWorkingDirectoryTree(String uuid) {

        String date = uuidToDate(uuid);
        String service = uuidToService(uuid);

        LOG.info("StorageKeeper.getLocalWorkingDirectoryTree()");
        LOG.info("UUID=[{}] date=[{}] service=[{}].", uuid, date, service);

        String baseLocalDirectory = getBaseLocalDirectory(uuid);
        String baseStorageDirectory = getBaseStorageDirectory(uuid);

        LOG.info("Local folder: [{}].", baseLocalDirectory);
        LOG.info("Storage folder: [{}].", baseStorageDirectory);

        NfsLocalWorkingDirectory localWorkingDirectory = new NfsLocalWorkingDirectory();
        localWorkingDirectory.setLocalBase(baseLocalDirectory, false);
        localWorkingDirectory.setStorageBase(baseStorageDirectory, false);
        localWorkingDirectory.setProcessUuid(uuid);
        localWorkingDirectory.init();

        return localWorkingDirectory;
    }

    /**
     * Resources accessors *
     ***********************/

    @Override
    public FileObject getFileObject(String uri) {
        FileObject fileObject;
        try {
            fileObject = fileSystemManager.resolveFile(uri);
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, uri);
            throw new StorageKeeperResolveFileException(uri, e);
        }

        return fileObject;
    }

    @Override
    public FileContent getFileContent(String uri) {
        FileObject fileObject = getFileObject(uri);
        try {
            return fileObject.getContent();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperGetContentException.MESSAGE, uri);
            throw new StorageKeeperGetContentException(uri, e);
        }
    }

    @Override
    public InputStream getInputStream(String uri) {
        try {
            return StorageKeeperUtils.newInputStream(getFileObject(uri));
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperNewInputStreamException.MESSAGE, uri, e);
            throw new StorageKeeperNewInputStreamException(uri, e);
        }
    }

    @Override
    public CloseableResource getResource(String uri) {
        return new FileObjectResource(fileSystemManager, getFileObject(uri));
    }

    /**
     * Main methods *
     ****************/

    @Override
    public String provideLocalWith(LocalWorkingDirectory lwd, String uri) {

        /**
         * Get the storage-id:
         * input:
         * * LWD: /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/{input,output,temp, delivery, log}
         * * URI: zip:file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip!/bundles-email-composition.xml
         * container:
         * * URI: file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
         * copy to:
         * * URI file:///var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
         * translate:
         * * URI zip:file:///var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip!/bundles-email-composition.xml
         */

        // file:///mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
        String containerUri = getContainerUri(uri);

        // 014d581f-e724-a040-0014-dd5765264b4c.zip
        String containerName = getFileObject(containerUri).getName().getBaseName();

        // FileObject of /mnt/vbackbone/vbackbone-normalization/2015-05-15/014d581f-e724-a040-0014-dd5765264b4c.zip
        FileObject containerSourceFileObject;

        try {
            containerSourceFileObject = fileSystemManager.resolveFile(containerUri);

            if (!containerSourceFileObject.exists()) {
                LOG.error(StorageContainerNotFoundException.MESSAGE, containerUri);
                throw new StorageContainerNotFoundException(containerUri);
            }
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, containerUri, e);
            throw new StorageKeeperResolveFileException(containerUri, e);
        }

        // /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
        String destinationUri = null;
        File destinationFile = new File(lwd.input(), containerName);
        try {
            destinationUri = fileSystemManager.toFileObject(destinationFile).toString();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperGetFileObjectException.MESSAGE, destinationFile.toString(), e);
            throw new StorageKeeperGetFileObjectException(destinationFile.toString(), e);
        }

        // FileObject of /var/local/vbackbone/vbackbone-composition/work/2015-05-18/014d67c4-49ff-a040-0014-dd5765264b9b/input/014d581f-e724-a040-0014-dd5765264b4c.zip
        FileObject containerDestinationFileObject;
        try {
            containerDestinationFileObject = fileSystemManager.resolveFile(destinationUri);
            if (containerDestinationFileObject.exists()) {
                // TODO: check if the container are the same
                LOG.info("Container already provided [{}]", destinationUri);
                return uri.replaceFirst(containerUri, destinationUri);
            }
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperResolveFileException.MESSAGE, destinationUri);
            throw new StorageKeeperResolveFileException(destinationUri, e);
        }

        try {
            containerDestinationFileObject.copyFrom(containerSourceFileObject, Selectors.SELECT_ALL);
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperCopyException.MESSAGE, containerUri, destinationUri);
            throw new StorageKeeperCopyException(containerUri, destinationUri, e);
        } finally {
            IoCloser.ioCloser().close(containerSourceFileObject, containerDestinationFileObject);
            //IoCloser.ioCloser().close(containerSourceFileObject.getFileSystem(), containerDestinationFileObject.getFileSystem());
        }
        // TODO: verify if the copy has been done successfully

        return uri.replaceFirst(containerUri, destinationUri);
    }

    @Override
    public void archiveLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType) {
        LOG.info("StorageKeeper.archiveLocalData() files of type [{}] with compression level [{}]", dataType, compressionLevel);
        if (!NfsLocalWorkingDirectory.getHandledDataTypes().contains(dataType)) {
            LOG.error(UnsupportedVbbFileDataTypeException.MESSAGE, dataType);
            throw new UnsupportedVbbFileDataTypeException(dataType.getName());
        }

        File sourceFolder = localWorkingDirectory.getLocalDirectory(dataType);
        File targetContainer = ((NfsLocalWorkingDirectory) localWorkingDirectory).getStorageContainer(dataType);

        if (localWorkingDirectory.isArchived(dataType)) {
            LOG.error("Cannot archive the already archived folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already archived folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isCleanedUp(dataType)) {
            LOG.error("Cannot archive the already cleaned up folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already cleaned up folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isEmpty(dataType)) {
            LOG.info("Empty folder, will not be archived.");
        } else {
            ZipUtil.pack(sourceFolder.toPath().toFile(), targetContainer, compressionLevel);
            localWorkingDirectory.setArchived(dataType, true);
            LOG.info("StorageKeeper.archiveLocalData() done and available into {}", kv("storagePath", targetContainer.toURI().toString()));
        }
    }

    @Override
    public void cleanUpLocalData(LocalWorkingDirectory localWorkingDirectory, VbbFileDataType dataType) {
        LOG.info("StorageKeeper.cleanUpLocalData() files of type [{}]", dataType);
        if (!NfsLocalWorkingDirectory.getHandledDataTypes().contains(dataType)) {
            LOG.error(UnsupportedVbbFileDataTypeException.MESSAGE, dataType);
            throw new UnsupportedVbbFileDataTypeException(dataType.getName());
        }
        File sourceFolder = localWorkingDirectory.getLocalDirectory(dataType);

        if (!localWorkingDirectory.isEmpty(dataType) && !localWorkingDirectory.isArchived(dataType)) {
            LOG.error("Cannot clean up the not archived folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot clean up the not archived folder [" + sourceFolder + "]");
        } else if (localWorkingDirectory.isCleanedUp(dataType)) {
            LOG.error("Cannot clean up the already cleaned up folder [{}]", sourceFolder);
            throw new InvalidStorageKeeperOperationException("Cannot archive the already cleaned up folder [" + sourceFolder + "]");
        }

        try {
            FileUtils.forceDelete(sourceFolder);
            localWorkingDirectory.setCleanedUp(dataType, true);
        } catch (IOException e) {
            LOG.error("Cannot clean up the folder [{}] with FileUtils.forceDelete()", sourceFolder);
            throw new LocalFolderDeletionException(sourceFolder.getAbsolutePath(), e);
        }
    }

    @Override
    public void archiveAllLocalData(LocalWorkingDirectory localWorkingDirectory) {
        NfsLocalWorkingDirectory.getHandledDataTypes().stream()
                .filter(dataType -> !localWorkingDirectory.isArchived(dataType) && !localWorkingDirectory.isEmpty(dataType))
                .forEach(dataType -> {
                    archiveLocalData(localWorkingDirectory, dataType);
                });
    }

    @Override
    public void cleanUpAllLocalData(LocalWorkingDirectory localWorkingDirectory) {
        NfsLocalWorkingDirectory.getHandledDataTypes().stream()
                .filter(dataType -> !localWorkingDirectory.isCleanedUp(dataType))
                .forEach(dataType -> cleanUpLocalData(localWorkingDirectory, dataType));
        if (localWorkingDirectory.getLocalBase().list().length == 0) {
            try {
                FileUtils.forceDelete(localWorkingDirectory.getLocalBase());
            } catch (IOException e) {
                LOG.error("Cannot clean up the base folder [{}]", localWorkingDirectory.getLocalBase());
                throw new LocalFolderDeletionException(localWorkingDirectory.getLocalBase().getAbsolutePath(), e);
            }
        }
    }

    @Override
    public String commitLocalOutput(LocalWorkingDirectory localWorkingDirectory) {
        archiveLocalData(localWorkingDirectory, VbbFileDataType.OUTPUT);
        return ((NfsLocalWorkingDirectory) localWorkingDirectory).getStorageContainer(VbbFileDataType.OUTPUT).getAbsolutePath();
    }

    @Override
    public String localFileToStorageUri(LocalWorkingDirectory workdir, File localFile) {

        if (workdir.getStorageBase() == null) {
            LOG.error("The local working directory doesn't have the storage base set!");
            throw new InvalidStorageKeeperOperationException("The local working directory doesn't have the storage base set!");

        } else if (!workdir.getLocalBase().toPath().startsWith(Paths.get(serviceLocalDirectory).toAbsolutePath())) {
            LOG.error("The local working directory [{}] does not belong to this Storage Keeper configuration [{}]!", workdir.getLocalBase().getAbsolutePath(), serviceLocalDirectory);
            throw new InvalidStorageKeeperOperationException("The local working directory [" + workdir.getLocalBase().getAbsolutePath() + "] does not belong to this Storage Keeper configuration [" + serviceLocalDirectory + "]!");

        } else if (!localFile.getAbsolutePath().startsWith(workdir.getLocalBase().getAbsolutePath())) {
            LOG.error("The local file [{}] does not belong to the specified local working directory [{}]", localFile.getAbsolutePath(), workdir.getLocalBase().getAbsolutePath());
            throw new InvalidStorageKeeperOperationException("The local file [" + localFile.getAbsolutePath() + "] does not belong to the specified local working directory [" + workdir.getLocalBase().getAbsolutePath() + "]");
        }

        VbbFileDataType dataType = StorageKeeperUtils.getDataTypeFromPath(localFile.getAbsolutePath());

        String filename = workdir.getLocalDirectory(dataType).toPath().relativize(localFile.toPath()).toString();

        return "zip:" + getContainerUri(workdir, dataType) + "!/" + filename;
    }

    @Override
    public Map<VbbFileDataType, StorageKeeperArchive> getAllArchiveUris(LocalWorkingDirectory localWorkingDirectory) {
        return NfsLocalWorkingDirectory.getHandledDataTypes().stream()
                .filter(dataType -> localWorkingDirectory.isArchived(dataType))
                .collect(Collectors.toMap(
                        dataType -> dataType,
                        dataType -> {
                            String containerUri = getContainerUri(localWorkingDirectory, dataType);
                            return new StorageKeeperArchive(dataType, containerUri, getContainerSize(containerUri));
                        }
                ));
    }


    @Override
    @Scheduled(fixedDelayString = "${storagekeeper.closeIfNeededFrequency:10000}")
    public void closeCommunicationLinkIfNeeded() {
        try {
            ZipFileProvider provider = (ZipFileProvider) fileSystemManager.getProvider("zip");
            int closedLinks = provider.closeCommunicationLinkIfNeeded(closeIfNeededThreshold);
            if (closedLinks > 0) {
                LOG.debug("closeCommunicationLinkIfNeeded  [{}]", closedLinks);
            }
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
    }


    private long getContainerSize(String containerUri) {
        try (FileContent fileContent = getFileContent(containerUri)) {
            return fileContent.getSize();
        } catch (FileSystemException e) {
            LOG.error(StorageKeeperGetContentException.MESSAGE, containerUri);
            throw new StorageKeeperGetContentException(containerUri, e);
        }
    }
}
