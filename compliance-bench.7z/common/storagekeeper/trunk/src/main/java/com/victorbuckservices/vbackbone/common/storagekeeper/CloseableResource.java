package com.victorbuckservices.vbackbone.common.storagekeeper;

import org.springframework.core.io.Resource;

import java.io.Closeable;

/**
 * Created on 16/10/2015
 *
 * @author labrot
 */
public interface CloseableResource extends Resource, Closeable {

}
