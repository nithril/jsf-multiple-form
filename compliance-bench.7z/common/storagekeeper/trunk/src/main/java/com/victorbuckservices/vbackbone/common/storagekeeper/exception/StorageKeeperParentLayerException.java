package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class StorageKeeperParentLayerException extends RuntimeException {

    private static final String MESSAGE_1 = "Unable to get the parent layer of file uri [";
    private static final String MESSAGE_2 = "]";

    public static final String MESSAGE = MESSAGE_1 + "{}" + MESSAGE_2;

    public StorageKeeperParentLayerException() {
    }

    public StorageKeeperParentLayerException(String file) {
        super(MESSAGE_1 + file + MESSAGE_2);
    }

    public StorageKeeperParentLayerException(String file, Throwable cause) {
        super(MESSAGE_1 + file + MESSAGE_2, cause);
    }

    public StorageKeeperParentLayerException(Throwable cause) {
        super(cause);
    }
}