package com.victorbuckservices.vbackbone.common.storagekeeper.sftp;

import com.jcraft.jsch.*;
import com.victorbuckservices.vbackbone.common.storagekeeper.LocalWorkingDirectory;
import com.victorbuckservices.vbackbone.common.storagekeeper.VbbFileDataType;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.*;
import org.apache.commons.exec.OS;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public class SftpLocalWorkingDirectory implements LocalWorkingDirectory {

    @Autowired
    private Environment environment;

    private static final List<VbbFileDataType> HANDLED_DATA_TYPES = Arrays.asList(
            VbbFileDataType.DELIVERY,
            VbbFileDataType.INPUT,
            VbbFileDataType.LOGGING,
            VbbFileDataType.OUTPUT,
            VbbFileDataType.TEMPORARY
    );

    /**
     * - localBase is the working directory on the local drive
     * - storageBase is the directory on the storage file server that will contain the containers after a commit
     */
    private File localBase;
    private String storageBase;
    private boolean storageBaseExistence;
    private String processUuid;
    /**
     * These are the sub-folders of the localBase directory.
     * All information stored in these folders must respect the following rules in order to be handled correctly
     * by the Archiving Service:
     * - input:    input files (which are provided by the provideLocalWith method)
     * - output:   output file that will be consumed by another service
     * - delivery: document (PDF or HTML) that will be referenced by another service
     * - log:      logs
     * - temp:     all the other types of files
     */
    private Map<VbbFileDataType, File> folders;
    private Map<VbbFileDataType, String> containers;
    private Map<VbbFileDataType, Boolean> archiveStatus;
    private Map<VbbFileDataType, Boolean> cleanedUpStatus;
    private Map<VbbFileDataType, Boolean> containerExistenceStatus;

    private String sshHost;
    private String sshUser;
    private String sshPassword;

    public SftpLocalWorkingDirectory(String sshHost, String sshUser, String sshPassword) {
        this.sshHost = sshHost;
        this.sshUser = sshUser;
        this.sshPassword = sshPassword;
    }

    public static List<VbbFileDataType> getHandledDataTypes() {
        return HANDLED_DATA_TYPES;
    }

    private static boolean sftpFileExists(ChannelSftp sftpChannel, String fileToCheck) {
        try {
            SftpATTRS attrs = sftpChannel.lstat(fileToCheck);
            return true;
        } catch (SftpException e) {
            return false;
        }
    }

    public void init() {
        if (!OS.isFamilyWindows() && environment.acceptsProfiles("production")) {
            throw new IllegalStateException("You are using an SftpStorageKeeper associated to a local environment with a production profile on a non windows OS, this configuration is erroneous");
        }

        folders = new HashMap<>();
        containers = new HashMap<>();
        archiveStatus = new HashMap<>();
        cleanedUpStatus = new HashMap<>();
        containerExistenceStatus = new HashMap<>();

        for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
            File localFolder = new File(localBase, dataType.getName());
            String container = storageBase + processUuid + "." + dataType.getName() + ".zip";

            folders.put(dataType, localFolder);
            containers.put(dataType, container);
        }

        checkStorageFolderAvailability();

        for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
            File localFolder = folders.get(dataType);
            String container = containers.get(dataType);

            if (localFolder.exists() && containerExists(dataType)) {
                archiveStatus.put(dataType, true);
                cleanedUpStatus.put(dataType, false);
            } else if (localFolder.exists() && !containerExists(dataType)) {
                archiveStatus.put(dataType, false);
                cleanedUpStatus.put(dataType, false);
            } else if (!localFolder.exists() && containerExists(dataType)) {
                archiveStatus.put(dataType, true);
                cleanedUpStatus.put(dataType, true);
            } else {
                archiveStatus.put(dataType, false);
                cleanedUpStatus.put(dataType, false);
            }
        }
    }

    private void checkStorageFolderAvailability() {
        JSch jsch = new JSch(); // TODO manage the connection better
        Session session = null;
        ChannelSftp sftpChannel = null;

        try {
            // 1 connect to the sftp storage
            session = jsch.getSession(sshUser, sshHost);
            session.setPassword(sshPassword);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();

            sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();

            // 2 check storageBase availibility
            this.storageBaseExistence = sftpFileExists(sftpChannel, getStorageBase());

            // 3 check containers existence
            for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
                String container = getStorageContainer(dataType);
                boolean containerExists = sftpFileExists(sftpChannel, container);
                setContainerExistence(dataType, containerExists);
            }
        } catch (Exception e) {
            e.printStackTrace(); //TODO
        } finally {
            if (sftpChannel != null)
                sftpChannel.disconnect();
            if (session != null)
                session.disconnect();
        }
    }

    @Override
    public File getLocalBase() {
        return localBase;
    }

    public void setLocalBase(String baseFolder, boolean isNew) {
        localBase = new File(baseFolder);

        if (isNew && localBase.exists()) {
            throw new LocalFolderAlreadyExistingException(localBase.getAbsolutePath());
        } else if (!isNew && !localBase.exists()) {
            throw new LocalFolderNotFoundException(localBase.getAbsolutePath());
        }
    }

    @Override
    public String getStorageBase() {
        return storageBase;
    }

    public void setStorageBase(String storageBase, boolean isNew) {
        this.storageBase = storageBase;
        if (!this.storageBase.endsWith("/")) this.storageBase += "/";

        JSch jsch = new JSch(); // TODO manage the connection better
        Session session = null;
        ChannelSftp sftpChannel = null;
        try {
            // 1 connect to the sftp storage
            session = jsch.getSession(sshUser, sshHost);
            session.setPassword(sshPassword);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();

            sftpChannel = (ChannelSftp) session.openChannel("sftp");
            sftpChannel.connect();

            this.storageBaseExistence = sftpFileExists(sftpChannel, this.storageBase);

        } catch (JSchException e) {
            e.printStackTrace(); //TODO
        } finally {
            if (sftpChannel != null)
                sftpChannel.disconnect();
            if (session != null)
                session.disconnect();
        }

        if (!isNew && !this.storageBaseExistence) {
            throw new StorageFolderNotFoundException(storageBase);
        }
    }

    @Override
    public String getProcessUuid() {
        return processUuid;
    }

    public void setProcessUuid(String processUuid) {
        this.processUuid = processUuid;
    }

    public void makeLocalDirs() {
        if (!localBase.mkdirs()) {
            throw new LocalFolderCreationException(localBase.getAbsolutePath());
        }
        for (VbbFileDataType dataType : HANDLED_DATA_TYPES) {
            if (!folders.get(dataType).mkdirs()) {
                throw new LocalFolderCreationException(folders.get(dataType).getAbsolutePath());
            }
        }
    }

    public void makeStorageDirs() {
        if (!this.storageBaseExistence) {
            JSch jsch = new JSch(); // TODO manage the connection better
            Session session = null;
            ChannelSftp sftpChannel = null;
            try {
                // 1 connect to the sftp storage
                session = jsch.getSession(sshUser, sshHost);
                session.setPassword(sshPassword);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                sftpChannel = (ChannelSftp) session.openChannel("sftp");
                sftpChannel.connect();
                sftpChannel.cd("/");
                String[] folders = this.storageBase.split("/");

                for (String folder : folders) {
                    if (folder.length() > 0) {
                        try {
                            sftpChannel.cd(folder);
                        } catch (SftpException e2) {
                            sftpChannel.mkdir(folder);
                            sftpChannel.cd(folder);
                        }
                    }
                }

                this.storageBaseExistence = sftpFileExists(sftpChannel, this.storageBase);

            } catch (JSchException | SftpException e) {
                throw new StorageFolderCreationException(storageBase, e);
            } finally {
                if (sftpChannel != null)
                    sftpChannel.disconnect();
                if (session != null)
                    session.disconnect();
            }
        }
    }

    @Override
    public File getLocalDirectory(VbbFileDataType dataType) {
        return folders.get(dataType);
    }

    @Override
    public String getStorageContainer(VbbFileDataType dataType) {
        return containers.get(dataType);
    }

    @Override
    public boolean isArchived(VbbFileDataType dataType) {
        return archiveStatus.get(dataType);
    }

    @Override
    public boolean isCleanedUp(VbbFileDataType dataType) {
        return cleanedUpStatus.get(dataType);
    }

    @Override
    public boolean isEmpty(VbbFileDataType dataType) {
        if (!folders.get(dataType).exists()) return true;
        return folders.get(dataType).list().length == 0;
    }

    public boolean containerExists(VbbFileDataType dataType) {
        return containerExistenceStatus.get(dataType);
    }

    @Override
    public boolean setArchived(VbbFileDataType dataType, boolean value) {
        return archiveStatus.put(dataType, value);
    }

    @Override
    public boolean setCleanedUp(VbbFileDataType dataType, boolean value) {
        return cleanedUpStatus.put(dataType, value);
    }

    public void setContainerExistence(VbbFileDataType dataType, boolean value) {
        containerExistenceStatus.put(dataType, value);
    }

    /**
     * The following getters are there for ease of access
     */
    @Override
    public File input() {
        return folders.get(VbbFileDataType.INPUT);
    }

    @Override
    public File output() {
        return folders.get(VbbFileDataType.OUTPUT);
    }

    @Override
    public File temp() {
        return folders.get(VbbFileDataType.TEMPORARY);
    }

    @Override
    public File log() {
        return folders.get(VbbFileDataType.LOGGING);
    }

    @Override
    public File temporary() {
        return folders.get(VbbFileDataType.TEMPORARY);
    }

    @Override
    public File logging() {
        return folders.get(VbbFileDataType.LOGGING);
    }

    @Override
    public File delivery() {
        return folders.get(VbbFileDataType.DELIVERY);
    }
}
