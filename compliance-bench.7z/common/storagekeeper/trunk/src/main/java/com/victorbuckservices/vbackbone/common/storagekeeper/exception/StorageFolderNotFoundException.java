package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class StorageFolderNotFoundException extends RuntimeException {

    public StorageFolderNotFoundException() {
    }

    public StorageFolderNotFoundException(String folder) {
        super("The storage folder [" + folder + "] does not exist!");
    }

    public StorageFolderNotFoundException(String folder, Throwable cause) {
        super("The storage folder [" + folder + "] does not exist!", cause);
    }

    public StorageFolderNotFoundException(Throwable cause) {
        super(cause);
    }
}