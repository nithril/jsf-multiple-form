package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class LocalFolderCreationException extends RuntimeException {

    public LocalFolderCreationException() {
    }

    public LocalFolderCreationException(String folder) {
        super("Unable to create local folder [" + folder + "]!");
    }

    public LocalFolderCreationException(String folder, Throwable cause) {
        super("Unable to create local folder [" + folder + "]!", cause);
    }

    public LocalFolderCreationException(Throwable cause) {
        super(cause);
    }
}