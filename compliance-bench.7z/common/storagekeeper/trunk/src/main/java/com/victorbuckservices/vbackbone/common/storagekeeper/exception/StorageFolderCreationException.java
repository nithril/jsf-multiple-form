package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class StorageFolderCreationException extends RuntimeException {

    public StorageFolderCreationException() {
    }

    public StorageFolderCreationException(String folder) {
        super("Unable to create storage folder [" + folder + "]!");
    }

    public StorageFolderCreationException(String folder, Throwable cause) {
        super("Unable to create storage folder [" + folder + "]!", cause);
    }

    public StorageFolderCreationException(Throwable cause) {
        super(cause);
    }
}