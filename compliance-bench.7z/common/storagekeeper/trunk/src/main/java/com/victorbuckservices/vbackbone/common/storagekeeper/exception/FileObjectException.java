package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class FileObjectException extends RuntimeException {

    private static final String MESSAGE_1 = "The was a error with the method [";
    private static final String MESSAGE_2 = "] applied to FileObject [";
    private static final String MESSAGE_3 = "]";

    public static final String MESSAGE = MESSAGE_1 + "{}" + MESSAGE_2 + "{}" + MESSAGE_3;

    public FileObjectException() {
    }

    public FileObjectException(String method, String fileObject) {
        super(MESSAGE_1 + method + MESSAGE_2 + fileObject + MESSAGE_3);
    }

    public FileObjectException(String method, String fileObject, Throwable cause) {
        super(MESSAGE_1 + method + MESSAGE_2 + fileObject + MESSAGE_3, cause);
    }

    public FileObjectException(Throwable cause) {
        super(cause);
    }
}