package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.google.common.net.UrlEscapers;
import com.victorbuckservices.vbackbone.common.storagekeeper.exception.FileObjectException;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-06-03.
 */
public class FileObjectResource implements CloseableResource {

    private static final Logger LOG = LoggerFactory.getLogger(FileObjectResource.class);

    private final FileObject resource;
    private final FileSystemManager fileSystemManager;

    public FileObjectResource(FileSystemManager fileSystemManager, FileObject fo) {
        this.fileSystemManager = fileSystemManager;
        resource = fo;
    }

    @Override
    public boolean exists() {
        try {
            return resource.exists();
        } catch (FileSystemException e) {
            LOG.error(FileObjectException.MESSAGE, "exists()", resource);
            throw new FileObjectException("exists()", resource.toString(), e);
        }
    }

    @Override
    public boolean isReadable() {
        try {
            return resource.isReadable();
        } catch (FileSystemException e) {
            LOG.error(FileObjectException.MESSAGE, "isReadable()", resource);
            throw new FileObjectException("isReadable()", resource.toString(), e);
        }
    }

    @Override
    public boolean isOpen() {
        return resource.isContentOpen();
    }

    @Override
    public URL getURL() throws IOException {
        return resource.getURL();
    }

    @Override
    public URI getURI() throws IOException {
        String url;
        try {
            url = UrlEscapers.urlFragmentEscaper().escape(resource.getURL().toString());
            return new URI(url);
        } catch (URISyntaxException e) {
            LOG.error(FileObjectException.MESSAGE, "getURI()", resource);
            throw new FileObjectException("getURI()", resource.toString(), e);
        }
    }

    @Override
    public String toString() {
        return resource.toString();
    }

    @Override
    public File getFile() throws IOException {
        throw new UnsupportedOperationException("FileObjectResource.getFile()");
    }

    @Override
    public long contentLength() throws IOException {
        try (FileContent content = resource.getContent()){
            return content.getSize();
        }
    }

    @Override
    public long lastModified() throws IOException {
        try (FileContent content = resource.getContent()){
            return content.getLastModifiedTime();
        }
    }

    @Override
    public Resource createRelative(String s) throws IOException {
        throw new UnsupportedOperationException("FileObjectResource.createRelative()");
    }

    @Override
    public String getFilename() {
        return resource.getName().getBaseName();
    }

    @Override
    public String getDescription() {
        throw new UnsupportedOperationException("FileObjectResource.getDescription()");
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return StorageKeeperUtils.newInputStream(resource);
    }

    @Override
    public void close() throws IOException {
       resource.close();
    }
}
