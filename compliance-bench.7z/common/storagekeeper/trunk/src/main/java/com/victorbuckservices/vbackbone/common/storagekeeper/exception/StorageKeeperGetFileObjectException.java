package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class StorageKeeperGetFileObjectException extends RuntimeException {

    private static final String MESSAGE_1 = "Unable to get FileObject from [";
    private static final String MESSAGE_2 = "] with system manager!";

    public static final String MESSAGE = MESSAGE_1 + "{}" + MESSAGE_2;

    public StorageKeeperGetFileObjectException() {
    }

    public StorageKeeperGetFileObjectException(String file) {
        super(MESSAGE_1 + file + MESSAGE_2);
    }

    public StorageKeeperGetFileObjectException(String file, Throwable cause) {
        super(MESSAGE_1 + file + MESSAGE_2, cause);
    }

    public StorageKeeperGetFileObjectException(Throwable cause) {
        super(cause);
    }
}