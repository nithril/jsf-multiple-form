package com.victorbuckservices.vbackbone.common.storagekeeper.exception;

/**
 * ************************************************************************
 * * ____   _______.                  __   ___.                           *
 * * \   \ /   /\_ |__ _____    ____ |  | _\_ |__   ____   ____   ____    *
 * *  \   Y   /  | __ \\__  \ _/ ___\|  |/ /| __ \ /  _ \ /    \_/ __ \   *
 * *   \     /   | \_\ \/ __ \\  \___|    < | \_\ (  <_> )   |  \  ___/   *
 * *    \___/    |___  (____  /\___  >__|_ \|___  /\____/|___|  /\___  >  *
 * *                 \/     \/     \/     \/    \/            \/     \/   *
 * ************************************************************************
 * Created by Perard on 2015-05-18.
 */
public class StorageContainerAlreadyExistingException extends RuntimeException {

    public StorageContainerAlreadyExistingException() {
    }

    public StorageContainerAlreadyExistingException(String container) {
        super("The storage container [" + container + "] already exists!");
    }

    public StorageContainerAlreadyExistingException(String container, Throwable cause) {
        super("The storage container [" + container + "] already exists!", cause);
    }

    public StorageContainerAlreadyExistingException(Throwable cause) {
        super(cause);
    }
}