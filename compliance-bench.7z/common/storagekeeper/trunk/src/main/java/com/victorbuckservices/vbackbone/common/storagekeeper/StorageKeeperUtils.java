package com.victorbuckservices.vbackbone.common.storagekeeper;

import com.victorbuckservices.vbackbone.common.storagekeeper.exception.DataTypeNotFoundException;
import org.apache.commons.io.input.ProxyInputStream;
import org.apache.commons.vfs2.FileContent;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created on 06/12/2015
 *
 * @author labrot
 */
public final class StorageKeeperUtils {

    private static final Logger LOG = LoggerFactory.getLogger(StorageKeeperUtils.class);

    protected StorageKeeperUtils() {
    }

    /**
     * Create an {@link InputStream} from a {@link FileObject}. <br>
     * <p/>
     * This method wraps the {@link InputStream} in order to close automaticly the underlying {@link FileContent} needs to open the stream.
     *
     * @param fileObject
     * @return
     * @throws FileSystemException
     */
    public static InputStream newInputStream(FileObject fileObject) throws FileSystemException {
        FileContent fileContent = fileObject.getContent();

        return new ProxyInputStream(fileContent.getInputStream()) {
            @Override
            public void close() throws IOException {
                super.close();
                fileContent.close();
            }
        };
    }

    /**
     * Create an {@link BufferedInputStream} from a {@link FileObject}. <br>
     * See {@link #newInputStream(FileObject)}
     * @param fileObject
     * @return
     * @throws FileSystemException
     */
    public static BufferedInputStream newBufferedInputStream(FileObject fileObject) throws FileSystemException {
        return new BufferedInputStream(newInputStream(fileObject));
    }


    public static VbbFileDataType getDataTypeFromPath(String path) {

        String uuidCaptureGrp = "([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})   # capture group 1\n";
        String separatorCaptureGrp = "(.{1})  # capture group 2\n";
        String dataTypeCaptureGrp = "(\\w+)   # capture group 3\n";
        String separatorBackRef = "(\\2)      # back reference to the capture group 2\n";
        String zipExtension = "zip$           # the extension must end the string\n";

        Pattern uuidOnlyPattern = Pattern.compile(uuidCaptureGrp, Pattern.COMMENTS);
        Matcher uuidOnlyMatcher = uuidOnlyPattern.matcher(path);

        if (uuidOnlyMatcher.find()) {
            Pattern newPathPattern = Pattern.compile(uuidCaptureGrp + separatorCaptureGrp + dataTypeCaptureGrp + separatorBackRef, Pattern.COMMENTS);
            Matcher newPathMatcher = newPathPattern.matcher(path);

            if (newPathMatcher.find()) {
                String dataType = newPathMatcher.group(3);
                VbbFileDataType retValue = VbbFileDataType.findByName(dataType);
                if (retValue == null) {
                    LOG.error(DataTypeNotFoundException.MESSAGE, path);
                    throw new DataTypeNotFoundException(path);
                }
                return retValue;
            }

            // For the old style StorageKeeper (version < 1.0.1-SNAPSHOT)
            Pattern oldPathPattern = Pattern.compile(uuidCaptureGrp + separatorCaptureGrp + zipExtension, Pattern.COMMENTS);
            Matcher oldPathMatcher = oldPathPattern.matcher(path);

            if (oldPathMatcher.find()) return VbbFileDataType.DELIVERY;
        }

        LOG.error(DataTypeNotFoundException.MESSAGE, path);
        throw new DataTypeNotFoundException(path);
    }
}
