package com.victorbuckservices.vbackbone.common.storagekeeper;

/**
 * Created on 16/09/2015
 *
 * @author labrot
 */
public class StorageKeeperArchive {

    private VbbFileDataType fileDataType;
    private String storageUri;
    private long fileSize;

    public StorageKeeperArchive() {
    }


    public StorageKeeperArchive(VbbFileDataType fileDataType, String storageUri, long fileSize) {
        this.fileDataType = fileDataType;
        this.storageUri = storageUri;
        this.fileSize = fileSize;
    }

    public String getStorageUri() {
        return storageUri;
    }

    public void setStorageUri(String storageUri) {
        this.storageUri = storageUri;
    }

    public VbbFileDataType getFileDataType() {
        return fileDataType;
    }

    public void setFileDataType(VbbFileDataType fileDataType) {
        this.fileDataType = fileDataType;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StorageKeeperArchive that = (StorageKeeperArchive) o;

        if (fileSize != that.fileSize) return false;
        if (fileDataType != that.fileDataType) return false;
        return storageUri.equals(that.storageUri);
    }

    @Override
    public int hashCode() {
        int result = fileDataType.hashCode();
        result = 31 * result + storageUri.hashCode();
        result = 31 * result + (int) (fileSize ^ (fileSize >>> 32));
        return result;
    }
}
